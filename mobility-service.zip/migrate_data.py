import re
import csv
import io
import collections

def parse_line_name(line_val):
    line_val = line_val.replace("'", "").strip()
    if line_val.isdigit():
        return f"{line_val}호선"
    return line_val

def normalize_station_name(name):
    """Normalize for deduplication: remove '역' suffix and whitespace."""
    n = name.replace("'", "").strip()
    if n.endswith("역"):
        return n[:-1]
    return n

def format_station_name_for_db(name):
    """Ensure consistent display format: always add '역' if missing? Or keep source?
    User prefers 'station list' to be consistent. 
    insert_subway_stations.sql uses '역'. Let's enforce '역' suffix for consistency.
    """
    n = name.replace("'", "").strip()
    if not n.endswith("역"):
        return n + "역"
    return n

def classify_line_1(station_name):
    """Heuristic to split 1호선 into logical sections."""
    # This is a rough heuristic. Overlaps are tricky, but this reduces menu bloat.
    # 인천/경인선 Section
    gyeongin_set = {'인천', '동인천', '도원', '제물포', '도화', '주안', '간석', '동암', '백운', '부평', '부개', '송내', '중동', '부천', '소사', '역곡', '온수', '오류동', '개봉', '구일'}
    # 천안/신창/수원 Section (Expanded list)
    gyeongbu_set = {'금천구청', '석수', '관악', '안양', '명학', '금정', '군포', '당정', '의왕', '성균관대', '화서', '수원', '세류', '병점', '세마', '오산대', '오산', '진위', '송탄', '서정리', '평택지제', '평택', '성환', '직산', '두정', '천안', '봉명', '쌍용', '아산', '탕정', '배방', '온양온천', '신창', '서동탄'}
    
    nm = normalize_station_name(station_name)
    if nm in gyeongin_set:
        return '1호선(경인)'
    if nm in gyeongbu_set:
        return '1호선(경부)'
    return '1호선(서울)'

def migrate():
    output_lines = []
    
    # [1] Full Reset & Schema Creation (The "Nuclear Option")
    # Drop likely existing tables/sequences to prevent ORA-00001 / name conflicts
    output_lines.append("-- [1] Reset Schema")
    output_lines.append("BEGIN")
    output_lines.append("    FOR r IN (SELECT table_name FROM user_tables WHERE table_name IN ('TB_INFRA_HUB', 'TB_KTX_SCHEDULE', 'TB_BOARD', 'TB_USER_ASSET')) LOOP")
    output_lines.append("        EXECUTE IMMEDIATE 'DROP TABLE ' || r.table_name || ' CASCADE CONSTRAINTS';")
    output_lines.append("    END LOOP;")
    output_lines.append("    FOR s IN (SELECT sequence_name FROM user_sequences WHERE sequence_name = 'MAAS_CORE_SEQ') LOOP")
    output_lines.append("        EXECUTE IMMEDIATE 'DROP SEQUENCE ' || s.sequence_name;")
    output_lines.append("    END LOOP;")
    output_lines.append("END;")
    output_lines.append("/")
    output_lines.append("")
    
    output_lines.append("-- [2] Create Sequence")
    output_lines.append("CREATE SEQUENCE MAAS_CORE_SEQ START WITH 1 INCREMENT BY 1;")
    output_lines.append("")
    
    output_lines.append("-- [3] Create Tables")
    output_lines.append("CREATE TABLE TB_INFRA_HUB (")
    output_lines.append("    ID NUMBER PRIMARY KEY,")
    output_lines.append("    CATEGORY VARCHAR2(20),")
    output_lines.append("    TYPE_NAME VARCHAR2(50),")
    output_lines.append("    STATION_NAME VARCHAR2(100) NOT NULL,")
    output_lines.append("    LATITUDE NUMBER(15, 10),")
    output_lines.append("    LONGITUDE NUMBER(15, 10),")
    output_lines.append("    ADD_INFO VARCHAR2(500),")
    output_lines.append("    IS_TAGLESS NUMBER(1) DEFAULT 0")
    output_lines.append(");")
    output_lines.append("")
    output_lines.append("CREATE TABLE TB_KTX_SCHEDULE (SCH_ID NUMBER PRIMARY KEY, TRAIN_NO VARCHAR2(50), DEP_PLACE VARCHAR2(100), ARR_PLACE VARCHAR2(100), DEP_TIME VARCHAR2(10), ARR_TIME VARCHAR2(10), CHARGE NUMBER);")
    output_lines.append("CREATE TABLE TB_BOARD (BNO NUMBER PRIMARY KEY, TITLE VARCHAR2(200), CONTENT CLOB, WRITER VARCHAR2(50), REGDATE DATE DEFAULT SYSDATE);")
    output_lines.append("CREATE TABLE TB_USER_ASSET (USER_ID NUMBER PRIMARY KEY, MILEAGE_POINT NUMBER DEFAULT 0, K_PASS_YN VARCHAR2(1) DEFAULT 'N');")
    output_lines.append("")
    
    output_lines.append("-- [4] Data Migration")

    files = [
        'insert_subway_stations.sql', # Priority 1: Has full Lines 1-9
        'integrate_subway_data.sql'   # Priority 2: Incheon, Suin, etc.
    ]
    
    # Set of (normalized_line, normalized_name) to track duplicates
    seen = set()
    stats = collections.defaultdict(int)

    for fname in files:
        print(f"Processing {fname}...")
        try:
            with open(fname, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # More robust regex to capture VALUES content
            # Matches: VALUES ( ... ); ignoring case, spanning lines if needed
            vals_iter = re.finditer(r"VALUES\s*\((.*?)\);", content, re.IGNORECASE | re.DOTALL)
            matches = list(vals_iter)
            print(f"Found {len(matches)} VALUES clauses in {fname}")
            
            for match in matches:
                val_str = match.group(1).replace('\n', ' ')
                
                # Use csv reader to handle quoted strings containing commas (e.g., '1호선,2호선')
                reader = csv.reader([val_str], skipinitialspace=True, quotechar="'")
                try:
                    parts = next(reader)
                except StopIteration:
                    print("CSV parsing failed for: " + val_str[:20])
                    continue
                
                # Clean up parts (remove extra whitespace/quotes artifacts if csv didn't catch all)
                # We interpret them as strings
                
                station_name = ""
                line_name = ""
                lat = 0.0
                lon = 0.0
                tagless = 0
                
                # Determine columns based on file
                if 'insert_subway_stations.sql' in fname:
                     # (SEQ, STATION_NAME, LINE_NUMBER, LAT, LON, TRANSFER_LINES)
                     # Example: (SEQ, '소요산역', '1', 37.948, 127.060, '1호선')
                     if len(parts) >= 6:
                        station_name = parts[1]
                        line_raw = parts[2]
                        lat = parts[3]
                        lon = parts[4]
                        line_name = parse_line_name(line_raw)
                     else:
                        print(f"Skipping insert_subway_stations match: len={len(parts)}")

                elif 'integrate_subway_data.sql' in fname:
                    # (SEQ, LINE_NAME, STATION_NAME, LAT, LON, CODE, TAGLESS)
                    # Example: (SEQ, '인천1호선', '계양', 37.537, 126.544, 'I110', 1)
                     if len(parts) >= 5:
                        line_raw = parts[1]
                        station_name = parts[2]
                        lat = parts[3]
                        lon = parts[4]
                        line_name = parse_line_name(line_raw)
                        if len(parts) >= 7 and str(parts[6]).strip().isdigit():
                            tagless = parts[6]
                     else:
                        print(f"Skipping integrate_subway_data match: len={len(parts)}")
                            
                # Validation
                if not station_name or not line_name:
                    continue
                    
                # --- Logic Improvements ---
                
                # 1. Merge Suin/Bundang
                if '수인선' in line_name or '분당선' in line_name:
                    line_name = '수인분당선'
                    
                # 2. Split Line 1
                if line_name == '1호선':
                    # Only apply splitting if it's generic '1호선'. 
                    # If file already had '1호선(경인)' (unlikely), keep it.
                    line_name = classify_line_1(station_name)
                    
                # Deduplication logic
                norm_line = line_name.strip()
                norm_name = normalize_station_name(station_name)
                
                combo = (norm_line, norm_name)
                
                if combo in seen:
                    # print(f"Skipping duplicate: {line_name} - {station_name}")
                    continue
                
                seen.add(combo)
                
                # Formatting
                db_station_name = format_station_name_for_db(station_name)
                
                # Clean lat/lon
                try:
                    lat_val = float(lat)
                    lon_val = float(lon)
                except ValueError:
                    continue
                    
                # Insert
                sql = f"INSERT INTO TB_INFRA_HUB (ID, CATEGORY, TYPE_NAME, STATION_NAME, LATITUDE, LONGITUDE, ADD_INFO, IS_TAGLESS) VALUES (MAAS_CORE_SEQ.NEXTVAL, 'SUBWAY', '{norm_line}', '{db_station_name}', {lat_val}, {lon_val}, '{{}}', {tagless});"
                output_lines.append(sql)
                stats[norm_line] += 1

        except FileNotFoundError:
            print(f"Skipping {fname} (not found)")
            
    print("Migration Stats:")
    for k, v in sorted(stats.items()):
        print(f"  {k}: {v} stations")
            
    # Add Test Data
    output_lines.append("INSERT INTO TB_INFRA_HUB (ID, CATEGORY, TYPE_NAME, STATION_NAME, LATITUDE, LONGITUDE, ADD_INFO, IS_TAGLESS) VALUES (MAAS_CORE_SEQ.NEXTVAL, 'PARKING', '공영', '부평역 주차장', 37.4898, 126.7250, '{\"spaces\": 45}', 0);")
    output_lines.append("INSERT INTO TB_INFRA_HUB (ID, CATEGORY, TYPE_NAME, STATION_NAME, LATITUDE, LONGITUDE, ADD_INFO, IS_TAGLESS) VALUES (MAAS_CORE_SEQ.NEXTVAL, 'BIKE', '따릉이', '부평역 1번출구', 37.4895, 126.7251, '{\"count\": 12}', 0);")
    output_lines.append("INSERT INTO TB_KTX_SCHEDULE (SCH_ID, TRAIN_NO, DEP_PLACE, ARR_PLACE, DEP_TIME, ARR_TIME, CHARGE) VALUES (MAAS_CORE_SEQ.NEXTVAL, 'KTX 001', '서울', '부산', '09:00', '11:30', 59800);")
    output_lines.append("INSERT INTO TB_USER_ASSET (USER_ID, MILEAGE_POINT, K_PASS_YN) VALUES (1, 5000, 'Y');")
    output_lines.append("COMMIT;")
    
    with open('master_build_zero_error.sql', 'w', encoding='utf-8') as f:
        f.write('\n'.join(output_lines))
        
if __name__ == "__main__":
    migrate()
