ㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈ# K-MaaS Platform - API Documentation

**서울·경기·인천 통합 모빌리티 플랫폼 API 문서**

- **Base URL**: `http://localhost:9999`
- **프로젝트**: Spring Boot 3.x + Oracle 11g XE
- **패키지**: `com.maas.service`

---

## 목차

1. [회원 관리 API](#1-회원-관리-api)
2. [KTX 예약 API](#2-ktx-예약-api)
3. [지하철 실시간 API](#3-지하철-실시간-api)
4. [버스 실시간 API](#4-버스-실시간-api)
5. [공유 모빌리티 (따릉이) API](#5-공유-모빌리티-따릉이-api)
6. [공영 주차장 API](#6-공영-주차장-api)
7. [정책 관리 API](#7-정책-관리-api)
8. [제휴 상점 API](#8-제휴-상점-api)
9. [대시보드 API](#9-대시보드-api)

---

## 1. 회원 관리 API

### 1.1 회원가입

**POST** `/api/users/register`

회원가입 처리

**Request Body:**
```json
{
  "name": "김철수",
  "email": "kim@example.com",
  "password": "password123",
  "phone": "010-1234-5678"
}
```

**Response:**
```json
{
  "success": true,
  "message": "회원가입이 완료되었습니다.",
  "userId": 1
}
```

**curl 테스트:**
```bash
curl -X POST http://localhost:9999/api/users/register \
  -H "Content-Type: application/json" \
  -d '{"name":"김철수","email":"kim@example.com","password":"password123","phone":"010-1234-5678"}'
```

---

### 1.2 로그인

**POST** `/api/users/login`

로그인 처리

**Request Body:**
```json
{
  "email": "kim@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "로그인 성공",
  "user": {
    "id": 1,
    "name": "김철수",
    "email": "kim@example.com",
    "points": 5000
  }
}
```

**curl 테스트:**
```bash
curl -X POST http://localhost:9999/api/users/login \
  -H "Content-Type: application/json" \
  -d '{"email":"kim@example.com","password":"password123"}'
```

---

### 1.3 회원 정보 조회

**GET** `/api/users/{userId}`

특정 회원의 상세 정보 조회

**Response:**
```json
{
  "id": 1,
  "name": "김철수",
  "email": "kim@example.com",
  "phone": "010-1234-5678",
  "points": 5000,
  "createdAt": "2026-01-12T10:30:00"
}
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/users/1
```

---

### 1.4 포인트 내역 조회

**GET** `/api/users/{userId}/points`

회원의 포인트 거래 내역 조회

**Response:**
```json
[
  {
    "transactionId": 1,
    "userId": 1,
    "amount": 1000,
    "type": "EARN",
    "reason": "회원가입 보너스",
    "transactionTime": "2026-01-12T10:30:00"
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/users/1/points
```

---

## 2. KTX 예약 API

### 2.1 KTX 페이지

**GET** `/ktx`

KTX 예약 페이지 렌더링

**Response:** HTML 페이지

---

## 3. 지하철 실시간 API

### 3.1 지하철 페이지

**GET** `/subway`

지하철 실시간 정보 페이지 렌더링

**Response:** HTML 페이지

---

### 3.2 지하철역 목록 조회

**GET** `/api/subway/stations`

모든 지하철역 목록 조회

**Query Parameters:**
- `line` (optional): 노선 번호 (예: 1, 2, 3, ..., 9)

**Response:**
```json
[
  {
    "stationId": 1,
    "stationName": "강남역",
    "lineNumber": "2",
    "latitude": 37.498095,
    "longitude": 127.027610,
    "stationCode": "222",
    "isTransfer": true,
    "transferLines": "신분당선"
  }
]
```

**curl 테스트:**
```bash
# 전체 역 조회
curl -X GET http://localhost:9999/api/subway/stations

# 2호선만 조회
curl -X GET "http://localhost:9999/api/subway/stations?line=2"
```

---

### 3.3 노선별 지하철역 조회

**GET** `/api/subway/lines/{lineNumber}`

특정 노선의 모든 역 조회

**Path Parameters:**
- `lineNumber`: 노선 번호 (1~9)

**Response:**
```json
[
  {
    "stationId": 1,
    "stationName": "강남역",
    "lineNumber": "2",
    "latitude": 37.498095,
    "longitude": 127.027610
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/subway/lines/2
```

---

## 4. 버스 실시간 API

### 4.1 버스 페이지

**GET** `/bus`

버스 실시간 정보 페이지 렌더링

**Response:** HTML 페이지

---

## 5. 공유 모빌리티 (따릉이) API

### 5.1 따릉이 페이지

**GET** `/bike`

따릉이/공유 모빌리티 페이지 렌더링 (카카오맵 포함)

**Response:** HTML 페이지

---

### 5.2 대여소 목록 조회

**GET** `/api/bike/stations`

모든 따릉이 대여소 목록 조회

**Response:**
```json
[
  {
    "stationId": "ST-001",
    "stationName": "강남역 1번출구",
    "latitude": 37.498095,
    "longitude": 127.027610,
    "availableBikes": 12,
    "totalDocks": 20,
    "district": "강남구",
    "address": "서울특별시 강남구 강남대로 지하396"
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/bike/stations
```

---

### 5.3 구역별 대여소 조회

**GET** `/api/bike/stations/district/{district}`

특정 구역의 대여소 조회

**Path Parameters:**
- `district`: 구 이름 (예: 강남구, 마포구)

**Response:**
```json
[
  {
    "stationId": "ST-001",
    "stationName": "강남역 1번출구",
    "availableBikes": 12,
    "totalDocks": 20
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/bike/stations/district/강남구
```

---

## 6. 공영 주차장 API

### 6.1 주차장 페이지

**GET** `/parking`

공영 주차장 검색 페이지 렌더링

**Response:** HTML 페이지

---

### 6.2 주차장 데이터 업데이트

**POST** `/api/parking/update`

서울·경기 주차장 데이터 업데이트 (Mock 데이터 로드)

**Response:**
```json
{
  "success": true,
  "message": "주차장 데이터 업데이트 완료"
}
```

**curl 테스트:**
```bash
curl -X POST http://localhost:9999/api/parking/update
```

---

### 6.3 전체 주차장 목록 조회

**GET** `/api/parking/all`

모든 주차장 목록 조회

**Response:**
```json
[
  {
    "parkingId": 1,
    "parkingCode": "SEL-001",
    "parkingName": "강남역 공영주차장",
    "address": "서울 강남구 강남대로 396",
    "latitude": 37.498095,
    "longitude": 127.027610,
    "totalSpaces": 200,
    "availableSpaces": 45,
    "parkingType": "노외",
    "operationType": "공영",
    "weekdayBeginTime": "00:00",
    "weekdayEndTime": "24:00",
    "rates": "기본 30분 1,000원, 추가 10분당 500원",
    "payMethod": "현금, 카드, 모바일",
    "telephone": "02-1234-5678",
    "region": "서울",
    "district": "강남구"
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/parking/all
```

---

### 6.4 키워드로 주차장 검색

**GET** `/api/parking/search`

주차장 이름으로 검색

**Query Parameters:**
- `keyword`: 검색 키워드 (예: 강남, 서울역)

**Response:**
```json
[
  {
    "parkingId": 1,
    "parkingCode": "SEL-001",
    "parkingName": "강남역 공영주차장",
    "availableSpaces": 45
  }
]
```

**curl 테스트:**
```bash
curl -X GET "http://localhost:9999/api/parking/search?keyword=강남"
```

---

### 6.5 근처 주차장 검색

**GET** `/api/parking/nearby`

현재 위치 기반 근처 주차장 검색 (Haversine 거리 계산)

**Query Parameters:**
- `latitude`: 위도 (예: 37.498)
- `longitude`: 경도 (예: 127.027)
- `radius`: 반경 (km, 기본값: 5km)

**Response:**
```json
[
  {
    "parkingId": 1,
    "parkingCode": "SEL-001",
    "parkingName": "강남역 공영주차장",
    "distance": 0.5,
    "availableSpaces": 45
  }
]
```

**curl 테스트:**
```bash
curl -X GET "http://localhost:9999/api/parking/nearby?latitude=37.498&longitude=127.027&radius=5"
```

---

### 6.6 지역별 주차장 조회

**GET** `/api/parking/region/{region}`

특정 지역의 주차장 조회

**Path Parameters:**
- `region`: 지역 (서울 또는 경기)

**Response:**
```json
[
  {
    "parkingId": 1,
    "parkingName": "강남역 공영주차장",
    "region": "서울",
    "availableSpaces": 45
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/parking/region/서울
```

---

### 6.7 구역별 주차장 조회

**GET** `/api/parking/district/{district}`

특정 구역의 주차장 조회

**Path Parameters:**
- `district`: 구 이름 (예: 강남구, 수원시 팔달구)

**Response:**
```json
[
  {
    "parkingId": 1,
    "parkingName": "강남역 공영주차장",
    "district": "강남구",
    "availableSpaces": 45
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/parking/district/강남구
```

---

### 6.8 여유 공간 기준 주차장 조회

**GET** `/api/parking/available`

최소 여유 공간 이상인 주차장 조회

**Query Parameters:**
- `minSpaces`: 최소 여유 공간 (기본값: 10)

**Response:**
```json
[
  {
    "parkingId": 7,
    "parkingName": "서울역 공영주차장",
    "totalSpaces": 400,
    "availableSpaces": 156
  }
]
```

**curl 테스트:**
```bash
curl -X GET "http://localhost:9999/api/parking/available?minSpaces=100"
```

---

## 7. 정책 관리 API

### 7.1 정책 관리 페이지

**GET** `/policy`

정책 관리 페이지 렌더링

**Response:** HTML 페이지

---

### 7.2 전체 정책 목록 조회

**GET** `/api/policies`

모든 정책 목록 조회

**Response:**
```json
[
  {
    "policyId": 1,
    "policyName": "비혼잡 시간대 인센티브",
    "policyType": "off-peak",
    "enabled": true,
    "targetArea": "서울,경기",
    "incentivePoint": 500,
    "description": "오전 10시~오후 4시 이용 시 포인트 지급"
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/policies
```

---

### 7.3 정책 타입별 조회

**GET** `/api/policies/type/{policyType}`

특정 타입의 정책 조회

**Path Parameters:**
- `policyType`: off-peak, eco, flat, area

**Response:**
```json
[
  {
    "policyId": 1,
    "policyName": "비혼잡 시간대 인센티브",
    "policyType": "off-peak",
    "enabled": true
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/policies/type/off-peak
```

---

## 8. 제휴 상점 API

### 8.1 상점 연계 페이지

**GET** `/shops`

제휴 상점 연계 페이지 렌더링

**Response:** HTML 페이지

---

### 8.2 전체 상점 목록 조회

**GET** `/api/shops`

모든 제휴 상점 목록 조회

**Response:**
```json
[
  {
    "shopId": 1,
    "shopName": "스타벅스 강남역점",
    "category": "카페",
    "address": "서울 강남구 강남대로 지하396",
    "latitude": 37.498095,
    "longitude": 127.027610,
    "rating": 4.5,
    "discountRate": 10,
    "status": "open"
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/shops
```

---

### 8.3 카테고리별 상점 조회

**GET** `/api/shops/category/{category}`

특정 카테고리의 상점 조회

**Path Parameters:**
- `category`: 카페, 음식점, 편의점, 주유소, 운동

**Response:**
```json
[
  {
    "shopId": 1,
    "shopName": "스타벅스 강남역점",
    "category": "카페",
    "discountRate": 10
  }
]
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/shops/category/카페
```

---

## 9. 대시보드 API

### 9.1 대시보드 페이지

**GET** `/dashboard`

운영 대시보드 페이지 렌더링

**Response:** HTML 페이지

---

### 9.2 통합 통계 조회

**GET** `/api/dashboard/stats`

전체 시스템 통계 조회

**Response:**
```json
{
  "totalUsers": 1523,
  "todayUsage": 487,
  "monthlyUsage": 12458,
  "totalPoints": 1523000,
  "activePolicies": 5,
  "partnerShops": 142,
  "bikeStations": 234,
  "parkingLots": 49
}
```

**curl 테스트:**
```bash
curl -X GET http://localhost:9999/api/dashboard/stats
```

---

### 9.3 데이터 분석 페이지

**GET** `/analytics`

데이터 분석 페이지 렌더링

**Response:** HTML 페이지

---

## API 테스트 가이드

### 전체 시스템 테스트 스크립트

```bash
#!/bin/bash

echo "=== K-MaaS API 전체 테스트 ==="

echo "1. 주차장 데이터 업데이트"
curl -X POST http://localhost:9999/api/parking/update

echo "\n2. 전체 주차장 조회"
curl -X GET http://localhost:9999/api/parking/all | head -20

echo "\n3. 따릉이 대여소 조회"
curl -X GET http://localhost:9999/api/bike/stations | head -20

echo "\n4. 지하철역 조회"
curl -X GET http://localhost:9999/api/subway/stations | head -20

echo "\n5. 제휴 상점 조회"
curl -X GET http://localhost:9999/api/shops | head -20

echo "\n6. 정책 목록 조회"
curl -X GET http://localhost:9999/api/policies

echo "\n=== 테스트 완료 ==="
```

---

## 에러 응답 형식

모든 API에서 에러 발생 시 다음 형식으로 응답합니다:

```json
{
  "success": false,
  "error": "에러 메시지",
  "timestamp": "2026-01-12T10:30:00"
}
```

**HTTP 상태 코드:**
- `200 OK`: 성공
- `400 Bad Request`: 잘못된 요청
- `404 Not Found`: 리소스를 찾을 수 없음
- `500 Internal Server Error`: 서버 내부 오류

---

## 페이지 URL 목록

| 페이지 | URL | 설명 |
|--------|-----|------|
| 메인 페이지 | `/` | 플랫폼 소개 및 전체 메뉴 |
| KTX 예약 | `/ktx` | KTX 열차 예약 페이지 |
| 지하철 | `/subway` | 지하철 실시간 정보 |
| 버스 | `/bus` | 버스 실시간 정보 |
| 공유 모빌리티 | `/bike` | 따릉이/킥보드 지도 |
| 공영 주차장 | `/parking` | 주차장 검색 및 정보 |
| 대시보드 | `/dashboard` | 운영 대시보드 |
| 정책 관리 | `/policy` | 정책 관리 시스템 |
| 데이터 분석 | `/analytics` | 데이터 분석 대시보드 |
| 상권 연계 | `/shops` | 제휴 상점 정보 |
| 로그인 | `/login` | 사용자 로그인 |
| 회원가입 | `/register` | 사용자 회원가입 |
| 마이페이지 | `/profile` | 사용자 프로필 |

---

## 개발 환경 설정

### application.properties

```properties
# Server
server.port=9999

# Oracle Database
spring.datasource.url=jdbc:oracle:thin:@localhost:1521:xe
spring.datasource.username=system
spring.datasource.password=oracle
spring.datasource.driver-class-name=oracle.jdbc.OracleDriver

# JPA
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.Oracle12cDialect

# Thymeleaf
spring.thymeleaf.cache=false
spring.thymeleaf.prefix=classpath:/templates/
spring.thymeleaf.suffix=.html
```

---

## 빌드 및 실행

### Gradle 빌드

```bash
# 빌드 (테스트 제외)
./gradlew.bat clean build -x test

# 애플리케이션 실행
./gradlew.bat bootRun

# 백그라운드 실행
./gradlew.bat bootRun --no-daemon &
```

### 애플리케이션 상태 확인

```bash
# 프로세스 확인
jps -l | grep MobilityServiceApplication

# 포트 확인
netstat -ano | findstr :9999
```

---

## 문의 및 지원

- **개발팀**: K-MaaS Platform Team
- **이메일**: contact@k-maas.kr
- **프로젝트**: Spring Boot 풀스택 개발 과정 팀 프로젝트

---

**최종 업데이트**: 2026-01-12
