
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Migrator {
    public static void main(String[] args) {
        try {
            List<String> outputLines = new ArrayList<>();

            // [1] Reset Schema
            outputLines.add("-- [1] Reset Schema");
            outputLines.add("BEGIN");
            outputLines.add("    FOR r IN (SELECT table_name FROM user_tables WHERE table_name IN ('TB_INFRA_HUB', 'TB_KTX_SCHEDULE', 'TB_BOARD', 'TB_USER_ASSET')) LOOP");
            outputLines.add("        EXECUTE IMMEDIATE 'DROP TABLE ' || r.table_name || ' CASCADE CONSTRAINTS';");
            outputLines.add("    END LOOP;");
            outputLines.add("    FOR s IN (SELECT sequence_name FROM user_sequences WHERE sequence_name = 'MAAS_CORE_SEQ') LOOP");
            outputLines.add("        EXECUTE IMMEDIATE 'DROP SEQUENCE ' || s.sequence_name;");
            outputLines.add("    END LOOP;");
            outputLines.add("END;");
            outputLines.add("/");
            outputLines.add("");

            // [2] Create Sequence
            outputLines.add("-- [2] Sequence");
            outputLines.add("CREATE SEQUENCE MAAS_CORE_SEQ START WITH 1 INCREMENT BY 1;");
            outputLines.add("");

            // [3] Create Tables
            outputLines.add("-- [3] Tables");
            outputLines.add("CREATE TABLE TB_INFRA_HUB (");
            outputLines.add("    ID NUMBER PRIMARY KEY,");
            outputLines.add("    CATEGORY VARCHAR2(20),");
            outputLines.add("    TYPE_NAME VARCHAR2(50),");
            outputLines.add("    STATION_NAME VARCHAR2(100) NOT NULL,");
            outputLines.add("    LATITUDE NUMBER(15, 10),");
            outputLines.add("    LONGITUDE NUMBER(15, 10),");
            outputLines.add("    ADD_INFO VARCHAR2(500),");
            outputLines.add("    IS_TAGLESS NUMBER(1) DEFAULT 0");
            outputLines.add(");");
            outputLines.add("");
            outputLines.add("CREATE TABLE TB_KTX_SCHEDULE (SCH_ID NUMBER PRIMARY KEY, TRAIN_NO VARCHAR2(50), DEP_PLACE VARCHAR2(100), ARR_PLACE VARCHAR2(100), DEP_TIME VARCHAR2(10), ARR_TIME VARCHAR2(10), CHARGE NUMBER);");
            outputLines.add("CREATE TABLE TB_BOARD (BNO NUMBER PRIMARY KEY, TITLE VARCHAR2(200), CONTENT CLOB, WRITER VARCHAR2(50), REGDATE DATE DEFAULT SYSDATE);");
            outputLines.add("CREATE TABLE TB_USER_ASSET (USER_ID NUMBER PRIMARY KEY, MILEAGE_POINT NUMBER DEFAULT 0, K_PASS_YN VARCHAR2(1) DEFAULT 'N');");
            outputLines.add("");

            // [4] Data Migration
            outputLines.add("-- [4] Data Migration");

            processFile("insert_subway_stations.sql", outputLines);
            processFile("integrate_subway_data.sql", outputLines);

            // Test Data
            outputLines.add("INSERT INTO TB_INFRA_HUB (ID, CATEGORY, TYPE_NAME, STATION_NAME, LATITUDE, LONGITUDE, ADD_INFO, IS_TAGLESS) VALUES (MAAS_CORE_SEQ.NEXTVAL, 'PARKING', '공영', '부평역 주차장', 37.4898, 126.7250, '{\"spaces\": 45}', 0);");
            outputLines.add("INSERT INTO TB_INFRA_HUB (ID, CATEGORY, TYPE_NAME, STATION_NAME, LATITUDE, LONGITUDE, ADD_INFO, IS_TAGLESS) VALUES (MAAS_CORE_SEQ.NEXTVAL, 'BIKE', '따릉이', '부평역 1번출구', 37.4895, 126.7251, '{\"count\": 12}', 0);");
            outputLines.add("INSERT INTO TB_KTX_SCHEDULE (SCH_ID, TRAIN_NO, DEP_PLACE, ARR_PLACE, DEP_TIME, ARR_TIME, CHARGE) VALUES (MAAS_CORE_SEQ.NEXTVAL, 'KTX 001', '서울', '부산', '09:00', '11:30', 59800);");
            outputLines.add("INSERT INTO TB_USER_ASSET (USER_ID, MILEAGE_POINT, K_PASS_YN) VALUES (1, 5000, 'Y');");
            outputLines.add("COMMIT;");

            Files.write(Paths.get("data.sql"), outputLines, StandardCharsets.UTF_8);
            System.out.println("Migration complete. Output written to data.sql");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Set<String> seen = new HashSet<>();

    private static void processFile(String fname, List<String> outputLines) throws IOException {
        Path path = Paths.get(fname);
        if (!Files.exists(path)) {
            System.out.println("Skipping " + fname + " (not found)");
            return;
        }

        String content = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
        
        // Regex to find VALUES (...);
        // Pattern matches: VALUES \s* \( (.*?) \);
        Pattern p = Pattern.compile("VALUES\\s*\\((.*?)\\);", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(content);

        while (m.find()) {
            String valStr = m.group(1).replace("\n", " ");
            List<String> parts = parseCsv(valStr);

            String stationName = "";
            String lineName = "";
            double lat = 0.0;
            double lon = 0.0;
            int tagless = 0;

            if (fname.contains("insert_subway_stations.sql")) {
                // (SEQ, STATION_NAME, LINE_NUMBER, LAT, LON, TRANSFER_LINES)
                if (parts.size() >= 6) {
                    stationName = parts.get(1);
                    String lineRaw = parts.get(2);
                    try {
                        lat = Double.parseDouble(parts.get(3));
                        lon = Double.parseDouble(parts.get(4));
                    } catch (NumberFormatException e) { continue; }
                    lineName = parseLineName(lineRaw);
                }
            } else if (fname.contains("integrate_subway_data.sql")) {
                // (SEQ, LINE_NAME, STATION_NAME, LAT, LON, CODE, TAGLESS)
                if (parts.size() >= 5) {
                    String lineRaw = parts.get(1);
                    stationName = parts.get(2);
                    try {
                        lat = Double.parseDouble(parts.get(3));
                        lon = Double.parseDouble(parts.get(4));
                    } catch (NumberFormatException e) { continue; }
                    lineName = parseLineName(lineRaw);
                    if (parts.size() >= 7 && parts.get(6).trim().matches("\\d+")) {
                        tagless = Integer.parseInt(parts.get(6).trim());
                    }
                }
            }

            if (stationName.isEmpty() || lineName.isEmpty()) continue;

            // Logic
            if (lineName.contains("수인선") || lineName.contains("분당선")) {
                lineName = "수인분당선";
            }

            if (lineName.equals("1호선")) {
                lineName = classifyLine1(stationName);
            }

            String normLine = lineName.trim();
            String normName = normalizeStationName(stationName);
            String combo = normLine + "|" + normName;

            if (seen.contains(combo)) continue;
            seen.add(combo);

            String dbStationName = formatStationName(stationName);
            
            String sql = String.format("INSERT INTO TB_INFRA_HUB (ID, CATEGORY, TYPE_NAME, STATION_NAME, LATITUDE, LONGITUDE, ADD_INFO, IS_TAGLESS) VALUES (MAAS_CORE_SEQ.NEXTVAL, 'SUBWAY', '%s', '%s', %.6f, %.6f, '{}', %d);",
                    normLine, dbStationName, lat, lon, tagless);
            outputLines.add(sql);
        }
    }

    private static List<String> parseCsv(String line) {
        List<String> result = new ArrayList<>();
        boolean inQuotes = false;
        StringBuilder current = new StringBuilder();
        for (char c : line.toCharArray()) {
            if (c == '\'') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                result.add(current.toString().trim().replace("'", "")); // strip quotes roughly
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }
        result.add(current.toString().trim().replace("'", ""));
        return result;
    }

    private static String parseLineName(String raw) {
        raw = raw.replace("'", "").trim();
        if (raw.matches("\\d+")) return raw + "호선";
        return raw;
    }

    private static String normalizeStationName(String name) {
        String n = name.replace("'", "").trim();
        if (n.endsWith("역")) return n.substring(0, n.length() - 1);
        return n;
    }

    private static String formatStationName(String name) {
        String n = name.replace("'", "").trim();
        if (!n.endsWith("역")) return n + "역";
        return n;
    }

    private static String classifyLine1(String name) {
        String n = normalizeStationName(name);
        Set<String> gyeongin = new HashSet<>(Arrays.asList("인천", "동인천", "도원", "제물포", "도화", "주안", "간석", "동암", "백운", "부평", "부개", "송내", "중동", "부천", "소사", "역곡", "온수", "오류동", "개봉", "구일"));
        Set<String> gyeongbu = new HashSet<>(Arrays.asList("금천구청", "석수", "관악", "안양", "명학", "금정", "군포", "당정", "의왕", "성균관대", "화서", "수원", "세류", "병점", "세마", "오산대", "오산", "진위", "송탄", "서정리", "평택지제", "평택", "성환", "직산", "두정", "천안", "봉명", "쌍용", "아산", "탕정", "배방", "온양온천", "신창", "서동탄"));

        if (gyeongin.contains(n)) return "1호선(경인)";
        if (gyeongbu.contains(n)) return "1호선(경부)";
        return "1호선(서울)";
    }
}
