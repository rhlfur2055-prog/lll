# 🎬 K-MaaS 시연 가이드 (Demo Script)

이 문서는 K-MaaS 프로젝트의 성공적인 시연을 위한 단계별 시나리오입니다.

## 1. 준비 사항

- [ ] **서버 실행**: `run.bat` 실행 후 `Started Application` 로그 확인
- [ ] **브라우저 준비**: Chrome 브라우저 실행 (시크릿 모드 권장)
- [ ] **DB 확인**: 초기 데이터 로딩 완료 확인 (로그에 "지하철 역 데이터 ... 저장됨" 확인)

---

## 2. 시연 시나리오

### SCENE 1: 접속 및 메인 화면 (Web)
1. **[Action]** `http://localhost:9999` 접속
2. **[Check]** 지도 로딩 확인 (서울역 중심)
3. **[Check]** 좌측 사이드바 표시 (검색창, 카테고리 칩)
4. **[Check]** 마커 표시 (지하철, KTX 등)

### SCENE 2: 통합 검색
1. **[Action]** 검색창에 "강남" 입력 후 엔터
2. **[Effect]** 지도 중심이 강남역으로 이동
3. **[Effect]** 검색 결과 리스트에 "강남역", "강남구청역" 등 표시
4. **[Action]** 리스트에서 "강남역" 클릭
5. **[Effect]** 인포윈도우 팝업 (도착 정보 로딩)

### SCENE 3: 실시간 지하철 정보
1. **[Action]** 지하철 마커(또는 검색 결과) 클릭
2. **[Effect]** 실시간 도착 정보 표시 (예: "당고개행 2분 후")
3. **[Note]** "실시간 데이터 연동 성공" 강조

### SCENE 4: 모바일 경험 (Mobile)
1. **[Action]** F12 눌러 개발자 도구 열기 -> 모바일 아이콘 클릭 (iPhone SE/12 등 선택)
2. **[Action]** 새로고침 (F5)
3. **[Check]** 모바일 전용 UI (하단 탭바, 바텀 시트) 확인
4. **[Action]** '내 주변' 탭 터치 -> 마일리지 적립 팝업 확인

### SCENE 5: 주차 및 QR
1. **[Action]** 카테고리 칩에서 '주차장' 선택
2. **[Action]** 지도에 표시된 주차장 마커 클릭
3. **[Effect]** 주차장 상세 정보 및 "QR 입차" 버튼 표시
4. **[Action]** (API 테스트) Postman 등으로 QR 생성 API 호출 시연 가능

---

## 3. 주요 API 테스트 (Console)

시연 중 문제가 생기거나 백엔드 검증이 필요한 경우 사용하세요.

**지하철 목록 조회**
```bash
curl http://localhost:9999/api/stations?category=SUBWAY
```

**검색**
```bash
curl http://localhost:9999/api/search?keyword=서울
```

**마일리지 적립**
```bash
curl -X POST "http://localhost:9999/api/kpass/earn?userId=1&serviceType=SUBWAY&distanceKm=10"
```
