# 📡 K-MaaS API Reference

K-MaaS 플랫폼에서 제공하는 REST API 명세서입니다.
Base URL: `http://localhost:9999`

---

## 1. Station & Map (교통 시설/정보)

### 📍 전체 정류장/역 조회
지도에 마커를 표시하기 위해 데이터를 가져옵니다.

- **URL**: `/api/stations`
- **Method**: `GET`
- **Query Params**:
  - `category` (Optional): `SUBWAY`, `BUS`, `KTX`, `DATA`, `PARKING` (없으면 전체)
- **Response**:
  ```json
  [
    {
      "id": 1,
      "name": "서울역",
      "type": "SUBWAY",
      "lat": 37.5546,
      "lng": 126.9706,
      "line": "1호선"
    },
    ...
  ]
  ```

### 🔍 통합 검색
키워드로 역, 정류장, 주차장 등을 검색합니다.

- **URL**: `/api/search`
- **Method**: `GET`
- **Query Params**:
  - `keyword`: 검색어 (예: "강남")
- **Response**: `List<StationDTO>`

### ⏱️ 실시간 도착 정보
특정 역의 실시간 열차 도착 정보를 조회합니다.

- **URL**: `/api/stations/{stationName}/realtime`
- **Method**: `GET`
- **Response**:
  ```json
  {
    "stationName": "강남",
    "arrivals": [
      {
        "trainNo": "2020",
        "arrivalTime": "3분 20초",
        "direction": "성수행"
      }
    ]
  }
  ```

---

## 2. K-Pass (마일리지)

### 💰 마일리지 적립
이동 거리에 따라 마일리지를 적립합니다.

- **URL**: `/api/kpass/earn`
- **Method**: `POST`
- **Query Params**:
  - `userId`: 사용자 ID
  - `serviceType`: `SUBWAY`, `BUS`, `KTX`
  - `distanceKm`: 이동 거리 (km)
- **Response**:
  ```json
  {
    "success": true,
    "earnedPoints": 100,
    "totalMileage": 500
  }
  ```

---

## 3. Parking (주차)

### 🎟️ 입차 QR 생성
입차 시 스캔할 QR 코드를 생성합니다.

- **URL**: `/api/parking/qr/entry`
- **Method**: `POST`
- **Query Params**:
  - `userId`, `parkingLotId`, `carNumber`
- **Response**: QR 코드 Base64 이미지 및 메타데이터

---

## 4. Error Handling

- **500 Internal Server Error**: 서버 로직 오류 혹은 DB 연결 실패
- **400 Bad Request**: 파라미터 누락 혹은 잘못된 형식
- **404 Not Found**: 존재하지 않는 리소스
