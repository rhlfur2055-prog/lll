package com.maas.service.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.maas.service.entity.BikeStation;
import com.maas.service.service.BikeService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 공유 모빌리티 컨트롤러 (Real API)
 * 따릉이, 킥보드 등 공유 이동수단 정보 제공
 */
@Controller
@RequiredArgsConstructor
@Slf4j
public class BikeController {

    private final BikeService bikeService;

    @Value("${kakao.js.key}")
    private String kakaoJsKey;

    /**
     * 따릉이 메인 페이지
     */
    @GetMapping("/bike")
    public String bikePage(Model model) {
        model.addAttribute("pageTitle", "따릉이 - K-MaaS");
        model.addAttribute("kakaoKey", kakaoJsKey != null ? kakaoJsKey : "TEST_KEY");
        return "bike";
    }

    /**
     * 대여소 검색 API (Real API)
     * 500 에러 방지: 예외 발생 시 빈 리스트 반환
     */
    @GetMapping("/api/bike/stations/search")
    @ResponseBody
    public ResponseEntity<List<BikeStation>> searchStations(@RequestParam String keyword) {
        try {
            log.info("Searching bike stations: {}", keyword);
            List<BikeStation> stations = bikeService.searchStations(keyword);
            return ResponseEntity.ok(stations != null ? stations : new ArrayList<>());
        } catch (Exception e) {
            log.error("Error searching stations: {}", e.getMessage());
            return ResponseEntity.ok(new ArrayList<>());
        }
    }

    /**
     * 주변 대여소 조회 API (Real API)
     * 500 에러 방지: 예외 발생 시 빈 리스트 반환
     */
    @GetMapping("/api/bike/stations/nearby")
    @ResponseBody
    public ResponseEntity<List<BikeStation>> getNearbyStations(
            @RequestParam Double latitude,
            @RequestParam Double longitude,
            @RequestParam(defaultValue = "2.0") Double radius) {
        try {
            log.info("Getting nearby stations: lat={}, lon={}, radius={}", latitude, longitude, radius);
            List<BikeStation> stations = bikeService.getNearbyStations(latitude, longitude, radius);
            return ResponseEntity.ok(stations != null ? stations : new ArrayList<>());
        } catch (Exception e) {
            log.error("Error getting nearby stations: {}", e.getMessage());
            return ResponseEntity.ok(new ArrayList<>());
        }
    }

    /**
     * 전체 대여소 조회 API
     * 500 에러 방지: 예외 발생 시 빈 리스트 반환
     */
    @GetMapping("/api/bike/stations/all")
    @ResponseBody
    public ResponseEntity<List<BikeStation>> getAllStations() {
        try {
            List<BikeStation> stations = bikeService.getAllStations();
            return ResponseEntity.ok(stations != null ? stations : new ArrayList<>());
        } catch (Exception e) {
            log.error("Error getting all stations: {}", e.getMessage());
            return ResponseEntity.ok(new ArrayList<>());
        }
    }

    /**
     * 대여소 데이터 업데이트 API
     */
    @PostMapping("/api/bike/stations/update")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> updateBikeData() {
        try {
            log.info("Updating bike station data");
            bikeService.updateBikeDataFromAPI();
            long stationCount = bikeService.getAllStations().size();
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "자전거 대여소 데이터 업데이트 완료",
                "stationCount", stationCount
            ));
        } catch (Exception e) {
            log.error("Error updating bike data: {}", e.getMessage());
            return ResponseEntity.ok(Map.of("success", false, "message", "업데이트 실패: " + e.getMessage()));
        }
    }
}
