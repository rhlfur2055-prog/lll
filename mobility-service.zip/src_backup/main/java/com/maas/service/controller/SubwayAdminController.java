package com.maas.service.controller;

import com.maas.service.repository.SubwayStationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/admin/subway")
@RequiredArgsConstructor
@Slf4j
public class SubwayAdminController {

    private final SubwayStationRepository subwayStationRepository;

    @PostMapping("/init-all-lines")
    public ResponseEntity<?> initAllSubwayLines() {
        log.info("지하철 데이터 초기화 요청됨");
        
        // 하드코딩 데이터 생성 로직 제거됨
        // DB 초기화는 resources/insert_init_data.sql 스크립트를 사용해야 함
        
        long totalCount = subwayStationRepository.count();
        log.info("현재 저장된 지하철 역 수: {}", totalCount);

        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "DB 데이터 확인 완료 (초기화는 SQL 스크립트를 사용하세요)",
                "totalCount", totalCount
        ));
    }
}
