package com.maas.service.controller;

import com.maas.service.dto.MapLocationDto;
import com.maas.service.repository.InfraRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 지도 데이터 API 컨트롤러
 * 모든 교통 인프라 위치 정보를 제공
 */
@RestController
@RequestMapping("/api/map")
@RequiredArgsConstructor
@Slf4j
public class MapDataController {

    private final InfraRepository infraRepository;

    /**
     * 모든 역/정류장 정보 조회
     */
    @GetMapping("/stations")
    public List<MapLocationDto> getAllStations() {
        log.info("지도 데이터 요청 수신");
        
        return infraRepository.findAll().stream()
            .map(infra -> MapLocationDto.builder()
                .name(infra.getStationName())
                .latitude(infra.getLatitude())
                .longitude(infra.getLongitude())
                .type(infra.getCategory())
                .lineName(infra.getTypeName())  // typeName 사용
                .address(infra.getAddInfo())
                .build())
            .collect(Collectors.toList());
    }

    /**
     * 카테고리별 정보 조회
     */
    @GetMapping("/stations/{category}")
    public List<MapLocationDto> getStationsByCategory(@PathVariable String category) {
        log.info("카테고리별 지도 데이터 요청: {}", category);
        
        return infraRepository.findByCategory(category.toUpperCase()).stream()
            .map(infra -> MapLocationDto.builder()
                .name(infra.getStationName())
                .latitude(infra.getLatitude())
                .longitude(infra.getLongitude())
                .type(infra.getCategory())
                .lineName(infra.getTypeName())  // typeName 사용
                .address(infra.getAddInfo())
                .build())
            .collect(Collectors.toList());
    }
}
