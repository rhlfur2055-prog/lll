package com.maas.service.controller;

import com.maas.service.entity.User;
import com.maas.service.repository.UserRepository;
import com.maas.service.service.KPassService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 태그리스 결제 API 컨트롤러
 * 부평역 핵심 기능 - 마일리지 즉시 적립
 */
@RestController
@RequestMapping("/api/tagless")
@RequiredArgsConstructor
@Slf4j
public class TaglessPaymentController {

    private final KPassService kpassService;
    private final UserRepository userRepository;

    /**
     * 태그리스 결제 시뮬레이션
     * 실제 결제는 하지 않고 K-Pass 마일리지만 적립
     */
    @PostMapping("/earn")
    public ResponseEntity<Map<String, Object>> earnMileage(@RequestBody Map<String, String> request) {
        try {
            String stationName = request.get("station");
            Long userId = Long.parseLong(request.getOrDefault("userId", "1")); // 기본 테스트 사용자
            
            log.info("태그리스 결제 요청: 역={}, 사용자={}", stationName, userId);
            
            // K-Pass 마일리지 적립 (지하철 이용)
            String transportType = "SUBWAY";
            int fare = 1400; // 기본 지하철 요금
            String routeInfo = stationName + "역 탑승";
            
            int earnedPoints = kpassService.earnPointsWithPolicy(userId, transportType, fare, routeInfo);
            
            // 현재 잔액 조회
            int currentBalance = kpassService.getBalance(userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", stationName + "역 태그리스 결제 완료!");
            response.put("earnedPoints", earnedPoints);
            response.put("currentBalance", currentBalance);
            response.put("station", stationName);
            
            log.info("태그리스 결제 성공: {}P 적립, 현재 잔액 {}P", earnedPoints, currentBalance);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("태그리스 결제 실패: {}", e.getMessage(), e);
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "결제 처리 중 오류가 발생했습니다");
            errorResponse.put("error", e.getMessage());
            
            return ResponseEntity.ok(errorResponse);
        }
    }

    /**
     * 사용자 마일리지 조회
     */
    @GetMapping("/balance/{userId}")
    public ResponseEntity<Map<String, Object>> getBalance(@PathVariable Long userId) {
        try {
            int balance = kpassService.getBalance(userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("userId", userId);
            response.put("balance", balance);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "잔액 조회 실패");
            
            return ResponseEntity.ok(errorResponse);
        }
    }
}
