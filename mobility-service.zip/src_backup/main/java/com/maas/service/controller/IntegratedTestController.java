package com.maas.service.controller;

import com.maas.service.domain.highway.HighwayService;
import com.maas.service.domain.highway.HighwayEntity;
import com.maas.service.domain.ktx.KtxService;
import com.maas.service.domain.ktx.KtxEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/test")
@RequiredArgsConstructor
@Slf4j
public class IntegratedTestController {

    private final HighwayService highwayService;
    private final KtxService ktxService;

    @GetMapping("/highway")
    public ResponseEntity<?> testHighway() {
        log.info("Testing Highway Domain...");
        // 실제 API 키가 유효하지 않을 수 있으므로, Mock 데이터 저장 메서드를 호출하여 DB 연동 확인
        HighwayEntity result = highwayService.createMockDataAndSave("서울", "부산");
        
        return ResponseEntity.ok(Map.of(
                "success", true,
                "domain", "Highway",
                "data", result,
                "message", "HIGHWAY_TOLL_INFO 테이블 저장 성공"
        ));
    }

    @GetMapping("/ktx")
    public ResponseEntity<?> testKtx() {
        log.info("Testing KTX Domain...");
        KtxEntity result = ktxService.createMockDataAndSave("서울", "부산");

        return ResponseEntity.ok(Map.of(
                "success", true,
                "domain", "KTX",
                "data", result,
                "message", "KTX_TRAIN_INFO 테이블 저장 성공"
        ));
    }
}
