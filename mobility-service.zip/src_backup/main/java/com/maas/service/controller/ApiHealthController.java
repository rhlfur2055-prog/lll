package com.maas.service.controller;

import com.maas.service.service.integration.EnhancedPublicDataClient;
import com.maas.service.service.integration.EnhancedSeoulMetroClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * API 헬스체크 및 모니터링 컨트롤러
 * 모든 외부 API의 상태를 실시간으로 모니터링
 */
@Slf4j
@RestController
@RequestMapping("/api/health")
public class ApiHealthController {

    @Autowired(required = false)
    private EnhancedSeoulMetroClient seoulMetroClient;

    @Autowired(required = false)
    private EnhancedPublicDataClient publicDataClient;

    /**
     * 전체 API 헬스 체크
     */
    @GetMapping("")
    public Map<String, Object> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        health.put("service", "K-MaaS Platform");
        health.put("version", "1.0.0");

        // API 메트릭 수집
        Map<String, Object> apis = new HashMap<>();

        if (seoulMetroClient != null) {
            apis.put("seoulMetro", seoulMetroClient.getAllMetrics());
        }


        if (publicDataClient != null) {
            apis.put("publicData", publicDataClient.getAllMetrics());
        }

        health.put("apiMetrics", apis);

        return health;
    }

    /**
     * 서울 지하철 API 상태
     */
    @GetMapping("/metro")
    public Map<String, Object> metroHealth() {
        Map<String, Object> health = new HashMap<>();
        health.put("api", "Seoul Metro");
        health.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        if (seoulMetroClient != null) {
            health.put("metrics", seoulMetroClient.getAllMetrics());
            health.put("status", "UP");
        } else {
            health.put("status", "NOT_CONFIGURED");
            health.put("message", "Seoul Metro client not available");
        }

        return health;
    }


    /**
     * 공공데이터포털 API 상태
     */
    @GetMapping("/public-data")
    public Map<String, Object> publicDataHealth() {
        Map<String, Object> health = new HashMap<>();
        health.put("api", "Public Data Portal");
        health.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        if (publicDataClient != null) {
            health.put("metrics", publicDataClient.getAllMetrics());
            health.put("status", "UP");
        } else {
            health.put("status", "NOT_CONFIGURED");
            health.put("message", "Public Data client not available");
        }

        return health;
    }

    /**
     * 간단한 상태 체크 (로드밸런서용)
     */
    @GetMapping("/ping")
    public Map<String, Object> ping() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "OK");
        response.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        return response;
    }

    /**
     * 상세 시스템 정보
     */
    @GetMapping("/info")
    public Map<String, Object> systemInfo() {
        Map<String, Object> info = new HashMap<>();

        // 시스템 정보
        info.put("service", "K-MaaS (Korea Mobility as a Service)");
        info.put("version", "1.0.0");
        info.put("build", "2025-01-12");
        info.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        // JVM 정보
        Runtime runtime = Runtime.getRuntime();
        Map<String, Object> jvm = new HashMap<>();
        jvm.put("maxMemory", runtime.maxMemory() / 1024 / 1024 + " MB");
        jvm.put("totalMemory", runtime.totalMemory() / 1024 / 1024 + " MB");
        jvm.put("freeMemory", runtime.freeMemory() / 1024 / 1024 + " MB");
        jvm.put("usedMemory", (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024 + " MB");
        jvm.put("processors", runtime.availableProcessors());
        info.put("jvm", jvm);

        // API 클라이언트 상태
        Map<String, String> clients = new HashMap<>();
        clients.put("seoulMetro", seoulMetroClient != null ? "Available" : "Not configured");
        clients.put("publicData", publicDataClient != null ? "Available" : "Not configured");
        info.put("apiClients", clients);

        return info;
    }

    /**
     * 통합 대시보드 데이터
     */
    @GetMapping("/dashboard")
    public Map<String, Object> dashboard() {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        // 전체 API 메트릭 요약
        Map<String, Object> summary = new HashMap<>();
        int totalApis = 0;
        int activeApis = 0;
        long totalCalls = 0;
        long totalSuccessCalls = 0;

        if (seoulMetroClient != null) {
            totalApis++;
            activeApis++;
            Map<String, Map<String, Object>> metrics = seoulMetroClient.getAllMetrics();
            for (Map<String, Object> metric : metrics.values()) {
                totalCalls += (long) metric.getOrDefault("totalCalls", 0L);
                totalSuccessCalls += (long) metric.getOrDefault("successCalls", 0L);
            }
        }


        if (publicDataClient != null) {
            totalApis++;
            activeApis++;
            Map<String, Map<String, Object>> metrics = publicDataClient.getAllMetrics();
            for (Map<String, Object> metric : metrics.values()) {
                totalCalls += (long) metric.getOrDefault("totalCalls", 0L);
                totalSuccessCalls += (long) metric.getOrDefault("successCalls", 0L);
            }
        }

        summary.put("totalApiClients", totalApis);
        summary.put("activeApiClients", activeApis);
        summary.put("totalApiCalls", totalCalls);
        summary.put("successfulCalls", totalSuccessCalls);
        summary.put("overallSuccessRate", totalCalls > 0 ?
                String.format("%.2f%%", (totalSuccessCalls * 100.0 / totalCalls)) : "N/A");

        dashboard.put("summary", summary);

        // 개별 API 상태
        Map<String, Object> apis = new HashMap<>();
        if (seoulMetroClient != null) {
            apis.put("seoulMetro", Map.of(
                    "status", "UP",
                    "metrics", seoulMetroClient.getAllMetrics()
            ));
        }
        if (publicDataClient != null) {
            apis.put("publicData", Map.of(
                    "status", "UP",
                    "metrics", publicDataClient.getAllMetrics()
            ));
        }

        dashboard.put("apis", apis);

        return dashboard;
    }
}
