package com.maas.service.controller;

import com.maas.service.repository.MobilityHubRepository;
import com.maas.service.service.integration.SeoulMetroRealtimeClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Controller
@RequiredArgsConstructor
public class IntegratedCoreController {

    private final MobilityHubRepository mobilityRepo;
    private final SeoulMetroRealtimeClient realtimeClient;

    // 1. 메인 페이지 Routing
    @GetMapping("/")
    public String mainPage(@RequestHeader(value = "User-Agent", defaultValue = "") String ua, Model model) {
        if (ua.toLowerCase().contains("mobile")) return "mobile/index";
        return "web/index"; // dashboard -> index로 변경 (Frontend 일치)
    }
    
    // 2. 검색 페이지
    @GetMapping("/search")
    public String searchPage() { return "search"; }
    
    // 3. 모바일 카테고리
    @GetMapping("/mobile/{category}")
    public String mobileCategoryPage(@PathVariable String category, Model model) {
        model.addAttribute("category", category.toUpperCase());
        return "mobile/index";
    }

    // ==========================================
    // REST APIs
    // ==========================================

    // 4. 전체 역/시설 조회 (필터링 지원)
    @GetMapping("/api/stations")
    @ResponseBody
    public Object getStations(@RequestParam(required = false) String category) {
        if (category != null && !category.equals("ALL")) {
            return mobilityRepo.findByCategoryOrderByLineNameAscStationNameAsc(category);
        }
        return mobilityRepo.findAll();
    }

    // 5. 지하철 노선 목록 조회 (그룹핑용)
    @GetMapping("/api/lines")
    @ResponseBody
    public Map<String, Object> getSubwayLines() {
        List<Object[]> results = mobilityRepo.countStationsByLine();
        List<Map<String, Object>> lines = new ArrayList<>();

        for (Object[] row : results) {
            String lineName = (String) row[0];
            Long count = (Long) row[1];
            
            Map<String, Object> lineMap = new HashMap<>();
            lineMap.put("lineName", lineName);
            lineMap.put("stationCount", count);
            lineMap.put("color", getLineColor(lineName));
            lines.add(lineMap);
        }
        return Map.of("lines", lines);
    }

    // 6. 노선별 역 조회
    @GetMapping("/api/stations/by-line")
    @ResponseBody
    public Object getStationsByLine(@RequestParam String line) {
        return mobilityRepo.findByLineNameOrderByStationNameAsc(line);
    }
    
    // 7. 실시간 도착 정보 (Frontend: /api/stations/{name}/realtime)
    @GetMapping("/api/stations/{stationName}/realtime")
    @ResponseBody
    public Object getRealtimeStation(@PathVariable String stationName) {
        log.info("실시간 도착 정보 요청: {}", stationName);
        // "역" 제거 로직
        String cleanName = stationName.endsWith("역") ? 
            stationName.substring(0, stationName.length() - 1) : stationName;
        return realtimeClient.getRealtimeArrival(cleanName);
    }
    
    // 8. 통합 검색 API
    @GetMapping("/api/search")
    @ResponseBody
    public Map<String, Object> search(@RequestParam String keyword) {
        return Map.of("results", mobilityRepo.findByStationNameContainingOrderByLineName(keyword));
    }

    // Helper: 노선 색상 매핑
    private String getLineColor(String lineName) {
        if (lineName.contains("1호선")) return "#0052A4";
        if (lineName.contains("2호선")) return "#00A84D";
        if (lineName.contains("3호선")) return "#EF7C1C";
        if (lineName.contains("4호선")) return "#00A5DE";
        if (lineName.contains("5호선")) return "#996CAC";
        if (lineName.contains("6호선")) return "#CD7C2F";
        if (lineName.contains("7호선")) return "#747F00";
        if (lineName.contains("8호선")) return "#E6186C";
        if (lineName.contains("9호선")) return "#BDB092";
        if (lineName.contains("인천1")) return "#7CA8D5";
        if (lineName.contains("인천2")) return "#ED8B00";
        if (lineName.contains("수인분당")) return "#F5A200";
        if (lineName.contains("신분당")) return "#D4003B";
        if (lineName.contains("경의중앙")) return "#77C4A3";
        if (lineName.contains("공항")) return "#0090D2";
        if (lineName.contains("경춘")) return "#0C8E72";
        return "#999999";
    }
}