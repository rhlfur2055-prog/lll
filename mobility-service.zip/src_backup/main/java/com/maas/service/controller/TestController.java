package com.maas.service.controller;

import com.maas.service.domain.highway.HighwayEntity;
import com.maas.service.domain.highway.HighwayService;
import com.maas.service.domain.ktx.KtxEntity;
import com.maas.service.domain.ktx.KtxService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/test")
@RequiredArgsConstructor
@Slf4j
public class TestController {

    private final HighwayService highwayService;
    private final KtxService ktxService;

    // 1. 엔드포인트: /test/highway/save?entry=서울&exit=부산
    @GetMapping("/highway/save")
    public ResponseEntity<?> testHighwaySave(
            @RequestParam("entry") String entry,
            @RequestParam("exit") String exit) {
        
        log.info("Test Request: Highway Save [{} -> {}]", entry, exit);
        try {
            // Service 호출 -> API (Mock) -> DB Insert -> Return Entity
            HighwayEntity result = highwayService.fetchAndSaveTollInfo(entry, exit);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "고속도로 통행료 저장 완료");
            response.put("data", result);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Highway Test Error", e);
            // 500 에러 방지용 JSON 리턴
            return ResponseEntity.ok(Map.of(
                    "success", false,
                    "message", "API 통신 실패: " + e.getMessage()
            ));
        }
    }

    // 2. 엔드포인트: /test/ktx/search?dep=서울&arr=부산
    @GetMapping("/ktx/search")
    public ResponseEntity<?> testKtxSearch(
            @RequestParam("dep") String dep,
            @RequestParam("arr") String arr) {
        
        log.info("Test Request: KTX Search [{} -> {}]", dep, arr);
        try {
            // Service 호출 -> API (Mock) -> DB Insert (5 rows) -> Return List
            List<KtxEntity> results = ktxService.fetchAndSaveTrainInfo(dep, arr);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "KTX 열차 조회 및 저장 완료 (" + results.size() + "건)");
            response.put("data", results);
            
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("KTX Test Error", e);
            // 500 에러 방지용 JSON 리턴
            return ResponseEntity.ok(Map.of(
                    "success", false,
                    "message", "API 통신 실패: " + e.getMessage()
            ));
        }
    }
}
