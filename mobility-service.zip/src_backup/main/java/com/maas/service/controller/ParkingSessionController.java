package com.maas.service.controller;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.maas.service.entity.ParkingSession;
import com.maas.service.repository.ParkingSessionRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 주차 세션 API 컨트롤러
 * QR 코드 기반 입출차 관리 시스템
 */
@RestController
@RequestMapping("/api/parking")
@RequiredArgsConstructor
@Slf4j
public class ParkingSessionController {

    private final ParkingSessionRepository parkingSessionRepository;

    /**
     * 입차 등록 (급지 정보 포함)
     */
    @PostMapping("/entry")
    public ResponseEntity<Map<String, Object>> createEntry(@RequestBody Map<String, Object> request) {
        log.info("입차 등록 요청: {}", request);

        try {
            Long userId = request.get("userId") != null ?
                Long.valueOf(request.get("userId").toString()) : null;
            String carNumber = (String) request.get("carNumber");
            String parkingLotId = (String) request.get("parkingLotId");
            String parkingLotName = (String) request.get("parkingLotName");
            Double latitude = request.get("latitude") != null ?
                Double.valueOf(request.get("latitude").toString()) : null;
            Double longitude = request.get("longitude") != null ?
                Double.valueOf(request.get("longitude").toString()) : null;

            // 주차장 급지 정보 (기본값: GRADE_3)
            String parkingGrade = request.get("parkingGrade") != null ?
                (String) request.get("parkingGrade") : "GRADE_3";

            // QR 코드 생성
            String qrCode = generateQRCode(carNumber);

            // 주차 세션 생성
            ParkingSession session = ParkingSession.builder()
                    .userId(userId)
                    .carNumber(carNumber)
                    .parkingLotId(parkingLotId)
                    .parkingLotName(parkingLotName)
                    .entryTime(LocalDateTime.now())
                    .qrCode(qrCode)
                    .paymentStatus("PENDING")
                    .latitude(latitude)
                    .longitude(longitude)
                    .parkingGrade(parkingGrade)
                    .freeMinutes(15) // 15분 무료
                    .build();

            session = parkingSessionRepository.save(session);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("sessionId", session.getSessionId());
            response.put("qrCode", qrCode);
            response.put("entryTime", session.getEntryTime());
            response.put("parkingGrade", parkingGrade);
            response.put("message", "입차가 완료되었습니다.");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("입차 등록 실패", e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "입차 등록 중 오류가 발생했습니다.");
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    /**
     * 출차 처리 (급지별 요금 + 차량 할인 적용)
     */
    @PostMapping("/exit")
    public ResponseEntity<Map<String, Object>> processExit(@RequestBody Map<String, Object> request) {
        log.info("출차 처리 요청: {}", request);

        try {
            Long sessionId = Long.valueOf(request.get("sessionId").toString());
            Optional<ParkingSession> sessionOpt = parkingSessionRepository.findById(sessionId);

            if (!sessionOpt.isPresent()) {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("success", false);
                errorResponse.put("message", "주차 세션을 찾을 수 없습니다.");
                return ResponseEntity.badRequest().body(errorResponse);
            }

            ParkingSession session = sessionOpt.get();
            session.setExitTime(LocalDateTime.now());

            // 급지별 요금 계산
            String parkingGrade = session.getParkingGrade() != null ? session.getParkingGrade() : "GRADE_3";
            int baseFee = calculateFeeWithGrade(session.getEntryTime(), session.getExitTime(), parkingGrade);
            session.setParkingFee(baseFee);

            // 차량 할인 적용
            Boolean isDisabled = request.get("isDisabled") != null ?
                (Boolean) request.get("isDisabled") : false;
            Boolean isEco = request.get("isEco") != null ?
                (Boolean) request.get("isEco") : false;

            session.setIsDisabledDiscount(isDisabled);
            session.setIsEcoDiscount(isEco);

            int finalFee = applyVehicleDiscount(baseFee, isDisabled, isEco);
            session.setFinalFee(finalFee);

            // 할인 사유 기록
            StringBuilder discountReason = new StringBuilder();
            if (isDisabled) {
                discountReason.append("장애인 할인 50%; ");
            }
            if (isEco) {
                discountReason.append("친환경 할인 30%; ");
            }
            if (discountReason.length() > 0) {
                session.setDiscountReason(discountReason.toString());
            }

            // 할인율 계산
            int discountRate = baseFee > 0 ? ((baseFee - finalFee) * 100 / baseFee) : 0;
            session.setDiscountRate(discountRate);

            parkingSessionRepository.save(session);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("sessionId", session.getSessionId());
            response.put("entryTime", session.getEntryTime());
            response.put("exitTime", session.getExitTime());
            response.put("parkingGrade", parkingGrade);
            response.put("baseFee", baseFee);
            response.put("discountRate", discountRate);
            response.put("finalFee", finalFee);
            response.put("discountReason", session.getDiscountReason());
            response.put("message", "출차 처리가 완료되었습니다.");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("출차 처리 실패", e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "출차 처리 중 오류가 발생했습니다.");
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    /**
     * 주차 현황 조회
     */
    @GetMapping("/status/{userId}")
    public ResponseEntity<Map<String, Object>> getParkingStatus(@PathVariable Long userId) {
        log.info("주차 현황 조회: userId={}", userId);

        Optional<ParkingSession> activeSession = parkingSessionRepository.findActiveSessionByUserId(userId);

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);

        if (activeSession.isPresent()) {
            ParkingSession session = activeSession.get();
            response.put("hasActiveSession", true);
            response.put("session", convertSessionToMap(session));

            // 현재까지의 주차 시간 계산
            long minutes = Duration.between(session.getEntryTime(), LocalDateTime.now()).toMinutes();
            response.put("parkedMinutes", minutes);

            // 현재까지의 예상 요금 계산
            int currentFee = calculateParkingFee(session.getEntryTime(), LocalDateTime.now());
            response.put("currentFee", currentFee);
        } else {
            response.put("hasActiveSession", false);
        }

        return ResponseEntity.ok(response);
    }

    /**
     * 요금 계산
     */
    @PostMapping("/calculate-fee")
    public ResponseEntity<Map<String, Object>> calculateFee(@RequestBody Map<String, Object> request) {
        try {
            Long sessionId = Long.valueOf(request.get("sessionId").toString());
            Optional<ParkingSession> sessionOpt = parkingSessionRepository.findById(sessionId);

            if (!sessionOpt.isPresent()) {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("success", false);
                errorResponse.put("message", "주차 세션을 찾을 수 없습니다.");
                return ResponseEntity.badRequest().body(errorResponse);
            }

            ParkingSession session = sessionOpt.get();
            LocalDateTime exitTime = session.getExitTime() != null ?
                session.getExitTime() : LocalDateTime.now();

            int fee = calculateParkingFee(session.getEntryTime(), exitTime);
            long minutes = Duration.between(session.getEntryTime(), exitTime).toMinutes();

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("parkingFee", fee);
            response.put("parkedMinutes", minutes);
            response.put("parkedHours", minutes / 60.0);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("요금 계산 실패", e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "요금 계산 중 오류가 발생했습니다.");
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    /**
     * QR 코드 생성
     */
    @PostMapping("/qr/generate")
    public ResponseEntity<Map<String, Object>> generateQR(@RequestBody Map<String, Object> request) {
        String carNumber = (String) request.get("carNumber");
        String qrCode = generateQRCode(carNumber);

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("qrCode", qrCode);

        return ResponseEntity.ok(response);
    }

    /**
     * QR 코드 스캔 (가상)
     */
    @PostMapping("/qr/scan")
    public ResponseEntity<Map<String, Object>> scanQR(@RequestBody Map<String, Object> request) {
        String qrCode = (String) request.get("qrCode");

        Optional<ParkingSession> sessionOpt = parkingSessionRepository.findByQrCode(qrCode);

        Map<String, Object> response = new HashMap<>();

        if (sessionOpt.isPresent()) {
            ParkingSession session = sessionOpt.get();
            response.put("success", true);
            response.put("session", convertSessionToMap(session));

            // 현재 요금 계산
            if (session.getExitTime() == null) {
                int currentFee = calculateParkingFee(session.getEntryTime(), LocalDateTime.now());
                response.put("currentFee", currentFee);
            }
        } else {
            response.put("success", false);
            response.put("message", "유효하지 않은 QR 코드입니다.");
        }

        return ResponseEntity.ok(response);
    }

    /**
     * 주차 이력 조회
     */
    @GetMapping("/history/{userId}")
    public ResponseEntity<List<ParkingSession>> getParkingHistory(@PathVariable Long userId) {
        List<ParkingSession> history = parkingSessionRepository.findByUserIdOrderByEntryTimeDesc(userId);
        return ResponseEntity.ok(history);
    }

    // ============================================
    // Private Helper Methods
    // ============================================

    /**
     * QR 코드 생성
     */
    private String generateQRCode(String carNumber) {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String uuid = UUID.randomUUID().toString().substring(0, 8);
        return String.format("PARK_%s_%s_%s", carNumber, timestamp, uuid);
    }

    /**
     * 주차 요금 계산 (급지별)
     * 기본: 30분 1000원
     * 추가: 10분당 500원
     */
    private int calculateParkingFee(LocalDateTime entryTime, LocalDateTime exitTime) {
        long totalMinutes = Duration.between(entryTime, exitTime).toMinutes();

        if (totalMinutes <= 0) {
            return 0;
        }

        // 기본 30분
        int baseFee = 1000;

        if (totalMinutes <= 30) {
            return baseFee;
        }

        // 추가 시간 계산 (10분 단위)
        long additionalMinutes = totalMinutes - 30;
        long additionalUnits = (long) Math.ceil(additionalMinutes / 10.0);
        int additionalFee = (int) (additionalUnits * 500);

        return baseFee + additionalFee;
    }

    /**
     * 급지별 주차 요금 계산
     * @param entryTime 입차 시간
     * @param exitTime 출차 시간
     * @param grade 주차장 급지 (GRADE_1, GRADE_2, GRADE_3)
     * @return 기본 주차 요금
     */
    private int calculateFeeWithGrade(LocalDateTime entryTime, LocalDateTime exitTime, String grade) {
        // 15분 이내 무료
        long minutes = Duration.between(entryTime, exitTime).toMinutes();
        if (minutes <= 15) {
            return 0;
        }

        int baseFee, additionalFee, maxDailyFee;

        switch (grade) {
            case "GRADE_1": // 1급지 (강남, 여의도)
                baseFee = 2000;      // 30분 기본
                additionalFee = 1000; // 10분당
                maxDailyFee = 50000;
                break;
            case "GRADE_2": // 2급지 (일반 도심)
                baseFee = 1500;
                additionalFee = 700;
                maxDailyFee = 30000;
                break;
            case "GRADE_3": // 3급지 (외곽)
                baseFee = 1000;
                additionalFee = 500;
                maxDailyFee = 20000;
                break;
            default:
                baseFee = 1000;
                additionalFee = 500;
                maxDailyFee = 20000;
        }

        // 30분 기본 요금
        int totalFee = baseFee;

        // 30분 초과 시 추가 요금 계산
        if (minutes > 30) {
            long additionalMinutes = minutes - 30;
            long additionalBlocks = (long) Math.ceil(additionalMinutes / 10.0);
            totalFee += (int)(additionalBlocks * additionalFee);
        }

        // 일일 최대 요금 제한
        if (totalFee > maxDailyFee) {
            totalFee = maxDailyFee;
        }

        return totalFee;
    }

    /**
     * 차량별 할인 적용
     * @param baseFee 기본 요금
     * @param isDisabled 장애인 차량 여부
     * @param isEco 친환경 차량 여부
     * @return 최종 요금
     */
    private int applyVehicleDiscount(int baseFee, boolean isDisabled, boolean isEco) {
        double discountRate = 0.0;

        if (isDisabled) {
            discountRate += 0.50; // 50%
        }

        if (isEco) {
            discountRate += 0.30; // 30%
        }

        // 최대 할인율 80%
        if (discountRate > 0.80) {
            discountRate = 0.80;
        }

        int discountAmount = (int)(baseFee * discountRate);
        return baseFee - discountAmount;
    }

    /**
     * 세션을 Map으로 변환
     */
    private Map<String, Object> convertSessionToMap(ParkingSession session) {
        Map<String, Object> map = new HashMap<>();
        map.put("sessionId", session.getSessionId());
        map.put("carNumber", session.getCarNumber());
        map.put("parkingLotId", session.getParkingLotId());
        map.put("parkingLotName", session.getParkingLotName());
        map.put("entryTime", session.getEntryTime());
        map.put("exitTime", session.getExitTime());
        map.put("qrCode", session.getQrCode());
        map.put("parkingFee", session.getParkingFee());
        map.put("paymentStatus", session.getPaymentStatus());
        map.put("discountRate", session.getDiscountRate());
        map.put("finalFee", session.getFinalFee());
        map.put("latitude", session.getLatitude());
        map.put("longitude", session.getLongitude());
        return map;
    }
}
