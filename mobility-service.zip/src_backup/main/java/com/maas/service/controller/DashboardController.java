package com.maas.service.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.maas.service.repository.UserRepository;
import com.maas.service.repository.UsageRepository;
import com.maas.service.entity.UsageRecord;

import java.util.*;

/**
 * 대시보드 컨트롤러
 * 운영 현황, KPI, 정책 시뮬레이션 상태 제공
 */
@Controller
@RequestMapping("/dashboard")
public class DashboardController {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private UsageRepository usageRepository;

    @Value("${kakao.js.key}")
    private String kakaoJsKey;

    /**
     * 대시보드 메인 페이지
     */
    @GetMapping("")
    public String dashboardMain(Model model) {
        model.addAttribute("pageTitle", "대시보드 - K-MaaS");
        model.addAttribute("kakaoKey", kakaoJsKey);
        model.addAttribute("kpis", getKPIs()); // Keep KPIs calling the DB-aware method
        model.addAttribute("policyStatus", getPolicyStatus());
        model.addAttribute("recentActivities", getRecentActivitiesInDto()); // DB driven
        model.addAttribute("topStations", getTopStations());
        return "dashboard";
    }

    /**
     * KPI 데이터 API
     */
    @GetMapping("/api/kpis")
    @ResponseBody
    public Map<String, Object> getKPIData() {
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("kpis", getKPIs());
        result.put("lastUpdate", new Date());
        return result;
    }

    /**
     * 실시간 통계 API
     */
    @GetMapping("/api/stats")
    @ResponseBody
    public Map<String, Object> getRealtimeStats() {
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        
        // REAL DB DATA
        long totalUsers = userRepository.count();
        long policyApplied = usageRepository.countByPolicyApplied("1");
        Double avgPoints = userRepository.findAveragePoints();
        long activeNow = usageRepository.countTodayUsage(); // Proxying "Active/Usage Today"

        result.put("totalUsers", totalUsers);
        result.put("activeNow", activeNow);
        result.put("policyApplied", policyApplied);
        result.put("avgPoints", avgPoints != null ? avgPoints.intValue() : 0);
        
        return result;
    }

    // KPI 데이터 (DB 연동)
    private List<Map<String, Object>> getKPIs() {
        List<Map<String, Object>> kpis = new ArrayList<>();

        long totalUsers = userRepository.count();
        long policyApplied = usageRepository.countByPolicyApplied("1");
        Double avgPointsVal = userRepository.findAveragePoints();
        int avgPoints = avgPointsVal != null ? avgPointsVal.intValue() : 0;
        
        // Formatting numbers
        String userStr = String.format("%,d", totalUsers);
        String policyStr = String.format("%,d", policyApplied);
        String pointStr = String.format("%,dpt", avgPoints);

        // Assuming some static growth trends for visual consistency alongside real data
        kpis.add(createKPI("총 회원 수", userStr, "+12.3%", "up", "지난주 대비"));
        kpis.add(createKPI("정책 적용 건수", policyStr, "+18.7%", "up", "지난주 대비"));
        kpis.add(createKPI("평균 포인트", pointStr, "+8.2%", "up", "지난주 대비"));
        kpis.add(createKPI("서비스 만족도", "4.8/5.0", "-", "neutral", "변동 없음")); 

        return kpis;
    }

    private Map<String, Object> createKPI(String label, String value, String change, String trend, String period) {
        Map<String, Object> kpi = new HashMap<>();
        kpi.put("label", label);
        kpi.put("value", value);
        kpi.put("change", change);
        kpi.put("trend", trend);
        kpi.put("period", period);
        return kpi;
    }

    // 최근 활동 (DB 연동)
    private List<Map<String, Object>> getRecentActivitiesInDto() {
        List<Map<String, Object>> activities = new ArrayList<>();
        
        // Fetch real logs
        List<UsageRecord> records = usageRepository.findTop5ByOrderByUsageTimeDesc();
        
        for (UsageRecord r : records) {
             String type = r.getTransportType();
             String msg = String.format("%s 이용 (%s)", r.getRouteInfo(), r.getRegion());
             // Simple time diff logic or just exact time
             String time = r.getUsageTime().toString().replace("T", " ").substring(0, 16); 
             
             activities.add(createActivity(type, msg, time));
        }

        if (activities.isEmpty()) {
             activities.add(createActivity("시스템", "최근 이용 기록이 없습니다.", "-"));
        }
        
        return activities;
    }

    // 정책 상태
    private List<Map<String, Object>> getPolicyStatus() {
        List<Map<String, Object>> policies = new ArrayList<>();

        policies.add(createPolicy("비혼잡 시간대 인센티브", true, "69개 역", "2025.01.06 ~ 2025.01.31"));
        policies.add(createPolicy("상권 연계 할인", false, "12개 제휴점", "준비 중"));
        policies.add(createPolicy("친환경 이동 보너스", false, "환경부 연계", "계획 중"));
        policies.add(createPolicy("역 혼잡도 기반 조정", false, "AI 기반", "개발 중"));

        return policies;
    }

    private Map<String, Object> createPolicy(String name, boolean active, String scope, String period) {
        Map<String, Object> policy = new HashMap<>();
        policy.put("name", name);
        policy.put("active", active);
        policy.put("scope", scope);
        policy.put("period", period);
        return policy;
    }

    // 최근 활동
    private List<Map<String, Object>> getRecentActivities() {
        List<Map<String, Object>> activities = new ArrayList<>();

        activities.add(createActivity("정책 변경", "비혼잡 시간대 가중치 2.0x → 2.5x 변경", "5분 전"));
        activities.add(createActivity("신규 제휴점", "부평역 카페 '리브로' 등록 완료", "15분 전"));
        activities.add(createActivity("시스템", "일일 정산 완료 - 5,981건 처리", "1시간 전"));
        activities.add(createActivity("알림", "부평역 이용량 전일 대비 15% 증가", "2시간 전"));

        return activities;
    }

    private Map<String, Object> createActivity(String type, String message, String time) {
        Map<String, Object> activity = new HashMap<>();
        activity.put("type", type);
        activity.put("message", message);
        activity.put("time", time);
        return activity;
    }

    // 상위 역
    private List<Map<String, Object>> getTopStations() {
        List<Map<String, Object>> stations = new ArrayList<>();

        stations.add(createStation(1, "부평역", 1247, 854, 68.5, 158));
        stations.add(createStation(2, "인천역", 982, 671, 68.3, 152));
        stations.add(createStation(3, "수원역", 756, 518, 68.5, 150));
        stations.add(createStation(4, "의정부역", 623, 427, 68.5, 148));
        stations.add(createStation(5, "동인천역", 512, 351, 68.6, 155));

        return stations;
    }

    private Map<String, Object> createStation(int rank, String name, int total, int applied, double rate, int avgPoints) {
        Map<String, Object> station = new HashMap<>();
        station.put("rank", rank);
        station.put("name", name);
        station.put("total", total);
        station.put("applied", applied);
        station.put("rate", rate);
        station.put("avgPoints", avgPoints);
        return station;
    }
}
