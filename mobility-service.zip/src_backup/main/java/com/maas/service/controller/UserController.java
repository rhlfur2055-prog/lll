package com.maas.service.controller;

import com.maas.service.entity.PointTransaction;
import com.maas.service.entity.User;
import com.maas.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
@Slf4j
public class UserController {

    private final UserService userService;

    /**
     * 회원가입 페이지
     */
    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("pageTitle", "회원가입 - K-MaaS");
        return "register";
    }

    /**
     * 프로필 페이지
     */
    @GetMapping("/profile")
    public String profilePage(Model model) {
        model.addAttribute("pageTitle", "내 프로필 - K-MaaS");
        return "profile";
    }

    /**
     * 현재 로그인한 사용자 정보 조회 API
     * 세션 기반 인증이 구현되면 실제 사용자 반환
     */
    @GetMapping("/api/user/current")
    @ResponseBody
    public ResponseEntity<?> getCurrentUser() {
        // TODO: 실제 세션에서 사용자 정보 가져오기
        // 현재는 비로그인 상태로 빈 응답 반환
        return ResponseEntity.ok().build();
    }

    /**
     * 회원가입 API
     */
    @PostMapping("/api/users/register")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> register(@RequestBody Map<String, String> request) {
        try {
            String name = request.get("name");
            String email = request.get("email");
            String password = request.get("password");
            String phone = request.get("phone");

            User user = userService.register(name, email, password, phone);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "회원가입 성공! 1000P를 드렸습니다.");
            response.put("user", user);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Register failed", e);
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 로그인 API
     */
    @PostMapping("/api/users/login")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> request) {
        try {
            String email = request.get("email");
            String password = request.get("password");

            Optional<User> user = userService.login(email, password);

            Map<String, Object> response = new HashMap<>();

            if (user.isPresent()) {
                response.put("success", true);
                response.put("message", "로그인 성공");
                response.put("user", user.get());
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "이메일 또는 비밀번호가 잘못되었습니다");
                return ResponseEntity.status(401).body(response);
            }

        } catch (Exception e) {
            log.error("Login failed", e);
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "로그인 중 오류가 발생했습니다");
            return ResponseEntity.status(500).body(response);
        }
    }

    /**
     * 사용자 정보 조회 API
     */
    @GetMapping("/api/users/{userId}")
    @ResponseBody
    public ResponseEntity<?> getUser(@PathVariable Long userId) {
        Optional<User> user = userService.getUserById(userId);

        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * 포인트 내역 조회 API
     */
    @GetMapping("/api/users/{userId}/points/history")
    @ResponseBody
    public ResponseEntity<List<PointTransaction>> getPointHistory(@PathVariable Long userId) {
        List<PointTransaction> history = userService.getPointHistory(userId);
        return ResponseEntity.ok(history);
    }

    /**
     * 포인트 적립 API
     */
    @PostMapping("/api/users/{userId}/points/earn")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> earnPoints(
            @PathVariable Long userId,
            @RequestBody Map<String, Object> request) {
        try {
            Integer amount = (Integer) request.get("amount");
            String reason = (String) request.get("reason");

            userService.earnPoints(userId, amount, reason);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", amount + "P가 적립되었습니다");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Earn points failed", e);
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 포인트 사용 API
     */
    @PostMapping("/api/users/{userId}/points/use")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> usePoints(
            @PathVariable Long userId,
            @RequestBody Map<String, Object> request) {
        try {
            Integer amount = (Integer) request.get("amount");
            String reason = (String) request.get("reason");

            userService.usePoints(userId, amount, reason);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", amount + "P를 사용했습니다");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Use points failed", e);
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
}
