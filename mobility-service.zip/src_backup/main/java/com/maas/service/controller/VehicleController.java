package com.maas.service.controller;

import com.maas.service.entity.Vehicle;
import com.maas.service.repository.VehicleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 차량 관리 API 컨트롤러
 */
@RestController
@RequestMapping("/api/vehicles")
@RequiredArgsConstructor
@Slf4j
public class VehicleController {

    private final VehicleRepository vehicleRepository;

    /**
     * 차량 등록
     *
     * POST /api/vehicles/register
     */
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> registerVehicle(@RequestBody Map<String, Object> request) {
        log.info("[차량 등록] 요청: {}", request);

        try {
            Long userId = Long.valueOf(request.get("userId").toString());
            String vehicleNumber = (String) request.get("vehicleNumber");
            String vehicleType = (String) request.get("vehicleType");
            Integer vehicleClass = request.get("vehicleClass") != null ?
                    Integer.valueOf(request.get("vehicleClass").toString()) : 2;
            Boolean isElectric = (Boolean) request.getOrDefault("isElectric", false);
            Boolean isDisabled = (Boolean) request.getOrDefault("isDisabled", false);
            Boolean isEcoFriendly = (Boolean) request.getOrDefault("isEcoFriendly", false);

            // 차량번호 중복 체크
            if (vehicleRepository.findByVehicleNumber(vehicleNumber).isPresent()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "이미 등록된 차량번호입니다.");
                return ResponseEntity.badRequest().body(response);
            }

            Vehicle vehicle = Vehicle.builder()
                    .userId(userId)
                    .vehicleNumber(vehicleNumber)
                    .vehicleType(vehicleType)
                    .vehicleClass(vehicleClass)
                    .isElectric(isElectric)
                    .isDisabled(isDisabled)
                    .isEcoFriendly(isEcoFriendly)
                    .isActive(true)
                    .registeredAt(LocalDateTime.now())
                    .build();

            vehicle = vehicleRepository.save(vehicle);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("vehicleId", vehicle.getVehicleId());
            response.put("vehicleNumber", vehicle.getVehicleNumber());
            response.put("message", "차량이 등록되었습니다.");

            log.info("[차량 등록 성공] 사용자: {}, 차량번호: {}", userId, vehicleNumber);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[차량 등록 실패] {}", e.getMessage(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 사용자별 차량 목록 조회
     *
     * GET /api/vehicles/user/{userId}
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Vehicle>> getUserVehicles(@PathVariable Long userId) {
        log.info("[차량 목록 조회] 사용자: {}", userId);

        try {
            List<Vehicle> vehicles = vehicleRepository.findByUserIdAndIsActiveTrue(userId);

            log.info("[차량 목록 조회 성공] 사용자: {}, 차량 수: {}", userId, vehicles.size());

            return ResponseEntity.ok(vehicles);

        } catch (Exception e) {
            log.error("[차량 목록 조회 실패] {}", e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 차량번호로 조회
     *
     * GET /api/vehicles/search?vehicleNumber=12가3456
     */
    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> searchVehicle(@RequestParam String vehicleNumber) {
        log.info("[차량 조회] 차량번호: {}", vehicleNumber);

        try {
            Vehicle vehicle = vehicleRepository.findByVehicleNumber(vehicleNumber)
                    .orElseThrow(() -> new RuntimeException("등록되지 않은 차량입니다"));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("vehicle", vehicle);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[차량 조회 실패] {}", e.getMessage());

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 차량 정보 수정
     *
     * PUT /api/vehicles/{vehicleId}
     */
    @PutMapping("/{vehicleId}")
    public ResponseEntity<Map<String, Object>> updateVehicle(
            @PathVariable Long vehicleId,
            @RequestBody Map<String, Object> request
    ) {
        log.info("[차량 수정] ID: {}, 요청: {}", vehicleId, request);

        try {
            Vehicle vehicle = vehicleRepository.findById(vehicleId)
                    .orElseThrow(() -> new RuntimeException("차량을 찾을 수 없습니다"));

            // 수정 가능한 필드 업데이트
            if (request.containsKey("vehicleType")) {
                vehicle.setVehicleType((String) request.get("vehicleType"));
            }
            if (request.containsKey("vehicleClass")) {
                vehicle.setVehicleClass(Integer.valueOf(request.get("vehicleClass").toString()));
            }
            if (request.containsKey("isElectric")) {
                vehicle.setIsElectric((Boolean) request.get("isElectric"));
            }
            if (request.containsKey("isDisabled")) {
                vehicle.setIsDisabled((Boolean) request.get("isDisabled"));
            }
            if (request.containsKey("isEcoFriendly")) {
                vehicle.setIsEcoFriendly((Boolean) request.get("isEcoFriendly"));
            }

            vehicle = vehicleRepository.save(vehicle);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("vehicle", vehicle);
            response.put("message", "차량 정보가 수정되었습니다.");

            log.info("[차량 수정 성공] ID: {}", vehicleId);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[차량 수정 실패] {}", e.getMessage(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 차량 삭제 (비활성화)
     *
     * DELETE /api/vehicles/{vehicleId}
     */
    @DeleteMapping("/{vehicleId}")
    public ResponseEntity<Map<String, Object>> deleteVehicle(@PathVariable Long vehicleId) {
        log.info("[차량 삭제] ID: {}", vehicleId);

        try {
            Vehicle vehicle = vehicleRepository.findById(vehicleId)
                    .orElseThrow(() -> new RuntimeException("차량을 찾을 수 없습니다"));

            vehicle.setIsActive(false);
            vehicleRepository.save(vehicle);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "차량이 삭제되었습니다.");

            log.info("[차량 삭제 성공] ID: {}", vehicleId);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[차량 삭제 실패] {}", e.getMessage(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 전기차 목록 조회
     *
     * GET /api/vehicles/electric
     */
    @GetMapping("/electric")
    public ResponseEntity<List<Vehicle>> getElectricVehicles() {
        log.info("[전기차 목록 조회]");

        try {
            List<Vehicle> vehicles = vehicleRepository.findByIsElectricTrue();

            return ResponseEntity.ok(vehicles);

        } catch (Exception e) {
            log.error("[전기차 목록 조회 실패] {}", e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 장애인 차량 목록 조회
     *
     * GET /api/vehicles/disabled
     */
    @GetMapping("/disabled")
    public ResponseEntity<List<Vehicle>> getDisabledVehicles() {
        log.info("[장애인 차량 목록 조회]");

        try {
            List<Vehicle> vehicles = vehicleRepository.findByIsDisabledTrue();

            return ResponseEntity.ok(vehicles);

        } catch (Exception e) {
            log.error("[장애인 차량 목록 조회 실패] {}", e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }
}
