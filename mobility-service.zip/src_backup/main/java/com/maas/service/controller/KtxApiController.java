package com.maas.service.controller;

import com.maas.service.domain.ktx.KtxService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * KTX API 컨트롤러 (모든 KTX 관련 요청은 여기서 처리합니다)
 */
@RestController
@RequestMapping("/api/ktx")
@RequiredArgsConstructor
@Slf4j
public class KtxApiController {

    private final KtxService ktxService;

    /**
     * KTX 열차 조회
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchTrains(
            @RequestParam(required = false) String dep,
            @RequestParam(required = false) String arr,
            @RequestParam(required = false, defaultValue = "2024-01-15") String date) {
        
        log.info("KTX 조회 요청: {} -> {}, 날짜: {}", dep, arr, date);
        
        try {
            // dep나 arr 중 하나라도 있으면 검색
            String depStation = dep != null ? dep : "서울";
            String arrStation = arr != null ? arr : "부산";
            
            var trains = ktxService.fetchAndSaveTrainInfo(depStation, arrStation);
            return ResponseEntity.ok(trains);
        } catch (Exception e) {
            log.error("KTX 조회 실패: {}", e.getMessage(), e);
            return ResponseEntity.ok(java.util.Collections.emptyList());
        }
    }

    /**
     * KTX 예약
     * 주소: POST /api/ktx/reserve
     */
    @PostMapping("/reserve")
    public ResponseEntity<Map<String, Object>> reserveTrain(@RequestBody Map<String, Object> reservationData) {
        log.info("KTX 예약 요청 수신: {}", reservationData);
        
        Map<String, Object> result = new HashMap<>();
        try {
            var reservation = ktxService.reserveTrain(reservationData);
            result.put("success", true);
            result.put("reservation", reservation);
        } catch (Exception e) {
            log.error("KTX 예약 실패: {}", e.getMessage());
            result.put("success", false);
            result.put("message", "예약 처리 중 오류가 발생했습니다.");
        }
        
        return ResponseEntity.ok(result);
    }
}