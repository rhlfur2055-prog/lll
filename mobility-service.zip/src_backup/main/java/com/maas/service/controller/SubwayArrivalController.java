package com.maas.service.controller;

import com.maas.service.service.integration.SeoulMetroRealtimeClient; // 패키지 경로 일치 확인
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j; // Logger 자동 생성
import org.springframework.http.ResponseEntity; // ResponseEntity 해결
import org.springframework.web.bind.annotation.*;

@Slf4j // log.info(), log.error() 사용 가능
@RestController
@RequestMapping("/api/subway")
@RequiredArgsConstructor
public class SubwayArrivalController {

    private final SeoulMetroRealtimeClient realtimeClient;

    @GetMapping("/arrival/{stationName}")
    public ResponseEntity<?> getArrivalInfo(@PathVariable String stationName) {
        log.info("지하철 실시간 도착 정보 요청: {}", stationName);
        
        try {
            // '역' 이름 정규화 (예: 부평역 -> 부평)
            String searchName = stationName.endsWith("역") ? 
                               stationName.substring(0, stationName.length() - 1) : stationName;

            var arrivalData = realtimeClient.getRealtimeArrival(searchName);
            return ResponseEntity.ok(arrivalData); // 정상 응답
            
        } catch (Exception e) {
            log.error("정보 조회 중 시스템 에러 발생: ", e);
            return ResponseEntity.internalServerError().body("데이터를 불러오지 못했습니다.");
        }
    }
}