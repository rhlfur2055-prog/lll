package com.maas.service.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 상권 연계 컨트롤러
 * 제휴 상점 관리, 통계, 지도 연동 기능 제공
 */
@Controller
@RequestMapping("/shops")
public class ShopController {

    @Value("${kakao.js.key}")
    private String kakaoJsKey;

    /**
     * 상권 연계 메인 페이지
     */
    @GetMapping("")
    public String shopsMain(Model model) {
        model.addAttribute("pageTitle", "상권 연계 - K-MaaS");
        model.addAttribute("kakaoKey", kakaoJsKey);
        model.addAttribute("stats", getShopStats());
        model.addAttribute("shops", getShops());
        return "shops";
    }

    /**
     * 상점 목록 API
     */
    @GetMapping("/api/list")
    @ResponseBody
    public Map<String, Object> getShopList(
            @RequestParam(defaultValue = "all") String category,
            @RequestParam(defaultValue = "all") String status) {

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("shops", getShops());
        result.put("totalCount", getShops().size());
        return result;
    }

    /**
     * 상점 상세 정보 API
     */
    @GetMapping("/api/{shopId}")
    @ResponseBody
    public Map<String, Object> getShopDetail(@PathVariable String shopId) {
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("shop", getShopById(shopId));
        return result;
    }

    /**
     * 상점 승인 API
     */
    @PostMapping("/api/approve")
    @ResponseBody
    public Map<String, Object> approveShop(@RequestParam String shopId) {
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("shopId", shopId);
        result.put("message", "제휴점이 승인되었습니다.");
        return result;
    }

    /**
     * 상점 삭제 API
     */
    @PostMapping("/api/delete")
    @ResponseBody
    public Map<String, Object> deleteShop(@RequestParam String shopId) {
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("shopId", shopId);
        result.put("message", "제휴점이 삭제되었습니다.");
        return result;
    }

    /**
     * 상점 등록 API
     */
    @PostMapping("/api/register")
    @ResponseBody
    public Map<String, Object> registerShop(
            @RequestParam String name,
            @RequestParam String category,
            @RequestParam String address,
            @RequestParam String phone,
            @RequestParam int discountRate) {

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("shopId", "SHOP" + System.currentTimeMillis());
        result.put("message", "새 제휴점이 등록되었습니다. 관리자 승인 후 활성화됩니다.");
        return result;
    }

    /**
     * 상점 수정 API
     */
    @PostMapping("/api/update")
    @ResponseBody
    public Map<String, Object> updateShop(
            @RequestParam String shopId,
            @RequestParam String name,
            @RequestParam String category,
            @RequestParam String address,
            @RequestParam String phone,
            @RequestParam int discountRate) {

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("shopId", shopId);
        result.put("message", "상점 정보가 수정되었습니다.");
        return result;
    }

    // 통계 데이터
    private Map<String, Object> getShopStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalShops", 12);
        stats.put("activeShops", 10);
        stats.put("totalUsage", 2341);
        stats.put("avgDiscount", 15);
        return stats;
    }

    // 상점 목록
    private List<Map<String, Object>> getShops() {
        List<Map<String, Object>> shops = new ArrayList<>();

        shops.add(createShop("S001", "부평 커피하우스", "음식점", "부평역 2번 출구 도보 3분",
                "032-1234-5678", 15, true, 247, 4.8, "2025-01-03"));

        shops.add(createShop("S002", "행복 베이커리", "디저트", "부평역 1번 출구 도보 5분",
                "032-2345-6789", 10, true, 189, 4.6, "2025-01-04"));

        shops.add(createShop("S003", "북카페 리브로", "카페", "부평역 3번 출구 도보 2분",
                "032-3456-7890", 20, true, 312, 4.9, "2025-01-02"));

        shops.add(createShop("S004", "피트니스 짐", "운동", "부평역 지하 상가",
                "032-4567-8901", 25, true, 156, 4.7, "2025-01-05"));

        shops.add(createShop("S005", "편의점 GS25", "편의점", "부평역 4번 출구 앞",
                "032-5678-9012", 5, true, 423, 4.5, "2025-01-01"));

        shops.add(createShop("S006", "치킨마을", "음식점", "부평역 2번 출구 도보 7분",
                "032-6789-0123", 12, false, 0, 0.0, "2025-01-08"));

        return shops;
    }

    private Map<String, Object> createShop(String id, String name, String category, String address,
                                            String phone, int discountRate, boolean active,
                                            int usageCount, double rating, String registeredDate) {
        Map<String, Object> shop = new HashMap<>();
        shop.put("id", id);
        shop.put("name", name);
        shop.put("category", category);
        shop.put("categoryIcon", getCategoryIcon(category));
        shop.put("address", address);
        shop.put("phone", phone);
        shop.put("discountRate", discountRate);
        shop.put("active", active);
        shop.put("usageCount", usageCount);
        shop.put("rating", rating);
        shop.put("registeredDate", registeredDate);
        return shop;
    }

    private String getCategoryIcon(String category) {
        switch (category) {
            case "음식점": return "🍴";
            case "디저트": return "🍰";
            case "카페": return "📚";
            case "운동": return "💪";
            case "편의점": return "🏪";
            default: return "🏪";
        }
    }

    private Map<String, Object> getShopById(String shopId) {
        for (Map<String, Object> shop : getShops()) {
            if (shop.get("id").equals(shopId)) {
                return shop;
            }
        }
        return new HashMap<>();
    }
}
