package com.maas.service.controller;
public class KtxController {}
