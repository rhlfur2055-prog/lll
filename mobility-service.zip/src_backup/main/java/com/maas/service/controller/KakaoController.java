package com.maas.service.controller;

import com.maas.service.service.KakaoService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 카카오 API 연동 컨트롤러
 */
@RestController
@RequestMapping("/api/kakao")
@RequiredArgsConstructor
@Slf4j
public class KakaoController {

    private final KakaoService kakaoService;

    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> searchPlace(@RequestParam String keyword) {
        log.info("Kakao Place Search: {}", keyword);
        return ResponseEntity.ok(kakaoService.searchPlace(keyword));
    }
}
