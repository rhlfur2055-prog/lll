package com.maas.service.controller;

import com.maas.service.entity.TollRecord;
import com.maas.service.service.HighwayTollService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 고속도로 통행료 API 컨트롤러
 * 한국도로공사 API 기반 통행료 계산 및 관리
 */
@RestController
@RequestMapping("/api/highway")
@RequiredArgsConstructor
@Slf4j
public class HighwayTollController {

    private final HighwayTollService highwayTollService;

    /**
     * 고속도로 진입 등록
     *
     * POST /api/highway/entry
     * Body: { userId, vehicleNumber, entryTollgate, entryTollgateCode, routeName }
     */
    @PostMapping("/entry")
    public ResponseEntity<Map<String, Object>> recordEntry(@RequestBody Map<String, Object> request) {
        log.info("[고속도로 진입] 요청: {}", request);

        try {
            Long userId = Long.valueOf(request.get("userId").toString());
            String vehicleNumber = (String) request.get("vehicleNumber");
            String entryTollgate = (String) request.get("entryTollgate");
            String entryTollgateCode = (String) request.get("entryTollgateCode");
            String routeName = (String) request.get("routeName");

            TollRecord record = highwayTollService.recordEntry(
                    userId,
                    vehicleNumber,
                    entryTollgate,
                    entryTollgateCode,
                    routeName
            );

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("tollId", record.getTollId());
            response.put("vehicleNumber", record.getVehicleNumber());
            response.put("entryTollgate", record.getEntryTollgate());
            response.put("entryTime", record.getEntryTime());
            response.put("routeName", record.getRouteName());
            response.put("message", "고속도로 진입이 등록되었습니다.");

            log.info("[고속도로 진입 성공] 사용자: {}, 차량: {}, 톨게이트: {}",
                    userId, vehicleNumber, entryTollgate);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[고속도로 진입 실패] {}", e.getMessage(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 고속도로 출구 통과 및 통행료 계산
     *
     * POST /api/highway/exit
     * Body: { userId, exitTollgate, exitTollgateCode, paymentMethod, routeNo, distanceKm }
     */
    @PostMapping("/exit")
    public ResponseEntity<Map<String, Object>> recordExit(@RequestBody Map<String, Object> request) {
        log.info("[고속도로 출구] 요청: {}", request);

        try {
            Long userId = Long.valueOf(request.get("userId").toString());
            String exitTollgate = (String) request.get("exitTollgate");
            String exitTollgateCode = (String) request.get("exitTollgateCode");
            String paymentMethod = (String) request.get("paymentMethod"); // HIPASS, CASH, CARD
            String routeNo = (String) request.get("routeNo");
            Double distanceKm = Double.valueOf(request.get("distanceKm").toString());

            TollRecord record = highwayTollService.recordExit(
                    userId,
                    exitTollgate,
                    exitTollgateCode,
                    paymentMethod,
                    routeNo,
                    distanceKm
            );

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("tollId", record.getTollId());
            response.put("vehicleNumber", record.getVehicleNumber());
            response.put("entryTollgate", record.getEntryTollgate());
            response.put("exitTollgate", record.getExitTollgate());
            response.put("entryTime", record.getEntryTime());
            response.put("exitTime", record.getExitTime());
            response.put("distanceKm", record.getDistanceKm());
            response.put("baseFee", record.getBaseFee());
            response.put("discountAmount", record.getDiscountAmount());
            response.put("finalFee", record.getFinalFee());
            response.put("paymentMethod", record.getPaymentMethod());
            response.put("discountReason", record.getDiscountReason());
            response.put("isRushHour", record.getIsRushHour());
            response.put("message", "통행료가 계산되었습니다.");

            log.info("[고속도로 출구 성공] 사용자: {}, 최종 요금: {}원, 할인: {}원",
                    userId, record.getFinalFee(), record.getDiscountAmount());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[고속도로 출구 실패] {}", e.getMessage(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 통행료 사전 조회 (예상 요금)
     *
     * GET /api/highway/calculate?entryCode=001&exitCode=100&vehicleNumber=12가3456&routeNo=1&distanceKm=400
     */
    @GetMapping("/calculate")
    public ResponseEntity<String> calculateExpectedFee(
            @RequestParam String entryCode,
            @RequestParam String exitCode,
            @RequestParam String vehicleNumber,
            @RequestParam String routeNo,
            @RequestParam Double distanceKm
    ) {
        log.info("[예상 요금 조회] 차량: {}, 입구: {}, 출구: {}, 거리: {}km",
                vehicleNumber, entryCode, exitCode, distanceKm);

        try {
            String result = highwayTollService.calculateExpectedFee(
                    entryCode,
                    exitCode,
                    vehicleNumber,
                    routeNo,
                    distanceKm
            );

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            log.error("[예상 요금 조회 실패] {}", e.getMessage(), e);

            return ResponseEntity.badRequest().body(
                    "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}"
            );
        }
    }

    /**
     * 사용자별 통행 내역 조회
     *
     * GET /api/highway/history/{userId}
     */
    @GetMapping("/history/{userId}")
    public ResponseEntity<Map<String, Object>> getUserTollHistory(@PathVariable Long userId) {
        log.info("[통행 내역 조회] 사용자: {}", userId);

        try {
            List<TollRecord> history = highwayTollService.getUserTollHistory(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("userId", userId);
            response.put("count", history.size());
            response.put("history", history);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[통행 내역 조회 실패] {}", e.getMessage(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 차량별 통행 내역 조회
     *
     * GET /api/highway/history/vehicle/{vehicleNumber}
     */
    @GetMapping("/history/vehicle/{vehicleNumber}")
    public ResponseEntity<Map<String, Object>> getVehicleTollHistory(@PathVariable String vehicleNumber) {
        log.info("[차량 통행 내역 조회] 차량: {}", vehicleNumber);

        try {
            List<TollRecord> history = highwayTollService.getVehicleTollHistory(vehicleNumber);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("vehicleNumber", vehicleNumber);
            response.put("count", history.size());
            response.put("history", history);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[차량 통행 내역 조회 실패] {}", e.getMessage(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 월간 통행료 합계 조회
     *
     * GET /api/highway/monthly-sum/{userId}?year=2026&month=1
     */
    @GetMapping("/monthly-sum/{userId}")
    public ResponseEntity<Map<String, Object>> getMonthlyTollSum(
            @PathVariable Long userId,
            @RequestParam int year,
            @RequestParam int month
    ) {
        log.info("[월간 통행료 합계] 사용자: {}, 연월: {}-{}", userId, year, month);

        try {
            Integer totalFee = highwayTollService.getMonthlyTollSum(userId, year, month);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("userId", userId);
            response.put("year", year);
            response.put("month", month);
            response.put("totalFee", totalFee);
            response.put("message", String.format("%d년 %d월 총 통행료: %,d원", year, month, totalFee));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[월간 통행료 합계 조회 실패] {}", e.getMessage(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 헬스 체크
     *
     * GET /api/highway/health
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> healthCheck() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "Highway Toll System");
        response.put("message", "고속도로 통행료 시스템이 정상 작동 중입니다.");

        return ResponseEntity.ok(response);
    }
}
