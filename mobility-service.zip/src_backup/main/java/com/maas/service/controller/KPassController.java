package com.maas.service.controller;

import com.maas.service.entity.PointTransaction;
import com.maas.service.entity.UsageRecord;
import com.maas.service.entity.User;
import com.maas.service.repository.UserRepository;
import com.maas.service.service.KPassService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * K-Pass 마일리지 컨트롤러
 * K-Pass 잔액 조회, 포인트 적립/사용, QR 생성, 이용 내역
 */
@RestController
@RequestMapping("/api/kpass")
@RequiredArgsConstructor
@Slf4j
public class KPassController {

    private final KPassService kPassService;
    private final UserRepository userRepository;

    /**
     * K-Pass 잔액 조회
     * GET /api/kpass/balance/{userId}
     */
    @GetMapping("/balance/{userId}")
    public ResponseEntity<Map<String, Object>> getBalance(@PathVariable Long userId) {
        try {
            int balance = kPassService.getBalance(userId);

            User user = userRepository.findById(userId).orElse(null);
            String userName = user != null ? user.getName() : "Unknown";

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("userId", userId);
            response.put("userName", userName);
            response.put("balance", balance);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("[K-Pass] 잔액 조회 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * K-Pass 포인트 적립
     * POST /api/kpass/earn
     * Body: { userId, transportType, fare, routeInfo }
     */
    @PostMapping("/earn")
    public ResponseEntity<Map<String, Object>> earnPoints(@RequestBody Map<String, Object> request) {
        try {
            Long userId = Long.valueOf(request.get("userId").toString());
            String transportType = (String) request.get("transportType");
            int fare = Integer.parseInt(request.get("fare").toString());
            String routeInfo = (String) request.getOrDefault("routeInfo", "");

            int earnedPoints = kPassService.earnPointsWithPolicy(userId, transportType, fare, routeInfo);
            int newBalance = kPassService.getBalance(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("earnedPoints", earnedPoints);
            response.put("newBalance", newBalance);
            response.put("message", String.format("%dP 적립되었습니다", earnedPoints));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("[K-Pass] 포인트 적립 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * K-Pass 포인트 사용
     * POST /api/kpass/use
     * Body: { userId, points, reason }
     */
    @PostMapping("/use")
    public ResponseEntity<Map<String, Object>> usePoints(@RequestBody Map<String, Object> request) {
        try {
            Long userId = Long.valueOf(request.get("userId").toString());
            int points = Integer.parseInt(request.get("points").toString());
            String reason = (String) request.getOrDefault("reason", "포인트 사용");

            int usedPoints = kPassService.usePoints(userId, points, reason);
            int newBalance = kPassService.getBalance(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("usedPoints", usedPoints);
            response.put("newBalance", newBalance);
            response.put("message", String.format("%dP 사용되었습니다", usedPoints));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("[K-Pass] 포인트 사용 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * K-Pass 거래 내역 조회
     * GET /api/kpass/history/{userId}
     */
    @GetMapping("/history/{userId}")
    public ResponseEntity<Map<String, Object>> getHistory(@PathVariable Long userId) {
        try {
            List<PointTransaction> transactions = kPassService.getPointHistory(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("count", transactions.size());
            response.put("transactions", transactions);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("[K-Pass] 내역 조회 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * K-Pass 이용 기록 조회
     * GET /api/kpass/usage/{userId}
     */
    @GetMapping("/usage/{userId}")
    public ResponseEntity<Map<String, Object>> getUsageHistory(@PathVariable Long userId) {
        try {
            List<UsageRecord> records = kPassService.getUsageHistory(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("count", records.size());
            response.put("records", records);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("[K-Pass] 이용 기록 조회 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * K-Pass 월간 통계 조회
     * GET /api/kpass/stats/{userId}
     */
    @GetMapping("/stats/{userId}")
    public ResponseEntity<Map<String, Object>> getMonthlyStats(@PathVariable Long userId) {
        try {
            Map<String, Object> stats = kPassService.getMonthlyStats(userId);
            stats.put("success", true);
            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            log.error("[K-Pass] 통계 조회 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * K-Pass QR 코드 토큰 생성
     * POST /api/kpass/qr/generate
     * Body: { userId }
     */
    @PostMapping("/qr/generate")
    public ResponseEntity<Map<String, Object>> generateQR(@RequestBody Map<String, Object> request) {
        try {
            Long userId = Long.valueOf(request.get("userId").toString());

            String token = kPassService.generateQRToken(userId);
            int balance = kPassService.getBalance(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("token", token);
            response.put("balance", balance);
            response.put("validSeconds", 60); // 60초 유효

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("[K-Pass] QR 생성 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * K-Pass 할인 계산
     * GET /api/kpass/discount?userId=1&fare=1500&transportType=SUBWAY
     */
    @GetMapping("/discount")
    public ResponseEntity<Map<String, Object>> calculateDiscount(
            @RequestParam Long userId,
            @RequestParam int fare,
            @RequestParam String transportType) {
        try {
            int discountAmount = kPassService.calculateDiscount(userId, fare, transportType);
            int finalFare = fare - discountAmount;

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("originalFare", fare);
            response.put("discountAmount", discountAmount);
            response.put("finalFare", finalFare);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("[K-Pass] 할인 계산 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }
}
