package com.maas.service.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maas.service.service.StationLocationService;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 데이터 분석 컨트롤러
 * 지하철 혼잡도 분석 결과 제공
 */
@RestController
@RequestMapping("/api/analytics")
@Slf4j
@RequiredArgsConstructor
public class AnalyticsController {

    private final StationLocationService locationService;

    @GetMapping("/congestion/morning")
    public ResponseEntity<List<StationCongestion>> getMorningCongestion() {
        return ResponseEntity.ok(getCongestionList(Arrays.asList(
            new CongestionData("송파", 50.9),
            new CongestionData("석촌", 47.8),
            new CongestionData("남태령", 47.6),
            new CongestionData("중곡", 47.0),
            new CongestionData("어린이대공원", 46.6),
            new CongestionData("용마산", 45.4),
            new CongestionData("몽촌토성", 45.2),
            new CongestionData("사가정", 44.7),
            new CongestionData("강동구청", 44.6),
            new CongestionData("방배", 44.5)
        )));
    }

    @GetMapping("/congestion/evening")
    public ResponseEntity<List<StationCongestion>> getEveningCongestion() {
        return ResponseEntity.ok(getCongestionList(Arrays.asList(
            new CongestionData("석촌", 58.1),
            new CongestionData("송파", 55.6),
            new CongestionData("서초", 53.6),
            new CongestionData("남태령", 52.8),
            new CongestionData("방배", 52.7),
            new CongestionData("강남", 52.4),
            new CongestionData("몽촌토성", 51.2),
            new CongestionData("역삼", 51.1),
            new CongestionData("혜화", 49.9),
            new CongestionData("길동", 49.6)
        )));
    }

    private List<StationCongestion> getCongestionList(List<CongestionData> dataList) {
        return dataList.stream().map(d -> {
            StationLocationService.Location loc = locationService.getStationLocation(d.name);
            double lat = (loc != null) ? loc.getLat() : 37.5665;
            double lng = (loc != null) ? loc.getLng() : 126.9780;
            return new StationCongestion(d.name, d.congestion, lat, lng);
        }).toList();
    }

    @Data
    @AllArgsConstructor
    static class CongestionData {
        String name;
        double congestion;
    }

    @Data
    @AllArgsConstructor
    static class StationCongestion {
        private String stationName;
        private double congestion;
        private double lat;
        private double lng;
    }
}
