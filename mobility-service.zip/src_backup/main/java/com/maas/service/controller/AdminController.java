package com.maas.service.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.maas.service.entity.PointTransaction;
import com.maas.service.entity.User;
import com.maas.service.service.AdminService;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 관리자 컨트롤러
 * 관리자 대시보드, 사용자 관리, 마일리지 수동 조정
 */
@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
@Slf4j
public class AdminController {

    private final AdminService adminService;

    /**
     * 관리자 로그인 페이지
     */
    @GetMapping("/login")
    public String loginPage(HttpSession session) {
        if (Boolean.TRUE.equals(session.getAttribute("isAdmin"))) {
            return "redirect:/admin/dashboard";
        }
        return "admin/login";
    }

    /**
     * 관리자 로그인 처리
     */
    @PostMapping("/login")
    public String login(@RequestParam String username, 
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {
        if (adminService.authenticate(username, password)) {
            session.setAttribute("isAdmin", true);
            session.setAttribute("adminId", username);
            log.info("[관리자] 로그인 성공: {}", username);
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("error", "아이디 또는 비밀번호가 올바르지 않습니다.");
        return "admin/login";
    }

    /**
     * 관리자 로그아웃
     */
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/admin/login";
    }

    /**
     * 관리자 대시보드
     */
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }

        Map<String, Object> stats = adminService.getDashboardStats();
        model.addAttribute("stats", stats);
        model.addAttribute("adminId", session.getAttribute("adminId"));

        return "admin/dashboard";
    }

    /**
     * 대시보드 통계 API
     */
    @GetMapping("/api/stats")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getStats(HttpSession session) {
        if (!isAdminLoggedIn(session)) {
            return ResponseEntity.status(401).body(Map.of("error", "Unauthorized"));
        }
        return ResponseEntity.ok(adminService.getDashboardStats());
    }

    /**
     * 사용자 목록 페이지
     */
    @GetMapping("/users")
    public String usersPage(HttpSession session, Model model) {
        if (!isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }

        List<User> users = adminService.getAllUsers();
        model.addAttribute("users", users);
        return "admin/users";
    }

    /**
     * 사용자 목록 API
     */
    @GetMapping("/api/users")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getUsers(HttpSession session) {
        if (!isAdminLoggedIn(session)) {
            return ResponseEntity.status(401).body(Map.of("error", "Unauthorized"));
        }

        List<User> users = adminService.getAllUsers();
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("count", users.size());
        response.put("users", users);
        return ResponseEntity.ok(response);
    }

    /**
     * 마일리지 수동 조정 API
     * POST /admin/api/points/adjust
     * Body: { userId, amount, reason, type: "grant" | "deduct" }
     */
    @PostMapping("/api/points/adjust")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> adjustPoints(
            @RequestBody Map<String, Object> request,
            HttpSession session) {

        if (!isAdminLoggedIn(session)) {
            return ResponseEntity.status(401).body(Map.of("error", "Unauthorized"));
        }

        try {
            Long userId = Long.valueOf(request.get("userId").toString());
            int amount = Integer.parseInt(request.get("amount").toString());
            String reason = (String) request.getOrDefault("reason", "관리자 조정");
            String type = (String) request.getOrDefault("type", "grant");
            String adminId = (String) session.getAttribute("adminId");

            if ("deduct".equalsIgnoreCase(type)) {
                adminService.deductPoints(userId, amount, reason, adminId);
            } else {
                adminService.grantPoints(userId, amount, reason, adminId);
            }

            User user = adminService.getUserById(userId);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", type.equals("deduct") ? 
                    String.format("%dP 차감 완료", amount) : String.format("%dP 지급 완료", amount));
            response.put("newBalance", user != null ? user.getPoints() : 0);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("[관리자] 포인트 조정 실패: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * 거래 내역 API
     */
    @GetMapping("/api/transactions")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getTransactions(
            @RequestParam(required = false) Long userId,
            HttpSession session) {

        if (!isAdminLoggedIn(session)) {
            return ResponseEntity.status(401).body(Map.of("error", "Unauthorized"));
        }

        List<PointTransaction> transactions;
        if (userId != null) {
            transactions = adminService.getUserTransactions(userId);
        } else {
            transactions = adminService.getAllTransactions();
        }

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("count", transactions.size());
        response.put("transactions", transactions);
        return ResponseEntity.ok(response);
    }

    /**
     * 관리자 로그인 확인
     */
    private boolean isAdminLoggedIn(HttpSession session) {
        return Boolean.TRUE.equals(session.getAttribute("isAdmin"));
    }
}
