package com.maas.service.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 정책 관리 컨트롤러
 * 정책 설정, 시간대 가중치, 역 가중치 관리
 */
@Controller
@RequestMapping("/policy")
public class PolicyController {

    /**
     * 정책 관리 메인 페이지
     */
    @GetMapping("")
    public String policyMain(Model model) {
        model.addAttribute("pageTitle", "정책 관리 - K-MaaS");
        model.addAttribute("policies", getPolicies());
        model.addAttribute("timeSlots", getTimeSlots());
        model.addAttribute("stations", getStationWeights());
        return "policy";
    }

    /**
     * 정책 목록 API
     */
    @GetMapping("/api/list")
    @ResponseBody
    public Map<String, Object> getPolicyList() {
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("policies", getPolicies());
        return result;
    }

    /**
     * 정책 상태 변경 API
     */
    @PostMapping("/api/toggle")
    @ResponseBody
    public Map<String, Object> togglePolicy(
            @RequestParam String policyId,
            @RequestParam String enabled) {

        boolean isEnabled = "true".equalsIgnoreCase(enabled);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("policyId", policyId);
        result.put("enabled", isEnabled);
        result.put("message", isEnabled ? "정책이 활성화되었습니다." : "정책이 비활성화되었습니다.");
        return result;
    }

    /**
     * 시간대 가중치 저장 API
     */
    @PostMapping("/api/timeslot")
    @ResponseBody
    public Map<String, Object> saveTimeSlotWeight(
            @RequestParam String slotId,
            @RequestParam double weight) {

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("slotId", slotId);
        result.put("weight", weight);
        result.put("message", "시간대 가중치가 저장되었습니다.");
        return result;
    }

    /**
     * 정책 저장 API
     */
    @PostMapping("/api/save")
    @ResponseBody
    public Map<String, Object> savePolicy(@RequestBody Map<String, Object> policyData) {

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("policyId", policyData.get("policyId"));
        result.put("message", "변경사항이 저장되었습니다. 1시간 후부터 적용됩니다.");
        return result;
    }

    /**
     * 정책 삭제 API
     */
    @PostMapping("/api/delete")
    @ResponseBody
    public Map<String, Object> deletePolicy(@RequestParam String policyId) {

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("policyId", policyId);
        result.put("message", "정책이 삭제되었습니다.");
        return result;
    }

    // 정책 목록
    private List<Map<String, Object>> getPolicies() {
        List<Map<String, Object>> policies = new ArrayList<>();

        policies.add(createPolicy(
                "P001",
                "비혼잡 시간대 인센티브",
                "오전/오후 비혼잡 시간대 하차 시 추가 포인트를 지급하여 교통 분산을 유도합니다.",
                true,
                "2025-01-06",
                "2025-01-31",
                "69개 역"
        ));

        policies.add(createPolicy(
                "P002",
                "상권 연계 할인",
                "하차 역 주변 제휴 상점 이용 시 할인 혜택을 제공하여 지역 경제를 활성화합니다.",
                false,
                null,
                null,
                "12개 제휴점"
        ));

        policies.add(createPolicy(
                "P003",
                "친환경 이동 보너스",
                "자전거, 킥보드 등 친환경 이동수단 이용 시 추가 포인트를 지급합니다.",
                false,
                null,
                null,
                "환경부 연계"
        ));

        policies.add(createPolicy(
                "P004",
                "역 혼잡도 기반 조정",
                "실시간 역 혼잡도에 따라 포인트를 동적으로 조정하여 승객 흐름을 최적화합니다.",
                false,
                null,
                null,
                "AI 기반"
        ));

        return policies;
    }

    private Map<String, Object> createPolicy(String id, String name, String description,
                                              boolean active, String startDate, String endDate, String scope) {
        Map<String, Object> policy = new HashMap<>();
        policy.put("id", id);
        policy.put("name", name);
        policy.put("description", description);
        policy.put("active", active);
        policy.put("startDate", startDate);
        policy.put("endDate", endDate);
        policy.put("scope", scope);
        return policy;
    }

    // 시간대 가중치
    private List<Map<String, Object>> getTimeSlots() {
        List<Map<String, Object>> slots = new ArrayList<>();

        slots.add(createTimeSlot("T1", "10:00 - 12:00", 1.0));
        slots.add(createTimeSlot("T2", "12:00 - 14:00", 1.5));
        slots.add(createTimeSlot("T3", "14:00 - 16:00", 2.0));
        slots.add(createTimeSlot("T4", "20:00 - 23:00", 1.3));

        return slots;
    }

    private Map<String, Object> createTimeSlot(String id, String time, double weight) {
        Map<String, Object> slot = new HashMap<>();
        slot.put("id", id);
        slot.put("time", time);
        slot.put("weight", weight);
        return slot;
    }

    // 역 가중치
    private List<Map<String, Object>> getStationWeights() {
        List<Map<String, Object>> stations = new ArrayList<>();

        stations.add(createStationWeight("부평역", 2.0, true));
        stations.add(createStationWeight("인천역", 1.5, true));
        stations.add(createStationWeight("동인천역", 1.5, true));
        stations.add(createStationWeight("수원역", 1.3, true));
        stations.add(createStationWeight("의정부역", 1.3, true));

        return stations;
    }

    private Map<String, Object> createStationWeight(String name, double weight, boolean enabled) {
        Map<String, Object> station = new HashMap<>();
        station.put("name", name);
        station.put("weight", weight);
        station.put("enabled", enabled);
        return station;
    }
}
