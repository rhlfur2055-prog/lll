package com.maas.service.service;

import com.maas.service.entity.User;
import com.maas.service.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.Optional;

/**
 * OAuth2 사용자 정보 처리 서비스
 * 구글, 네이버, 카카오 로그인 시 사용자 정보를 DB에 저장 및 연동
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OAuth2UserService extends DefaultOAuth2UserService {

    private final UserRepository userRepository;

    @Override
    @Transactional
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
        OAuth2User oAuth2User = super.loadUser(userRequest);

        try {
            String registrationId = userRequest.getClientRegistration().getRegistrationId();
            log.info("[OAuth2 로그인] Provider: {}", registrationId);

            // OAuth2 제공자에 따라 사용자 정보 파싱
            Map<String, Object> attributes = oAuth2User.getAttributes();
            String email = extractEmail(registrationId, attributes);
            String name = extractName(registrationId, attributes);

            log.info("[OAuth2 사용자 정보] Email: {}, Name: {}", email, name);

            // 사용자 조회 또는 생성
            User user = saveOrUpdate(email, name, registrationId);

            log.info("[OAuth2 로그인 완료] 사용자 ID: {}, Email: {}", user.getId(), user.getEmail());

            return oAuth2User;

        } catch (Exception e) {
            log.error("[OAuth2 로그인 실패] {}", e.getMessage(), e);
            throw new OAuth2AuthenticationException("OAuth2 로그인 처리 실패");
        }
    }

    /**
     * 이메일 추출
     */
    private String extractEmail(String registrationId, Map<String, Object> attributes) {
        switch (registrationId) {
            case "google":
                return (String) attributes.get("email");

            case "naver":
                @SuppressWarnings("unchecked")
                Map<String, Object> response = (Map<String, Object>) attributes.get("response");
                return (String) response.get("email");

            case "kakao":
                @SuppressWarnings("unchecked")
                Map<String, Object> kakaoAccount = (Map<String, Object>) attributes.get("kakao_account");
                return (String) kakaoAccount.get("email");

            default:
                throw new IllegalArgumentException("지원하지 않는 OAuth2 제공자입니다: " + registrationId);
        }
    }

    /**
     * 이름 추출
     */
    private String extractName(String registrationId, Map<String, Object> attributes) {
        switch (registrationId) {
            case "google":
                return (String) attributes.get("name");

            case "naver":
                @SuppressWarnings("unchecked")
                Map<String, Object> response = (Map<String, Object>) attributes.get("response");
                return (String) response.get("name");

            case "kakao":
                @SuppressWarnings("unchecked")
                Map<String, Object> properties = (Map<String, Object>) attributes.get("properties");
                return (String) properties.get("nickname");

            default:
                return "Unknown";
        }
    }

    /**
     * 사용자 저장 또는 업데이트
     */
    private User saveOrUpdate(String email, String name, String provider) {
        Optional<User> existingUser = userRepository.findByEmail(email);

        if (existingUser.isPresent()) {
            // 기존 사용자 업데이트
            User user = existingUser.get();
            user.setName(name);
            log.info("[기존 사용자] ID: {}, Email: {}", user.getId(), user.getEmail());
            return userRepository.save(user);
        } else {
            // 신규 사용자 생성 (가입 축하 1000P 지급)
            User newUser = User.builder()
                    .email(email)
                    .name(name)
                    .password("OAUTH2_" + provider.toUpperCase()) // OAuth2 사용자는 비밀번호 없음
                    .phone("") // 선택 정보
                    .points(1000) // 가입 축하 포인트
                    .build();

            newUser = userRepository.save(newUser);
            log.info("[신규 사용자 생성] ID: {}, Email: {}, 초기 포인트: 1000P", newUser.getId(), newUser.getEmail());

            return newUser;
        }
    }
}
