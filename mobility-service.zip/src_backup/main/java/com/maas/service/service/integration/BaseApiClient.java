package com.maas.service.service.integration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * 프로덕션 레벨 API 클라이언트 베이스 클래스
 * 재시도, 타임아웃, 에러 처리 포함
 */
@Slf4j
public abstract class BaseApiClient {

    protected final WebClient webClient;
    private final Map<String, ApiMetrics> metricsMap = new HashMap<>();

    protected BaseApiClient(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder
                .build();
    }

    /**
     * API 메트릭 추적 클래스
     */
    protected static class ApiMetrics {
        long totalCalls = 0;
        long successCalls = 0;
        long failedCalls = 0;
        long totalResponseTime = 0;
        String lastError = "";

        public double getSuccessRate() {
            return totalCalls == 0 ? 0 : (successCalls * 100.0 / totalCalls);
        }

        public long getAverageResponseTime() {
            return successCalls == 0 ? 0 : (totalResponseTime / successCalls);
        }
    }

    /**
     * GET 요청 실행 (재시도 포함)
     *
     * @param url 요청 URL
     * @param apiName API 이름 (로깅용)
     * @param maxRetries 최대 재시도 횟수
     * @param timeoutSeconds 타임아웃 (초)
     * @return 응답 문자열
     */
    protected String executeGet(String url, String apiName, int maxRetries, int timeoutSeconds) {
        long startTime = System.currentTimeMillis();
        String metricsKey = apiName;

        ApiMetrics metrics = metricsMap.computeIfAbsent(metricsKey, k -> new ApiMetrics());
        metrics.totalCalls++;

        try {
            log.debug("[{}] API 호출 시작: {}", apiName, maskUrl(url));

            String response = webClient.get()
                    .uri(url)
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(timeoutSeconds))
                    .retryWhen(Retry.fixedDelay(maxRetries, Duration.ofSeconds(2))
                            .filter(throwable -> {
                                // 재시도 가능한 예외만 재시도
                                if (throwable instanceof WebClientResponseException) {
                                    WebClientResponseException ex = (WebClientResponseException) throwable;
                                    int status = ex.getStatusCode().value();
                                    // 5xx 에러나 429(Too Many Requests)만 재시도
                                    return status >= 500 || status == 429;
                                }
                                return false;
                            })
                            .doBeforeRetry(retrySignal -> {
                                log.warn("[{}] 재시도 {}/{}: {}",
                                        apiName,
                                        retrySignal.totalRetries() + 1,
                                        maxRetries,
                                        retrySignal.failure().getMessage());
                            }))
                    .onErrorResume(throwable -> {
                        log.error("[{}] API 호출 실패 (모든 재시도 소진): {}",
                                apiName, throwable.getMessage());
                        return Mono.just("{\"error\": \"" + throwable.getMessage() + "\"}");
                    })
                    .block();

            long responseTime = System.currentTimeMillis() - startTime;
            metrics.successCalls++;
            metrics.totalResponseTime += responseTime;

            log.info("[{}] API 호출 성공 - 응답시간: {}ms", apiName, responseTime);

            return response;

        } catch (Exception e) {
            long responseTime = System.currentTimeMillis() - startTime;
            metrics.failedCalls++;
            metrics.lastError = e.getMessage();

            log.error("[{}] API 호출 예외 발생 - 소요시간: {}ms, 에러: {}",
                    apiName, responseTime, e.getMessage(), e);

            return "{\"error\": \"" + e.getMessage() + "\"}";
        }
    }

    /**
     * POST 요청 실행 (재시도 포함)
     */
    protected String executePost(String url, String body, String apiName, int maxRetries, int timeoutSeconds) {
        long startTime = System.currentTimeMillis();
        ApiMetrics metrics = metricsMap.computeIfAbsent(apiName, k -> new ApiMetrics());
        metrics.totalCalls++;

        try {
            log.debug("[{}] POST 요청 시작: {}", apiName, maskUrl(url));

            String response = webClient.post()
                    .uri(url)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(timeoutSeconds))
                    .retryWhen(Retry.fixedDelay(maxRetries, Duration.ofSeconds(2))
                            .filter(throwable -> throwable instanceof WebClientResponseException)
                            .doBeforeRetry(retrySignal ->
                                    log.warn("[{}] POST 재시도 {}/{}", apiName, retrySignal.totalRetries() + 1, maxRetries)))
                    .block();

            long responseTime = System.currentTimeMillis() - startTime;
            metrics.successCalls++;
            metrics.totalResponseTime += responseTime;

            log.info("[{}] POST 성공 - 응답시간: {}ms", apiName, responseTime);
            return response;

        } catch (Exception e) {
            metrics.failedCalls++;
            metrics.lastError = e.getMessage();
            log.error("[{}] POST 실패: {}", apiName, e.getMessage(), e);
            return "{\"error\": \"" + e.getMessage() + "\"}";
        }
    }

    /**
     * API 메트릭 조회
     */
    public Map<String, Object> getMetrics(String apiName) {
        ApiMetrics metrics = metricsMap.get(apiName);
        if (metrics == null) {
            return Map.of("message", "No metrics available");
        }

        Map<String, Object> result = new HashMap<>();
        result.put("totalCalls", metrics.totalCalls);
        result.put("successCalls", metrics.successCalls);
        result.put("failedCalls", metrics.failedCalls);
        result.put("successRate", String.format("%.2f%%", metrics.getSuccessRate()));
        result.put("averageResponseTime", metrics.getAverageResponseTime() + "ms");
        result.put("lastError", metrics.lastError);
        return result;
    }

    /**
     * 모든 API 메트릭 조회
     */
    public Map<String, Map<String, Object>> getAllMetrics() {
        Map<String, Map<String, Object>> allMetrics = new HashMap<>();
        for (String apiName : metricsMap.keySet()) {
            allMetrics.put(apiName, getMetrics(apiName));
        }
        return allMetrics;
    }

    /**
     * URL 마스킹 (API 키 숨김)
     */
    protected String maskUrl(String url) {
        if (url == null) return "";
        // API 키 부분을 마스킹
        return url.replaceAll("(serviceKey|key|apiKey)=([^&]+)", "$1=****");
    }

    /**
     * 추상 메서드: API 이름 반환
     */
    protected abstract String getApiName();
}
