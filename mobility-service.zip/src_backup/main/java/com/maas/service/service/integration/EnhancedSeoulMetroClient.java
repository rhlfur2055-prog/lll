package com.maas.service.service.integration;

import com.maas.service.config.ApiKeyConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * 서울 지하철 실시간 도착 정보 API 클라이언트 (프로덕션 레벨)
 * 재시도, 타임아웃, 캐싱, 에러 로깅 포함
 */
@Slf4j
@Service
public class EnhancedSeoulMetroClient extends BaseApiClient {

    private static final String BASE_URL = "http://swopenAPI.seoul.go.kr/api/subway";
    private static final int MAX_RETRIES = 3;
    private static final int TIMEOUT_SECONDS = 10;

    private final ApiKeyConfig apiKeyConfig;

    public EnhancedSeoulMetroClient(WebClient.Builder webClientBuilder, ApiKeyConfig apiKeyConfig) {
        super(webClientBuilder);
        this.apiKeyConfig = apiKeyConfig;
    }

    /**
     * 실시간 지하철 도착 정보 조회 (캐싱 5분)
     */
    @Cacheable(value = "metroArrival", key = "#stationName", unless = "#result == null || #result.contains('error')")
    public String getRealtimeArrival(String stationName) {
        String url = String.format("%s/%s/json/realtimeStationArrival/0/10/%s",
                BASE_URL,
                apiKeyConfig.getSeoulMetroArrivalKey(),
                stationName);

        return executeGet(url, "Seoul Metro Arrival - " + stationName, MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * 호선별 역 목록 조회 (캐싱 1시간)
     */
    @Cacheable(value = "metroStations", key = "#lineNumber")
    public String getStationsByLine(String lineNumber) {
        String url = String.format("%s/%s/json/SearchSTNBySubwayLineInfo/0/100/%s",
                BASE_URL,
                apiKeyConfig.getSeoulMetroArrivalKey(),
                lineNumber);

        return executeGet(url, "Seoul Metro Stations - Line " + lineNumber, MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * 지하철 혼잡도 정보 조회 (캐싱 10분)
     */
    @Cacheable(value = "metroCongestion", key = "#date")
    public String getCongestionData(String date) {
        String url = String.format("%s/%s/json/CardSubwayStatsNew/1/100/%s",
                BASE_URL,
                apiKeyConfig.getSeoulMetroCongestionKey(),
                date);

        return executeGet(url, "Seoul Metro Congestion - " + date, MAX_RETRIES, TIMEOUT_SECONDS);
    }

    @Override
    protected String getApiName() {
        return "Seoul Metro API";
    }
}
