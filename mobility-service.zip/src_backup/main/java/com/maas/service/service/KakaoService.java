package com.maas.service.service;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 카카오 로컬 API 연동 서비스
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class KakaoService {

    @Value("${kakao.rest.api.key}")
    private String kakaoRestApiKey;

    private final RestTemplate restTemplate = new RestTemplate();
    private static final String KAKAO_SEARCH_URL = "https://dapi.kakao.com/v2/local/search/keyword.json";

    public Map<String, Object> searchPlace(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return Collections.emptyMap();
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "KakaoAK " + kakaoRestApiKey);
            HttpEntity<String> entity = new HttpEntity<>(headers);

            String url = KAKAO_SEARCH_URL + "?query=" + keyword;
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);
            
            return response.getBody();
        } catch (Exception e) {
            log.error("Kakao Search API Failed: {}", e.getMessage());
            return Collections.emptyMap();
        }
    }
}
