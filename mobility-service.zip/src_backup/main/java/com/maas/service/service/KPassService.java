package com.maas.service.service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.maas.service.entity.PointTransaction;
import com.maas.service.entity.Policy;
import com.maas.service.entity.UsageRecord;
import com.maas.service.entity.User;
import com.maas.service.repository.PointTransactionRepository;
import com.maas.service.repository.PolicyRepository;
import com.maas.service.repository.UsageRecordRepository;
import com.maas.service.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * K-Pass 마일리지 시스템 서비스
 * 교통수단별 자동 적립, 정책 기반 가중치 적용, 할인 관리
 */
@Service("kpassApiService")
@RequiredArgsConstructor
@Slf4j
public class KPassService {

    private final UserRepository userRepository;
    private final PointTransactionRepository pointTransactionRepository;
    private final UsageRecordRepository usageRecordRepository;
    private final PolicyRepository policyRepository;

    // 기본 적립률 (교통수단별)
    private static final Map<String, Double> BASE_EARN_RATES = Map.of(
            "SUBWAY", 0.10,      // 지하철 10%
            "BUS", 0.10,         // 버스 10%
            "KTX", 0.05,         // KTX 5%
            "BIKE", 0.0,         // 따릉이: 고정 100P
            "HIGHWAY", 0.03,     // 고속도로 3%
            "PARKING", 0.05      // 주차장 5%
    );

    private static final int BIKE_FIXED_POINTS = 100; // 따릉이 고정 포인트

    /**
     * 교통수단 이용 시 K-Pass 마일리지 자동 적립
     * 정책 가중치를 적용하여 최종 적립 포인트 계산
     */
    @Transactional
    public int earnPointsWithPolicy(Long userId, String transportType, int fare, String routeInfo) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다: " + userId));

        // 기본 적립 포인트 계산
        int basePoints;
        if ("BIKE".equalsIgnoreCase(transportType)) {
            basePoints = BIKE_FIXED_POINTS;
        } else {
            double rate = BASE_EARN_RATES.getOrDefault(transportType.toUpperCase(), 0.05);
            basePoints = (int) Math.round(fare * rate);
        }

        // 정책 가중치 적용
        double policyMultiplier = getPolicyMultiplier(transportType);
        int finalPoints = (int) Math.round(basePoints * policyMultiplier);

        if (finalPoints <= 0) {
            log.info("[K-Pass] 적립 대상 아님: userId={}, type={}, fare={}", userId, transportType, fare);
            return 0;
        }

        // 포인트 적립
        user.setPoints(user.getPoints() + finalPoints);
        userRepository.save(user);

        // 트랜잭션 기록
        PointTransaction transaction = PointTransaction.builder()
                .userId(userId)
                .amount(finalPoints)
                .type("EARN")
                .reason(String.format("K-Pass 적립: %s (%s)", transportType, routeInfo))
                .build();
        pointTransactionRepository.save(transaction);

        // 이용 기록
        UsageRecord usageRecord = UsageRecord.builder()
                .userId(String.valueOf(userId))
                .transportType(transportType)
                .routeInfo(routeInfo)
                .usageTime(LocalDateTime.now())
                .points(finalPoints)
                .policyApplied(String.valueOf(policyMultiplier > 1.0))
                .build();
        usageRecordRepository.save(usageRecord);

        log.info("[K-Pass 적립] userId={}, type={}, fare={}, 기본={}P, 정책배율={}, 최종={}P",
                userId, transportType, fare, basePoints, policyMultiplier, finalPoints);

        return finalPoints;
    }

    /**
     * K-Pass 마일리지 사용 (결제 할인)
     */
    @Transactional
    public int usePoints(Long userId, int requestedPoints, String reason) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다"));

        int availablePoints = user.getPoints();
        int usePoints = Math.min(requestedPoints, availablePoints);

        if (usePoints <= 0) {
            throw new RuntimeException("사용 가능한 포인트가 없습니다");
        }

        user.setPoints(availablePoints - usePoints);
        userRepository.save(user);

        PointTransaction transaction = PointTransaction.builder()
                .userId(userId)
                .amount(usePoints)
                .type("USE")
                .reason(reason)
                .build();
        pointTransactionRepository.save(transaction);

        log.info("[K-Pass 사용] userId={}, 사용={}P, 잔액={}P", userId, usePoints, user.getPoints());

        return usePoints;
    }

    /**
     * 사용자 K-Pass 잔액 조회
     */
    public int getBalance(Long userId) {
        return userRepository.findById(userId)
                .map(User::getPoints)
                .orElse(0);
    }

    /**
     * 포인트 거래 내역 조회
     */
    public List<PointTransaction> getPointHistory(Long userId) {
        return pointTransactionRepository.findByUserIdOrderByTransactionTimeDesc(userId);
    }

    /**
     * 이용 기록 조회
     */
    public List<UsageRecord> getUsageHistory(Long userId) {
        return usageRecordRepository.findByUserId(String.valueOf(userId));
    }

    /**
     * 월간 통계 조회
     */
    public Map<String, Object> getMonthlyStats(Long userId) {
        LocalDateTime now = LocalDateTime.now();
        int year = now.getYear();
        int month = now.getMonthValue();

        // 이번 달 시작/끝
        LocalDateTime startOfMonth = now.withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
        LocalDateTime endOfMonth = now.withDayOfMonth(now.toLocalDate().lengthOfMonth())
                .withHour(23).withMinute(59).withSecond(59);

        List<PointTransaction> transactions = pointTransactionRepository.findByUserIdOrderByTransactionTimeDesc(userId);

        int earnedThisMonth = 0;
        int usedThisMonth = 0;
        int usageCount = 0;

        for (PointTransaction tx : transactions) {
            if (tx.getTransactionTime() != null &&
                    !tx.getTransactionTime().isBefore(startOfMonth) &&
                    !tx.getTransactionTime().isAfter(endOfMonth)) {

                if ("EARN".equals(tx.getType())) {
                    earnedThisMonth += tx.getAmount();
                    usageCount++;
                } else if ("USE".equals(tx.getType())) {
                    usedThisMonth += tx.getAmount();
                }
            }
        }

        Map<String, Object> stats = new HashMap<>();
        stats.put("year", year);
        stats.put("month", month);
        stats.put("earnedPoints", earnedThisMonth);
        stats.put("usedPoints", usedThisMonth);
        stats.put("usageCount", usageCount);
        stats.put("savingsEstimate", usedThisMonth); // 절약 금액 = 사용 포인트

        return stats;
    }

    /**
     * 할인 금액 계산 (교통수단별 할인율 적용)
     */
    public int calculateDiscount(Long userId, int originalFare, String transportType) {
        int points = getBalance(userId);

        // 교통수단별 할인율 계산
        double discountRate = getDiscountRate(transportType);
        int discountAmount = (int) Math.round(originalFare * discountRate);

        // 포인트로 결제 가능한 금액과 비교
        int pointDiscount = Math.min(points, discountAmount);

        return pointDiscount;
    }

    /**
     * QR 코드용 토큰 생성
     */
    public String generateQRToken(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다"));

        // 간단한 토큰: userId + timestamp + 체크섬
        long timestamp = System.currentTimeMillis();
        String data = String.format("KPASS:%d:%d:%d", userId, user.getPoints(), timestamp);
        return data;
    }

    // === Private Helper Methods ===

    /**
     * 정책 가중치 조회
     */
    private double getPolicyMultiplier(String transportType) {
        // 시간대별 가중치 (비혼잡: 10~16시 = 1.5배)
        LocalTime now = LocalTime.now();
        int hour = now.getHour();
        double timeMultiplier = (hour >= 10 && hour < 16) ? 1.5 : 1.0;

        // 친환경 가중치 (따릉이 = 2.0배)
        double ecoMultiplier = "BIKE".equalsIgnoreCase(transportType) ? 2.0 : 1.0;

        // 정책 DB에서 활성화된 정책 확인 (eco, off-peak 등)
        // 현재 Policy 엔티티는 policyType 기반이므로 간단하게 처리
        double policyWeight = 1.0;
        try {
            // eco 정책이 활성화되어 있으면 추가 가중치
            if ("BIKE".equalsIgnoreCase(transportType)) {
                Optional<Policy> ecoPolicy = policyRepository.findByPolicyTypeAndEnabledTrue("eco");
                if (ecoPolicy.isPresent()) {
                    policyWeight = 1.5; // 친환경 정책 활성 시 추가 가중치
                }
            }
            // off-peak 정책 확인
            if (hour >= 10 && hour < 16) {
                Optional<Policy> offPeakPolicy = policyRepository.findByPolicyTypeAndEnabledTrue("off-peak");
                if (offPeakPolicy.isPresent()) {
                    policyWeight *= 1.2; // 비혼잡 정책 활성 시 추가 가중치
                }
            }
        } catch (Exception e) {
            log.warn("[K-Pass] 정책 조회 실패, 기본값 사용: {}", e.getMessage());
        }

        return timeMultiplier * ecoMultiplier * policyWeight;
    }

    /**
     * 교통수단별 할인율
     */
    private double getDiscountRate(String transportType) {
        return switch (transportType.toUpperCase()) {
            case "SUBWAY" -> 0.10;  // 10%
            case "BUS" -> 0.10;
            case "KTX" -> 0.20;     // 20%
            case "BIKE" -> 1.0;     // 100% (무료 쿠폰)
            default -> 0.05;
        };
    }
}
