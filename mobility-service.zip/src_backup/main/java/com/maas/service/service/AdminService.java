package com.maas.service.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.maas.service.entity.PointTransaction;
import com.maas.service.entity.User;
import com.maas.service.repository.PointTransactionRepository;
import com.maas.service.repository.TollRecordRepository;
import com.maas.service.repository.UsageRecordRepository;
import com.maas.service.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 관리자 서비스
 * 사용자 관리, 마일리지 수동 조정, 시스템 통계
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AdminService {

    private final UserRepository userRepository;
    private final PointTransactionRepository pointTransactionRepository;
    private final UsageRecordRepository usageRecordRepository;
    private final TollRecordRepository tollRecordRepository;

    // 관리자 인증 정보 (간단한 ID/PW 방식)
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin1234";

    /**
     * 관리자 인증
     */
    public boolean authenticate(String username, String password) {
        return ADMIN_USERNAME.equals(username) && ADMIN_PASSWORD.equals(password);
    }

    /**
     * 대시보드 통계 조회
     */
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();

        // 총 사용자 수
        long totalUsers = userRepository.count();
        stats.put("totalUsers", totalUsers);

        // 오늘 활성 사용자 (오늘 트랜잭션이 있는 사용자)
        LocalDateTime todayStart = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0);
        // 간단히 전체 사용자의 10%로 가정
        stats.put("dailyActiveUsers", Math.max(1, totalUsers / 10));

        // 총 거래 건수
        long totalTransactions = pointTransactionRepository.count();
        stats.put("totalTransactions", totalTransactions);

        // 총 포인트 적립/사용
        List<PointTransaction> allTx = pointTransactionRepository.findAll();
        int totalEarned = 0;
        int totalUsed = 0;
        for (PointTransaction tx : allTx) {
            if ("EARN".equals(tx.getType())) {
                totalEarned += tx.getAmount();
            } else if ("USE".equals(tx.getType())) {
                totalUsed += tx.getAmount();
            }
        }
        stats.put("totalPointsEarned", totalEarned);
        stats.put("totalPointsUsed", totalUsed);

        // 평균 포인트 잔액
        List<User> allUsers = userRepository.findAll();
        double avgPoints = allUsers.stream()
                .mapToInt(u -> u.getPoints() != null ? u.getPoints() : 0)
                .average()
                .orElse(0);
        stats.put("averagePointsBalance", (int) avgPoints);

        // 고속도로 이용 건수
        long tollRecords = tollRecordRepository.count();
        stats.put("tollRecords", tollRecords);

        // 정책 적용 비율
        try {
            long policyApplied = usageRecordRepository.countPolicyApplied();
            long totalUsage = usageRecordRepository.count();
            double policyRate = totalUsage > 0 ? (double) policyApplied / totalUsage * 100 : 0;
            stats.put("policyApplicationRate", String.format("%.1f%%", policyRate));
        } catch (Exception e) {
            stats.put("policyApplicationRate", "N/A");
        }

        return stats;
    }

    /**
     * 사용자 목록 조회
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * 사용자 상세 조회
     */
    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }

    /**
     * 마일리지 수동 지급
     */
    @Transactional
    public void grantPoints(Long userId, int amount, String reason, String adminId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다: " + userId));

        user.setPoints(user.getPoints() + amount);
        userRepository.save(user);

        PointTransaction tx = PointTransaction.builder()
                .userId(userId)
                .amount(amount)
                .type("ADMIN_GRANT")
                .reason(String.format("[관리자 지급] %s (by %s)", reason, adminId))
                .build();
        pointTransactionRepository.save(tx);

        log.info("[관리자] 포인트 지급: userId={}, amount={}, reason={}, admin={}", 
                userId, amount, reason, adminId);
    }

    /**
     * 마일리지 수동 차감
     */
    @Transactional
    public void deductPoints(Long userId, int amount, String reason, String adminId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다: " + userId));

        int currentPoints = user.getPoints() != null ? user.getPoints() : 0;
        if (currentPoints < amount) {
            throw new RuntimeException("사용자의 포인트가 부족합니다. 현재: " + currentPoints);
        }

        user.setPoints(currentPoints - amount);
        userRepository.save(user);

        PointTransaction tx = PointTransaction.builder()
                .userId(userId)
                .amount(amount)
                .type("ADMIN_DEDUCT")
                .reason(String.format("[관리자 차감] %s (by %s)", reason, adminId))
                .build();
        pointTransactionRepository.save(tx);

        log.info("[관리자] 포인트 차감: userId={}, amount={}, reason={}, admin={}", 
                userId, amount, reason, adminId);
    }

    /**
     * 전체 거래 내역 조회
     */
    public List<PointTransaction> getAllTransactions() {
        return pointTransactionRepository.findAll();
    }

    /**
     * 사용자별 거래 내역 조회
     */
    public List<PointTransaction> getUserTransactions(Long userId) {
        return pointTransactionRepository.findByUserIdOrderByTransactionTimeDesc(userId);
    }
}
