package com.maas.service.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * 지하철역 위도/경도 좌표 관리 서비스
 */
@Service
public class StationLocationService implements InitializingBean {

    private final Map<String, Location> stationMap = new HashMap<>();

    @Override
    public void afterPropertiesSet() throws Exception {
        // 서울교통공사 1~8호선 역사 좌표 데이터
        // 2호선
        addStation("까치산", 37.53181, 126.846706);
        
        // 3호선
        addStation("지축", 37.648281, 126.912551);
        addStation("구파발", 37.636612, 126.918827);
        addStation("연신내", 37.618855, 126.920859);
        addStation("불광", 37.610554, 126.929843);
        addStation("녹번", 37.600882, 126.935758);
        addStation("홍제", 37.588851, 126.944092);
        addStation("무악재", 37.582658, 126.950131);
        addStation("독립문", 37.574534, 126.957902);
        addStation("경복궁", 37.575844, 126.973576);
        addStation("안국", 37.576562, 126.98547);
        addStation("종로3가", 37.571537, 126.991237);
        addStation("을지로3가", 37.566299, 126.992616);
        addStation("충무로", 37.561302, 126.995473);
        addStation("동대입구", 37.55816, 127.005273);
        addStation("약수", 37.554674, 127.010628);
        addStation("금호", 37.548269, 127.015785);
        addStation("옥수", 37.541653, 127.017303);
        addStation("압구정", 37.526169, 127.028502);
        addStation("신사", 37.516438, 127.020247);
        addStation("잠원", 37.512989, 127.011613);
        addStation("고속터미널", 37.504953, 127.004916);
        addStation("교대", 37.49306, 127.013796);
        addStation("남부터미널", 37.48494, 127.016289);
        addStation("양재", 37.48466, 127.03513);
        addStation("매봉", 37.487114, 127.046907);
        addStation("도곡", 37.491129, 127.055694);
        addStation("대치", 37.494601, 127.063449);
        addStation("학여울", 37.496757, 127.070541);
        addStation("대청", 37.493607, 127.079526);
        addStation("일원", 37.48389, 127.08416);
        addStation("수서", 37.487507, 127.101324);
        addStation("가락시장", 37.492368, 127.118101);
        addStation("경찰병원", 37.495754, 127.124198);
        addStation("오금", 37.502288, 127.128344);

        // 4호선
        addStation("당고개", 37.66956, 127.078404);
        addStation("상계", 37.660576, 127.073199);
        addStation("노원", 37.656274, 127.063183);
        addStation("창동", 37.652993, 127.046746);
        addStation("쌍문", 37.648274, 127.034381);
        addStation("수유", 37.637127, 127.024731);
        addStation("미아", 37.626435, 127.026151);
        addStation("미아사거리", 37.613276, 127.030083);
        addStation("길음", 37.604087, 127.025353);
        addStation("성신여대입구", 37.592782, 127.017338);
        addStation("한성대입구", 37.58838, 127.006751);
        addStation("혜화", 37.582116, 127.001759);
        addStation("동대문", 37.5708397, 127.009403);
        addStation("동대문역사문화공원", 37.565083, 127.007645);
        addStation("명동", 37.561055, 126.988271);
        addStation("회현", 37.559698, 126.979565);
        addStation("서울", 37.553172, 126.972836);
        addStation("숙대입구", 37.545124, 126.971952);
        addStation("삼각지", 37.535057, 126.973354);
        addStation("신용산", 37.52919, 126.96858);
        addStation("이촌", 37.522525, 126.97335);
        addStation("동작", 37.503567, 126.980171);
        addStation("총신대입구", 37.487521, 126.982309);
        addStation("사당", 37.476563, 126.981746);
        addStation("남태령", 37.464339, 126.989081);

        // 5호선
        addStation("방화", 37.577669, 126.812822);
        addStation("개화산", 37.572458, 126.806838);
        addStation("김포공항", 37.56217, 126.801273);
        addStation("송정", 37.561411, 126.812052);
        addStation("마곡", 37.562182, 126.82693);
        addStation("발산", 37.562182, 126.82693);
        addStation("우장산", 37.548864, 126.83633);
        addStation("화곡", 37.541585, 126.840436);
        addStation("신정", 37.525001, 126.856176);
        addStation("목동", 37.526088, 126.864296);
        addStation("오목교", 37.524557, 126.875049);
        addStation("양평", 37.525614, 126.886177);
        addStation("영등포구청", 37.524209, 126.895022);
        addStation("영등포시장", 37.52276, 126.905143);
        addStation("신길", 37.51763, 126.914886);
        addStation("여의도", 37.521578, 126.924318);
        addStation("여의나루", 37.527145, 126.932807);
        addStation("마포", 37.539718, 126.946043);
        addStation("공덕", 37.544005, 126.951058);
        addStation("애오개", 37.553592, 126.956733);
        addStation("충정로", 37.560061, 126.962783);
        addStation("서대문", 37.565812, 126.966639);
        addStation("광화문", 37.570545, 126.976568);
        addStation("을지로4가", 37.56658, 126.998127);
        addStation("청구", 37.560237, 127.01379);
        addStation("신금호", 37.554504, 127.020403);
        addStation("행당", 37.557297, 127.029482);
        addStation("왕십리", 37.56197, 127.037264);
        addStation("마장", 37.566066, 127.042921);
        addStation("답십리", 37.566833, 127.05266);
        addStation("장한평", 37.561438, 127.064601);
        addStation("군자", 37.557102, 127.079559);
        addStation("아차산", 37.552005, 127.089609);
        addStation("광나루", 37.545301, 127.103478);
        addStation("천호", 37.538566, 127.123539);
        addStation("강동", 37.53581, 127.13249);
        addStation("길동", 37.538022, 127.140085);
        addStation("굽은다리", 37.545442, 127.142844);
        addStation("명일", 37.551317, 127.144002);
        addStation("고덕", 37.555002, 127.154214);
        addStation("상일동", 37.556714, 127.166381);
        addStation("둔촌동", 37.527787, 127.136219);
        addStation("올림픽공원", 37.516217, 127.130957);
        addStation("방이", 37.508752, 127.126054);
        addStation("오금", 37.502228, 127.127701);
        addStation("개롱", 37.498097, 127.134817);
        addStation("거여", 37.493208, 127.143983);
        addStation("마천", 37.494972, 127.152784);
        addStation("강일", 37.557521, 127.176018);
        addStation("미사", 37.56329, 127.192954);
        addStation("하남풍산", 37.552201, 127.203897);
        addStation("하남시청", 37.541723, 127.206901);
        addStation("하남검단산", 37.539729, 127.223427);

        // 6호선
        addStation("응암", 37.59859, 126.915583);
        addStation("역촌", 37.60605, 126.922764);
        addStation("독바위", 37.618413, 126.933035);
        addStation("구산", 37.611223, 126.917246);
        addStation("새절", 37.591148, 126.913613);
        addStation("증산", 37.583989, 126.909785);
        addStation("디지털미디어시티", 37.577005, 126.898643);
        addStation("월드컵경기장", 37.569439, 126.899077);
        addStation("마포구청", 37.563535, 126.903326);
        addStation("망원", 37.556031, 126.910129);
        addStation("합정", 37.549033, 126.913546);
        addStation("상수", 37.547704, 126.92292);
        addStation("광흥창", 37.547464, 126.931971);
        addStation("대흥", 37.547732, 126.942214);
        addStation("효창공원앞", 37.539279, 126.961348);
        addStation("녹사평", 37.53469, 126.98665);
        addStation("이태원", 37.534485, 126.994369);
        addStation("한강진", 37.53956, 127.001729);
        addStation("버티고개", 37.547933, 127.006948);
        // 약수 중복제거
        addStation("신당", 37.566174, 127.016158);
        // 동묘앞 중복제거
        addStation("창신", 37.579772, 127.015246);
        addStation("보문", 37.585293, 127.019377);
        addStation("안암", 37.586261, 127.02903);
        addStation("고려대", 37.59034, 127.03626);
        addStation("월곡", 37.60192, 127.041492);
        addStation("상월곡", 37.606392, 127.048509);
        addStation("돌곶이", 37.610522, 127.056419);
        addStation("석계", 37.614937, 127.065922);
        addStation("태릉입구", 37.617319, 127.074741);
        addStation("화랑대", 37.619875, 127.084106);
        addStation("봉화산", 37.617293, 127.091375);
        addStation("신내", 37.612571, 127.104326);

        // 7호선
        addStation("장암", 37.70015, 127.053126);
        addStation("도봉산", 37.689131, 127.046548);
        addStation("수락산", 37.677804, 127.055314);
        addStation("마들", 37.664985, 127.057701);
        addStation("중계", 37.645052, 127.064084);
        addStation("하계", 37.636363, 127.067999);
        addStation("공릉", 37.625642, 127.072969);
        addStation("먹골", 37.610638, 127.077719);
        addStation("중화", 37.602604, 127.079254);
        addStation("상봉", 37.595673, 127.085708);
        addStation("면목", 37.588671, 127.087503);
        // 사가정 중복제거
        // 용마산 중복제거
        // 중곡 중복제거
        // 어린이대공원 중복제거
        addStation("건대입구", 37.540882, 127.071103);
        addStation("뚝섬유원지", 37.531558, 127.066714);
        addStation("청담", 37.519097, 127.051851);
        addStation("강남구청", 37.517185, 127.04122);
        addStation("학동", 37.514262, 127.031738);
        addStation("논현", 37.511108, 127.021385);
        addStation("반포", 37.508171, 127.011717);
        addStation("내방", 37.48764, 126.993541);
        addStation("남성", 37.484688, 126.971108);
        addStation("숭실대입구", 37.496258, 126.953649);
        addStation("상도", 37.50279, 126.947949);
        addStation("장승배기", 37.504845, 126.939025);
        addStation("신대방삼거리", 37.499717, 126.928218);
        addStation("보라매", 37.499916, 126.920112);
        addStation("신풍", 37.500107, 126.909806);
        addStation("대림", 37.492984, 126.896997);
        addStation("남구로", 37.486181, 126.887372);
        addStation("가산디지털단지", 37.480376, 126.882704);
        addStation("철산", 37.47616, 126.868217);
        addStation("광명사거리", 37.47927, 126.854854);
        addStation("천왕", 37.486699, 126.838684);
        addStation("온수", 37.492059, 126.823294);

        // 8호선
        addStation("암사", 37.550127, 127.127521);
        addStation("암사역사공원", 37.5492, 127.1270);
        // 강동구청 중복제거
        // 몽촌토성 중복제거
        // 잠실 중복제거
        // 석촌 중복제거
        // 송파 중복제거
        addStation("문정", 37.485931, 127.122473);
        addStation("장지", 37.478609, 127.126229);
        addStation("복정", 37.471016, 127.126746);
        addStation("남위례", 37.462839, 127.139047);
        addStation("산성", 37.456886, 127.149927);
        addStation("남한산성입구", 37.451568, 127.159845);
        addStation("단대오거리", 37.445057, 127.156735);
        addStation("신흥", 37.440952, 127.14759);
        addStation("수진", 37.437575, 127.140936);
        addStation("모란", 37.433888, 127.129921);
    }

    private void addStation(String name, double lat, double lng) {
        stationMap.put(name, new Location(lat, lng));
    }

    public Location getStationLocation(String name) {
        return stationMap.get(name);
    }

    @Data
    @AllArgsConstructor
    public static class Location {
        private double lat;
        private double lng;
    }
}
