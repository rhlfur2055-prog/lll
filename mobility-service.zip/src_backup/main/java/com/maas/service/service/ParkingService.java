package com.maas.service.service;

import com.maas.service.entity.PublicParking;
import com.maas.service.repository.PublicParkingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ParkingService {

    private final PublicParkingRepository parkingRepository;
    private final SeoulParkingApiService seoulParkingApiService;
    private final GyeonggiParkingApiService gyeonggiParkingApiService;

    public void updateAllParkingData() {
        log.info("Updating all parking data...");
        seoulParkingApiService.fetchAndSaveSeoulParking();
        gyeonggiParkingApiService.fetchAndSaveGyeonggiParking();
    }

    public List<PublicParking> searchParking(String keyword) {
        return parkingRepository.findByParkingNameContaining(keyword);
    }

    public List<PublicParking> getNearbyParking(Double latitude, Double longitude, Double radiusKm) {
        return parkingRepository.findNearbyParking(latitude, longitude, radiusKm);
    }

    public List<PublicParking> getParkingByRegion(String region) {
        return parkingRepository.findByRegion(region);
    }

    public List<PublicParking> getParkingByDistrict(String district) {
        return parkingRepository.findByDistrict(district);
    }

    public List<PublicParking> getAvailableParking(Integer minSpaces) {
        return parkingRepository.findByAvailableSpacesGreaterThan(minSpaces);
    }

    public List<PublicParking> getAllParking() {
        return parkingRepository.findAll();
    }
}
