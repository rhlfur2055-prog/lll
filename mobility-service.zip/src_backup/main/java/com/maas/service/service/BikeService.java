package com.maas.service.service;

import com.maas.service.entity.BikeStation;
import com.maas.service.repository.BikeStationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class BikeService {

    private final BikeStationRepository bikeStationRepository;

    @Value("${api.bike.base-url}")
    private String baseUrl;

    @Value("${api.bike.key}")
    private String apiKey;

    private final RestTemplate restTemplate = new RestTemplate();

    public List<BikeStation> searchStations(String keyword) {
        try {
            List<BikeStation> results = bikeStationRepository.findByStationNameContaining(keyword);

            if (results.isEmpty()) {
                log.warn("No bike stations found for keyword: {}", keyword);
                return generateMockBikeStations(keyword);
            }

            return results;
        } catch (Exception e) {
            log.error("Error searching bike stations", e);
            return generateMockBikeStations(keyword);
        }
    }

    public List<BikeStation> getNearbyStations(Double latitude, Double longitude, Double radiusKm) {
        try {
            List<BikeStation> stations = bikeStationRepository.findNearbyStations(latitude, longitude, radiusKm);

            if (stations.isEmpty()) {
                log.warn("No nearby stations found");
                return generateMockNearbyStations(latitude, longitude);
            }

            return stations;
        } catch (Exception e) {
            log.error("Error getting nearby stations", e);
            return generateMockNearbyStations(latitude, longitude);
        }
    }

    @Transactional
    public void updateBikeDataFromAPI() {
        try {
            String url = UriComponentsBuilder
                    .fromHttpUrl(baseUrl + "/rfidInfo")
                    .queryParam("serviceKey", apiKey)
                    .queryParam("pageNo", "1")
                    .queryParam("numOfRows", "100")
                    .build(true)
                    .toUriString();

            log.info("Fetching bike data from API: {}", url);

            String response = restTemplate.getForObject(url, String.class);
            List<BikeStation> stations = parseBikeXml(response);

            if (!stations.isEmpty()) {
                bikeStationRepository.saveAll(stations);
                log.info("Updated {} bike stations from API", stations.size());
            } else {
                log.warn("No data from API, generating mock data");
                generateAndSaveMockData();
            }

        } catch (Exception e) {
            log.error("Failed to update bike data from API: {}", e.getMessage());
            generateAndSaveMockData();
        }
    }

    private List<BikeStation> parseBikeXml(String xml) throws Exception {
        List<BikeStation> stations = new ArrayList<>();

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));

        NodeList itemList = doc.getElementsByTagName("item");

        for (int i = 0; i < itemList.getLength(); i++) {
            Element item = (Element) itemList.item(i);

            BikeStation station = BikeStation.builder()
                    .stationId(getTagValue("stationId", item))
                    .stationName(getTagValue("stationName", item))
                    .latitude(parseDouble(getTagValue("stationLatitude", item)))
                    .longitude(parseDouble(getTagValue("stationLongitude", item)))
                    .availableBikes(parseInt(getTagValue("parkingBikeTotCnt", item)))
                    .totalDocks(parseInt(getTagValue("rackTotCnt", item)))
                    .district("서울시")
                    .address(getTagValue("stationName", item))
                    .updatedAt(LocalDateTime.now())
                    .build();

            stations.add(station);
        }

        return stations;
    }

    @Transactional
    private void generateAndSaveMockData() {
        List<BikeStation> mockStations = new ArrayList<>();

        // Gangnam Area
        mockStations.add(createMockStation("ST-101", "강남역 1번출구", 37.498095, 127.027610, "강남구", "강남역 1번출구 앞"));
        mockStations.add(createMockStation("ST-102", "강남역 2번출구", 37.497500, 127.028500, "강남구", "강남역 2번출구 앞"));
        mockStations.add(createMockStation("ST-103", "역삼역", 37.500510, 127.035760, "강남구", "역삼역 3번출구"));
        mockStations.add(createMockStation("ST-104", "선릉역", 37.504630, 127.048960, "강남구", "선릉역 4번출구"));
        mockStations.add(createMockStation("ST-105", "삼성역", 37.508490, 127.063370, "강남구", "삼성역 5번출구"));

        // Hongdae Area
        mockStations.add(createMockStation("ST-201", "홍대입구역", 37.557192, 126.925381, "마포구", "홍대입구역 9번출구"));
        mockStations.add(createMockStation("ST-202", "합정역", 37.549500, 126.913800, "마포구", "합정역 2번출구"));
        mockStations.add(createMockStation("ST-203", "망원역", 37.556000, 126.910500, "마포구", "망원역 1번출구"));

        // Gangbuk Area
        mockStations.add(createMockStation("ST-301", "광화문", 37.571607, 126.976882, "종로구", "광화문역 5번출구"));
        mockStations.add(createMockStation("ST-302", "시청역", 37.564214, 126.976738, "중구", "시청역 앞"));
        mockStations.add(createMockStation("ST-303", "종각역", 37.570108, 126.982573, "종로구", "종각역 3번출구"));

        // Yeouido Area
        mockStations.add(createMockStation("ST-401", "여의도역", 37.521624, 126.924377, "영등포구", "여의도역 3번출구"));
        mockStations.add(createMockStation("ST-402", "국회의사당역", 37.530000, 126.917000, "영등포구", "국회의사당역 1번출구"));

        // Jamsil Area
        mockStations.add(createMockStation("ST-501", "잠실역", 37.513292, 127.100109, "송파구", "잠실역 2번출구"));
        mockStations.add(createMockStation("ST-502", "석촌역", 37.505700, 127.105900, "송파구", "석촌역 4번출구"));

        bikeStationRepository.saveAll(mockStations);
        log.info("Generated and saved {} mock bike stations", mockStations.size());
    }

    private BikeStation createMockStation(String id, String name, double lat, double lon, String district, String address) {
        return BikeStation.builder()
                .stationId(id)
                .stationName(name)
                .latitude(lat)
                .longitude(lon)
                .availableBikes((int)(Math.random() * 15) + 3)
                .totalDocks(20)
                .district(district)
                .address(address)
                .updatedAt(LocalDateTime.now())
                .build();
    }

    private List<BikeStation> generateMockBikeStations(String keyword) {
        List<BikeStation> stations = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            stations.add(BikeStation.builder()
                    .stationId("MOCK-" + i)
                    .stationName(keyword + " " + (i + 1) + "번 대여소")
                    .latitude(37.5 + Math.random() * 0.1)
                    .longitude(127.0 + Math.random() * 0.1)
                    .availableBikes((int)(Math.random() * 15))
                    .totalDocks(20)
                    .district("서울시")
                    .address(keyword + " 근처")
                    .updatedAt(LocalDateTime.now())
                    .build());
        }

        return stations;
    }

    private List<BikeStation> generateMockNearbyStations(Double lat, Double lon) {
        List<BikeStation> stations = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            double offsetLat = (Math.random() - 0.5) * 0.02;
            double offsetLon = (Math.random() - 0.5) * 0.02;

            stations.add(BikeStation.builder()
                    .stationId("NEARBY-" + i)
                    .stationName("주변 대여소 " + (i + 1))
                    .latitude(lat + offsetLat)
                    .longitude(lon + offsetLon)
                    .availableBikes((int)(Math.random() * 15))
                    .totalDocks(20)
                    .district("서울시")
                    .address("주변 지역")
                    .updatedAt(LocalDateTime.now())
                    .build());
        }

        return stations;
    }

    private String getTagValue(String tag, Element element) {
        try {
            NodeList nodeList = element.getElementsByTagName(tag);
            if (nodeList.getLength() > 0) {
                return nodeList.item(0).getTextContent();
            }
        } catch (Exception e) {
            log.warn("Failed to get tag value: {}", tag);
        }
        return "0";
    }

    private Double parseDouble(String value) {
        try {
            return Double.parseDouble(value);
        } catch (Exception e) {
            return 0.0;
        }
    }

    private Integer parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    public List<BikeStation> getAllStations() {
        return bikeStationRepository.findAll();
    }

    public List<BikeStation> getStationsByDistrict(String district) {
        return bikeStationRepository.findByDistrict(district);
    }
}
