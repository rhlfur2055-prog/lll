package com.maas.service.service.integration;

import com.maas.service.config.ApiKeyConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * 한국도로공사 고속도로 API 클라이언트
 * 통행료 조회 및 영업소 정보 제공
 */
@Slf4j
@Service
public class HighwayApiClient extends BaseApiClient {

    private static final int MAX_RETRIES = 3;
    private static final int TIMEOUT_SECONDS = 15;

    // 한국도로공사 Open API 엔드포인트
    private static final String BASE_URL = "https://data.ex.co.kr/openapi/business";
    private static final String TOLL_FEE_ENDPOINT = "/curTollfeeSearch";
    private static final String TOLLGATE_INFO_ENDPOINT = "/curTgInfoGateSearch";

    private final ApiKeyConfig apiKeyConfig;

    public HighwayApiClient(WebClient.Builder webClientBuilder, ApiKeyConfig apiKeyConfig) {
        super(webClientBuilder);
        this.apiKeyConfig = apiKeyConfig;
    }

    /**
     * 통행료 조회 (캐싱 1시간)
     *
     * @param routeNo 노선번호 (1: 경부선, 10: 남해선, 100: 중부선, 130: 서해안선 등)
     * @param startTollgate 출발 톨게이트 코드
     * @param endTollgate 도착 톨게이트 코드
     * @param vehicleClass 차종 (1~5종)
     * @return JSON 형식의 통행료 정보
     */
    @Cacheable(value = "tollFee", key = "#routeNo + '-' + #startTollgate + '-' + #endTollgate + '-' + #vehicleClass",
               unless = "#result == null || #result.contains('error')")
    public String getTollFee(String routeNo, String startTollgate, String endTollgate, int vehicleClass) {
        String url = String.format("%s%s?serviceKey=%s&type=json&routeNo=%s&startTollgate=%s&endTollgate=%s&vehicleClass=%d",
                BASE_URL,
                TOLL_FEE_ENDPOINT,
                apiKeyConfig.getHighwayApiKey(),
                routeNo,
                startTollgate,
                endTollgate,
                vehicleClass);

        log.info("[고속도로 API] 통행료 조회 - 노선: {}, 출발: {}, 도착: {}, 차종: {}종",
                routeNo, startTollgate, endTollgate, vehicleClass);

        return executeGet(url, "Highway Toll Fee", MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * 영업소(톨게이트) 정보 조회 (캐싱 1일)
     *
     * @param routeNo 노선번호
     * @return JSON 형식의 톨게이트 목록
     */
    @Cacheable(value = "tollgateList", key = "#routeNo", unless = "#result == null || #result.contains('error')")
    public String getTollgateList(String routeNo) {
        String url = String.format("%s%s?serviceKey=%s&type=json&routeNo=%s",
                BASE_URL,
                TOLLGATE_INFO_ENDPOINT,
                apiKeyConfig.getHighwayApiKey(),
                routeNo);

        log.info("[고속도로 API] 톨게이트 목록 조회 - 노선: {}", routeNo);

        return executeGet(url, "Highway Tollgate List", MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * Fallback 통행료 계산 (API 실패 시 거리 기반)
     *
     * @param distanceKm 주행 거리 (km)
     * @param vehicleClass 차종 (1~5종)
     * @return 계산된 기본 통행료 (원)
     */
    public int calculateFallbackFee(double distanceKm, int vehicleClass) {
        // 차종별 기본 단가 (원/km)
        int baseRate;
        switch (vehicleClass) {
            case 1: // 경차
                baseRate = 38; // 경차는 일반의 50%
                break;
            case 2: // 승용차 (기준)
                baseRate = 76;
                break;
            case 3: // 중형차
                baseRate = 99; // 기준의 1.3배
                break;
            case 4: // 대형차
                baseRate = 122; // 기준의 1.6배
                break;
            case 5: // 특수차
                baseRate = 152; // 기준의 2.0배
                break;
            default:
                baseRate = 76; // 기본값 (승용차)
        }

        int calculatedFee = (int) Math.round(distanceKm * baseRate);

        // 최소 요금 1,000원
        if (calculatedFee < 1000) {
            calculatedFee = 1000;
        }

        log.warn("[고속도로 Fallback] 거리 기반 요금 계산 - 거리: {}km, 차종: {}종, 계산 요금: {}원",
                distanceKm, vehicleClass, calculatedFee);

        return calculatedFee;
    }

    /**
     * 할인율 계산 (정책 기반)
     *
     * @param vehicleType 차량 유형 (경차, 승용차, 전기차 등)
     * @param isElectric 전기차 여부
     * @param isDisabled 장애인 차량 여부
     * @param isHipass 하이패스 사용 여부
     * @param isRushHour 출퇴근 시간대 여부
     * @return 총 할인율 (0.0 ~ 1.0)
     */
    public double calculateDiscountRate(String vehicleType, boolean isElectric, boolean isDisabled,
                                       boolean isHipass, boolean isRushHour) {
        double totalDiscount = 0.0;

        // 경차 할인: 50%
        if ("COMPACT".equalsIgnoreCase(vehicleType) || "1종".equals(vehicleType)) {
            totalDiscount += 0.50;
            log.debug("[할인 적용] 경차 50%");
        }

        // 전기차 할인: 50%
        if (isElectric) {
            totalDiscount += 0.50;
            log.debug("[할인 적용] 전기차 50%");
        }

        // 장애인 차량 할인: 50%
        if (isDisabled) {
            totalDiscount += 0.50;
            log.debug("[할인 적용] 장애인 차량 50%");
        }

        // 하이패스 할인: 10%
        if (isHipass) {
            totalDiscount += 0.10;
            log.debug("[할인 적용] 하이패스 10%");
        }

        // 출퇴근 시간대 할인: 20% (06~09시, 18~20시)
        if (isRushHour) {
            totalDiscount += 0.20;
            log.debug("[할인 적용] 출퇴근 시간대 20%");
        }

        // 최대 할인율 80% 제한
        if (totalDiscount > 0.80) {
            totalDiscount = 0.80;
            log.info("[할인 제한] 최대 할인율 80% 적용");
        }

        log.info("[총 할인율] {}%", (int)(totalDiscount * 100));

        return totalDiscount;
    }

    /**
     * 최종 통행료 계산
     *
     * @param baseFee 기본 통행료
     * @param discountRate 할인율 (0.0 ~ 1.0)
     * @return 최종 통행료 (원)
     */
    public int calculateFinalFee(int baseFee, double discountRate) {
        int discountAmount = (int) Math.round(baseFee * discountRate);
        int finalFee = baseFee - discountAmount;

        // 최소 요금 100원 (10원 단위 절사)
        finalFee = (finalFee / 10) * 10;
        if (finalFee < 100) {
            finalFee = 100;
        }

        log.info("[최종 요금] 기본: {}원, 할인: {}원, 최종: {}원", baseFee, discountAmount, finalFee);

        return finalFee;
    }

    @Override
    protected String getApiName() {
        return "Korea Expressway Corporation API";
    }
}
