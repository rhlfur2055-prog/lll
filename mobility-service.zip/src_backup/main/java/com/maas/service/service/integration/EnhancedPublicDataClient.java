package com.maas.service.service.integration;

import com.maas.service.config.ApiKeyConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * 공공데이터포털 통합 API 클라이언트
 * KTX, 따릉이, 대기질 등 다양한 API 지원
 */
@Slf4j
@Service
public class EnhancedPublicDataClient extends BaseApiClient {

    private static final int MAX_RETRIES = 3;
    private static final int TIMEOUT_SECONDS = 15;

    private final ApiKeyConfig apiKeyConfig;

    public EnhancedPublicDataClient(WebClient.Builder webClientBuilder, ApiKeyConfig apiKeyConfig) {
        super(webClientBuilder);
        this.apiKeyConfig = apiKeyConfig;
    }

    /**
     * KTX 열차 정보 조회 (캐싱 10분)
     */
    @Cacheable(value = "ktxTrains", key = "#depPlaceId + '-' + #arrPlaceId", unless = "#result == null || #result.contains('error')")
    public String getKtxTrainInfo(String depPlaceId, String arrPlaceId) {
        String url = String.format("https://apis.data.go.kr/B551457/train/v2/trainInfo?serviceKey=%s&depPlaceId=%s&arrPlaceId=%s",
                apiKeyConfig.getKtxApiKey(),
                depPlaceId,
                arrPlaceId);

        return executeGet(url, "KTX Train Info", MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * 공공자전거(따릉이) 대여소 정보 조회 (캐싱 5분)
     */
    @Cacheable(value = "bikeStations", unless = "#result == null || #result.contains('error')")
    public String getBikeStations() {
        String url = String.format("https://apis.data.go.kr/B551982/pbdo/BikeInformation?serviceKey=%s",
                apiKeyConfig.getBikeApiKey());

        return executeGet(url, "Public Bike Stations", MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * 지하철역 정보 조회 (캐싱 1시간)
     */
    @Cacheable(value = "subwayStations", key = "#stationName")
    public String getSubwayStationInfo(String stationName) {
        String url = String.format("https://apis.data.go.kr/1613000/SubwayInfoService/getKwrdFndSubwaySttnList?serviceKey=%s&subwayStationName=%s",
                apiKeyConfig.getPublicDataPortalKey(),
                stationName);

        return executeGet(url, "Subway Station Info - " + stationName, MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * 대기질 정보 조회 (캐싱 30분)
     */
    @Cacheable(value = "airQuality", key = "#sidoName", unless = "#result == null || #result.contains('error')")
    public String getAirQuality(String sidoName) {
        String url = String.format("https://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty?serviceKey=%s&sidoName=%s&returnType=json",
                apiKeyConfig.getAirQualityKey(),
                sidoName);

        return executeGet(url, "Air Quality - " + sidoName, MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * 상점 정보 조회 (캐싱 1일)
     */
    @Cacheable(value = "shopInfo", key = "#key")
    public String getShopInfo(String divId, String key) {
        String url = String.format("https://apis.data.go.kr/B553077/api/open/sdsc2/storeListInUpjong?serviceKey=%s&divId=%s&key=%s",
                apiKeyConfig.getShopApiKey(),
                divId,
                key);

        return executeGet(url, "Shop Info", MAX_RETRIES, TIMEOUT_SECONDS);
    }

    /**
     * 서울시 실시간 도시데이터 (혼잡도) 조회 (캐싱 5분)
     */
    @Cacheable(value = "seoulCongestion", key = "#area", unless = "#result == null || #result.contains('error')")
    public String getSeoulCongestion(String area) {
        String url = String.format("http://openapi.seoul.go.kr:8088/%s/json/citydata/1/5/%s",
                apiKeyConfig.getSeoulCongestionKey(),
                area);

        return executeGet(url, "Seoul Congestion - " + area, MAX_RETRIES, TIMEOUT_SECONDS);
    }

    @Override
    protected String getApiName() {
        return "Public Data Portal APIs";
    }
}
