package com.maas.service.service;

import com.maas.service.entity.PublicParking;
import com.maas.service.repository.PublicParkingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class GyeonggiParkingApiService {

    private final PublicParkingRepository parkingRepository;
    private final RestTemplate restTemplate = new RestTemplate();

    // 경기도 공영주차장 API (실제 API 키로 교체 필요)
    private static final String GYEONGGI_API_KEY = "your-gyeonggi-api-key";
    private static final String GYEONGGI_API_URL = "https://openapi.gg.go.kr/Parking";

    @Transactional
    public int fetchAndSaveGyeonggiParking() {
        log.info("Fetching Gyeonggi parking data...");

        try {
            // API 호출 로직 (실제 구현 시 추가)
            // String response = restTemplate.getForObject(GYEONGGI_API_URL, String.class);

            // Mock data for now
            generateGyeonggiMockData();
            return 30;

        } catch (Exception e) {
            log.error("Failed to fetch Gyeonggi parking data: {}", e.getMessage());
            generateGyeonggiMockData();
        }

        return 0;
    }

    @Transactional
    public void generateGyeonggiMockData() {
        log.info("Generating Gyeonggi mock parking data...");

        List<PublicParking> mockData = List.of(
            // 수원시
            createMockParking("GG-001", "수원역 공영주차장", "경기 수원시 팔달구 매산로 1", 37.266219, 127.001087, 350, 142, "수원시", "팔달구"),
            createMockParking("GG-002", "수원시청 공영주차장", "경기 수원시 팔달구 효원로 241", 37.263570, 127.028723, 280, 98, "수원시", "팔달구"),
            createMockParking("GG-003", "수원월드컵경기장 주차장", "경기 수원시 팔달구 월드컵로 310", 37.286878, 127.036854, 500, 245, "수원시", "팔달구"),

            // 성남시
            createMockParking("GG-004", "서현역 공영주차장", "경기 성남시 분당구 서현동 255", 37.385472, 127.123558, 300, 135, "성남시", "분당구"),
            createMockParking("GG-005", "야탑역 공영주차장", "경기 성남시 분당구 야탑동 353", 37.411482, 127.128021, 280, 122, "성남시", "분당구"),
            createMockParking("GG-006", "모란역 공영주차장", "경기 성남시 중원구 성남대로 997", 37.404481, 127.146071, 250, 88, "성남시", "중원구"),

            // 고양시
            createMockParking("GG-007", "일산역 공영주차장", "경기 고양시 일산동구 중앙로 1275", 37.696342, 126.770729, 320, 156, "고양시", "일산동구"),
            createMockParking("GG-008", "정발산역 공영주차장", "경기 고양시 일산동구 정발산로 24", 37.638390, 126.776089, 280, 112, "고양시", "일산동구"),
            createMockParking("GG-009", "킨텍스 공영주차장", "경기 고양시 일산서구 킨텍스로 217-60", 37.668819, 126.747234, 800, 345, "고양시", "일산서구"),

            // 용인시
            createMockParking("GG-010", "기흥역 공영주차장", "경기 용인시 기흥구 구갈동 597", 37.275874, 127.115631, 300, 145, "용인시", "기흥구"),
            createMockParking("GG-011", "수지구청 공영주차장", "경기 용인시 수지구 포은대로 435", 37.326372, 127.093812, 250, 98, "용인시", "수지구"),

            // 부천시
            createMockParking("GG-012", "부천역 공영주차장", "경기 부천시 원미구 부천로 1", 37.483607, 126.783073, 280, 124, "부천시", "원미구"),
            createMockParking("GG-013", "부천시청 공영주차장", "경기 부천시 원미구 신흥로 210", 37.502822, 126.766145, 220, 87, "부천시", "원미구"),
            createMockParking("SEL-014", "상동역 공영주차장", "경기 부천시 원미구 상동로 85", 37.543381, 126.763071, 300, 142, "부천시", "원미구"),

            // 안양시
            createMockParking("GG-015", "안양역 공영주차장", "경기 안양시 만안구 안양로 307", 37.402134, 126.922743, 260, 98, "안양시", "만안구"),
            createMockParking("GG-016", "평촌역 공영주차장", "경기 안양시 동안구 시민대로 180", 37.389234, 126.950872, 320, 145, "안양시", "동안구"),

            // 안산시
            createMockParking("GG-017", "중앙역 공영주차장", "경기 안산시 단원구 광덕대로 195", 37.308234, 126.838723, 280, 112, "안산시", "단원구"),
            createMockParking("GG-018", "고잔역 공영주차장", "경기 안산시 단원구 고잔동 541", 37.321234, 126.832981, 240, 96, "안산시", "단원구"),

            // 남양주시
            createMockParking("GG-019", "다산역 공영주차장", "경기 남양주시 다산중앙로 80", 37.565823, 127.145672, 300, 134, "남양주시", "다산동"),
            createMockParking("GG-020", "별내역 공영주차장", "경기 남양주시 별내동 192", 37.641234, 127.125872, 250, 98, "남양주시", "별내동"),

            // 화성시
            createMockParking("GG-021", "병점역 공영주차장", "경기 화성시 병점동 490", 37.199234, 126.982743, 280, 124, "화성시", "병점동"),
            createMockParking("GG-022", "동탄역 공영주차장", "경기 화성시 동탄중앙로 130", 37.206234, 127.073812, 400, 178, "화성시", "동탄동"),

            // 의정부시
            createMockParking("GG-023", "의정부역 공영주차장", "경기 의정부시 의정부동 228", 37.738234, 127.046723, 280, 112, "의정부시", "의정부동"),
            createMockParking("GG-024", "의정부시청 공영주차장", "경기 의정부시 녹양로 90", 37.745234, 127.033981, 220, 87, "의정부시", "의정부동"),

            // 파주시
            createMockParking("GG-025", "파주출판단지 공영주차장", "경기 파주시 문발로 242", 37.760234, 126.723812, 350, 156, "파주시", "문발동"),

            // 시흥시
            createMockParking("GG-026", "시흥시청 공영주차장", "경기 시흥시 시청로 20", 37.380234, 126.802743, 240, 98, "시흥시", "시흥동"),
            createMockParking("GG-027", "정왕역 공영주차장", "경기 시흥시 정왕동 1778", 37.370234, 126.740872, 280, 124, "시흥시", "정왕동"),

            // 광명시
            createMockParking("GG-028", "광명역 공영주차장", "경기 광명시 일직동 17", 37.416234, 126.884723, 500, 234, "광명시", "일직동"),

            // 김포시
            createMockParking("GG-029", "김포공항역 공영주차장", "경기 김포시 공항동 1571", 37.562434, 126.801058, 600, 278, "김포시", "공항동"),
            createMockParking("GG-030", "장기역 공영주차장", "경기 김포시 장기동 2174", 37.649234, 126.713812, 260, 112, "김포시", "장기동")
        );

        mockData.forEach(parking -> {
            if (parkingRepository.findByParkingCode(parking.getParkingCode()).isEmpty()) {
                parkingRepository.save(parking);
            }
        });

        log.info("Generated {} Gyeonggi mock parking locations", mockData.size());
    }

    private PublicParking createMockParking(String code, String name, String address,
                                           double lat, double lng, int total, int available,
                                           String city, String district) {
        return PublicParking.builder()
            .parkingCode(code)
            .parkingName(name)
            .address(address)
            .latitude(lat)
            .longitude(lng)
            .totalSpaces(total)
            .availableSpaces(available)
            .parkingType("노외")
            .operationType("공영")
            .weekdayBeginTime("00:00")
            .weekdayEndTime("24:00")
            .weekendBeginTime("00:00")
            .weekendEndTime("24:00")
            .rates("기본 30분 1,000원, 추가 10분당 500원")
            .payMethod("현금, 카드, 모바일")
            .telephone("031-1234-5678")
            .region("경기")
            .district(city + " " + district)
            .build();
    }
}
