package com.maas.service.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maas.service.entity.TollRecord;
import com.maas.service.entity.Vehicle;
import com.maas.service.repository.TollRecordRepository;
import com.maas.service.repository.VehicleRepository;
import com.maas.service.service.integration.HighwayApiClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

/**
 * 고속도로 통행료 관리 서비스
 * 한국도로공사 API 연동 및 통행료 계산
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class HighwayTollService {

    private final HighwayApiClient highwayApiClient;
    private final TollRecordRepository tollRecordRepository;
    private final VehicleRepository vehicleRepository;
    private final UserService userService;
    private final ObjectMapper objectMapper;

    /**
     * 고속도로 진입 기록
     *
     * @param userId 사용자 ID
     * @param vehicleNumber 차량번호
     * @param entryTollgate 진입 톨게이트명
     * @param entryTollgateCode 진입 톨게이트 코드
     * @param routeName 노선명 (경부선, 남해선 등)
     * @return 생성된 통행 기록
     */
    @Transactional
    public TollRecord recordEntry(Long userId, String vehicleNumber, String entryTollgate,
                                  String entryTollgateCode, String routeName) {
        // 기존에 진행 중인 통행이 있는지 확인
        Optional<TollRecord> activeRecord = tollRecordRepository.findActiveRecordByUserId(userId);
        if (activeRecord.isPresent()) {
            throw new RuntimeException("이미 진행 중인 통행이 있습니다. 먼저 출구를 통과해주세요.");
        }

        // 차량 정보 조회
        Vehicle vehicle = vehicleRepository.findByVehicleNumber(vehicleNumber)
                .orElseThrow(() -> new RuntimeException("등록되지 않은 차량입니다: " + vehicleNumber));

        // 차종 결정 (Vehicle 엔티티의 vehicleClass 활용)
        String vehicleType = determineVehicleType(vehicle);

        TollRecord record = TollRecord.builder()
                .userId(userId)
                .vehicleNumber(vehicleNumber)
                .entryTollgate(entryTollgate)
                .entryTollgateCode(entryTollgateCode)
                .exitTollgate("") // 아직 미정
                .exitTollgateCode("")
                .routeName(routeName)
                .vehicleType(vehicleType)
                .entryTime(LocalDateTime.now())
                .exitTime(null) // 진입 시에는 null
                .build();

        TollRecord saved = tollRecordRepository.save(record);

        log.info("[고속도로 진입] 사용자: {}, 차량: {}, 톨게이트: {}, 시간: {}",
                userId, vehicleNumber, entryTollgate, saved.getEntryTime());

        return saved;
    }

    /**
     * 고속도로 출구 통과 및 통행료 계산
     *
     * @param userId 사용자 ID
     * @param exitTollgate 출구 톨게이트명
     * @param exitTollgateCode 출구 톨게이트 코드
     * @param paymentMethod 결제 방법 (HIPASS, CASH, CARD)
     * @param routeNo 노선번호 (API 조회용)
     * @param distanceKm 주행 거리 (km)
     * @return 계산된 통행료 정보
     */
    @Transactional
    public TollRecord recordExit(Long userId, String exitTollgate, String exitTollgateCode,
                                 String paymentMethod, String routeNo, Double distanceKm) {
        // 진행 중인 통행 기록 조회
        TollRecord record = tollRecordRepository.findActiveRecordByUserId(userId)
                .orElseThrow(() -> new RuntimeException("진입 기록이 없습니다. 먼저 입구를 통과해주세요."));

        LocalDateTime exitTime = LocalDateTime.now();

        // 출구 정보 업데이트
        record.setExitTollgate(exitTollgate);
        record.setExitTollgateCode(exitTollgateCode);
        record.setExitTime(exitTime);
        record.setPaymentMethod(paymentMethod);
        record.setDistanceKm(distanceKm);

        // 차량 정보 조회
        Vehicle vehicle = vehicleRepository.findByVehicleNumber(record.getVehicleNumber())
                .orElseThrow(() -> new RuntimeException("차량 정보를 찾을 수 없습니다"));

        // 차종 코드 추출 (1~5종)
        int vehicleClass = extractVehicleClass(record.getVehicleType());

        // 출퇴근 시간대 판별 (06~09시, 18~20시)
        boolean isRushHour = isRushHour(exitTime.toLocalTime());
        record.setIsRushHour(isRushHour);

        // 기본 통행료 조회 (API 또는 Fallback)
        int baseFee = fetchTollFee(routeNo, record.getEntryTollgateCode(), exitTollgateCode,
                vehicleClass, distanceKm);
        record.setBaseFee(baseFee);

        // 할인율 계산
        boolean isHipass = "HIPASS".equalsIgnoreCase(paymentMethod);
        double discountRate = highwayApiClient.calculateDiscountRate(
                record.getVehicleType(),
                vehicle.getIsElectric(),
                vehicle.getIsDisabled(),
                isHipass,
                isRushHour
        );

        // 최종 통행료 계산
        int finalFee = highwayApiClient.calculateFinalFee(baseFee, discountRate);
        int discountAmount = baseFee - finalFee;

        record.setDiscountAmount(discountAmount);
        record.setFinalFee(finalFee);

        // 할인 사유 기록
        String discountReason = buildDiscountReason(record.getVehicleType(), vehicle.getIsElectric(),
                vehicle.getIsDisabled(), isHipass, isRushHour, discountRate);
        record.setDiscountReason(discountReason);

        // 저장
        TollRecord saved = tollRecordRepository.save(record);

        log.info("[고속도로 출구] 사용자: {}, 톨게이트: {}, 기본 요금: {}원, 할인: {}원, 최종: {}원",
                userId, exitTollgate, baseFee, discountAmount, finalFee);

        // K-Pass 마일리지 적립 (통행료의 3%)
        int earnedPoints = (int) Math.round(finalFee * 0.03);
        if (earnedPoints > 0) {
            userService.earnPoints(userId, earnedPoints,
                    String.format("고속도로 이용 (%s → %s)", record.getEntryTollgate(), exitTollgate));
            log.info("[마일리지 적립] 사용자: {}, 적립: {}P (통행료 {}원의 3%)", userId, earnedPoints, finalFee);
        }

        return saved;
    }

    /**
     * 통행료 사전 조회 (예상 요금)
     *
     * @param entryCode 진입 톨게이트 코드
     * @param exitCode 출구 톨게이트 코드
     * @param vehicleNumber 차량번호
     * @param routeNo 노선번호
     * @param distanceKm 예상 거리
     * @return 예상 통행료 정보 (JSON)
     */
    public String calculateExpectedFee(String entryCode, String exitCode, String vehicleNumber,
                                      String routeNo, Double distanceKm) {
        try {
            // 차량 정보 조회
            Vehicle vehicle = vehicleRepository.findByVehicleNumber(vehicleNumber)
                    .orElseThrow(() -> new RuntimeException("등록되지 않은 차량입니다"));

            int vehicleClass = vehicle.getVehicleClass() != null ? vehicle.getVehicleClass() : 2;

            // 기본 요금 조회
            int baseFee = fetchTollFee(routeNo, entryCode, exitCode, vehicleClass, distanceKm);

            // 하이패스 사용 가정
            double discountRate = highwayApiClient.calculateDiscountRate(
                    determineVehicleType(vehicle),
                    vehicle.getIsElectric(),
                    vehicle.getIsDisabled(),
                    true, // 하이패스 가정
                    false // 비혼잡 시간대 가정
            );

            int finalFee = highwayApiClient.calculateFinalFee(baseFee, discountRate);
            int discountAmount = baseFee - finalFee;

            // JSON 응답 생성
            String result = String.format(
                    "{\"baseFee\": %d, \"discountAmount\": %d, \"finalFee\": %d, \"discountRate\": %.2f, \"vehicleClass\": %d}",
                    baseFee, discountAmount, finalFee, discountRate * 100, vehicleClass
            );

            log.info("[예상 요금] 차량: {}, 기본: {}원, 최종: {}원", vehicleNumber, baseFee, finalFee);

            return result;

        } catch (Exception e) {
            log.error("[예상 요금 계산 실패] {}", e.getMessage());
            return "{\"error\": \"" + e.getMessage() + "\"}";
        }
    }

    /**
     * 사용자별 통행 내역 조회
     */
    public List<TollRecord> getUserTollHistory(Long userId) {
        return tollRecordRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    /**
     * 차량별 통행 내역 조회
     */
    public List<TollRecord> getVehicleTollHistory(String vehicleNumber) {
        return tollRecordRepository.findByVehicleNumberOrderByCreatedAtDesc(vehicleNumber);
    }

    /**
     * 월간 통행료 합계 조회
     */
    public Integer getMonthlyTollSum(Long userId, int year, int month) {
        Integer sum = tollRecordRepository.sumMonthlyFeeByUserId(userId, year, month);
        return sum != null ? sum : 0;
    }

    /**
     * 통행료 조회 (API 또는 Fallback)
     */
    private int fetchTollFee(String routeNo, String entryCode, String exitCode,
                            int vehicleClass, Double distanceKm) {
        try {
            String response = highwayApiClient.getTollFee(routeNo, entryCode, exitCode, vehicleClass);

            // JSON 파싱
            JsonNode root = objectMapper.readTree(response);

            // API 응답에 에러가 있는지 확인
            if (root.has("error")) {
                log.warn("[API 실패] Fallback 모드로 전환: {}", root.get("error").asText());
                return highwayApiClient.calculateFallbackFee(distanceKm, vehicleClass);
            }

            // 실제 API 응답 구조에 맞게 조정 필요 (예시)
            if (root.has("list") && root.get("list").isArray() && root.get("list").size() > 0) {
                JsonNode firstItem = root.get("list").get(0);
                if (firstItem.has("tollFee")) {
                    return firstItem.get("tollFee").asInt();
                }
            }

            // 파싱 실패 시 Fallback
            log.warn("[API 파싱 실패] Fallback 모드로 전환");
            return highwayApiClient.calculateFallbackFee(distanceKm, vehicleClass);

        } catch (Exception e) {
            log.error("[통행료 조회 실패] Fallback 사용: {}", e.getMessage());
            return highwayApiClient.calculateFallbackFee(distanceKm, vehicleClass);
        }
    }

    /**
     * 차량 유형 결정
     */
    private String determineVehicleType(Vehicle vehicle) {
        if (vehicle.getVehicleClass() != null) {
            return vehicle.getVehicleClass() + "종";
        }

        // vehicleType 기반 매핑
        String type = vehicle.getVehicleType();
        if (type == null) return "2종"; // 기본값: 승용차

        switch (type.toUpperCase()) {
            case "COMPACT":
                return "1종"; // 경차
            case "SEDAN":
            case "SUV":
                return "2종"; // 승용차
            case "TRUCK":
                return "4종"; // 화물차
            case "SPECIAL":
                return "5종"; // 특수차량
            default:
                return "2종"; // 기본값
        }
    }

    /**
     * 차종 코드 추출
     */
    private int extractVehicleClass(String vehicleType) {
        if (vehicleType == null || vehicleType.isEmpty()) return 2;

        // "1종", "2종" 형식에서 숫자 추출
        String digit = vehicleType.replaceAll("[^0-9]", "");
        if (!digit.isEmpty()) {
            return Integer.parseInt(digit);
        }

        return 2; // 기본값: 승용차
    }

    /**
     * 출퇴근 시간대 판별
     */
    private boolean isRushHour(LocalTime time) {
        int hour = time.getHour();
        // 06~09시, 18~20시
        return (hour >= 6 && hour < 9) || (hour >= 18 && hour < 20);
    }

    /**
     * 할인 사유 문자열 생성
     */
    private String buildDiscountReason(String vehicleType, Boolean isElectric, Boolean isDisabled,
                                      boolean isHipass, boolean isRushHour, double discountRate) {
        StringBuilder sb = new StringBuilder();

        if ("1종".equals(vehicleType)) {
            sb.append("경차 50%");
        }

        if (Boolean.TRUE.equals(isElectric)) {
            if (sb.length() > 0) sb.append(", ");
            sb.append("전기차 50%");
        }

        if (Boolean.TRUE.equals(isDisabled)) {
            if (sb.length() > 0) sb.append(", ");
            sb.append("장애인 차량 50%");
        }

        if (isHipass) {
            if (sb.length() > 0) sb.append(", ");
            sb.append("하이패스 10%");
        }

        if (isRushHour) {
            if (sb.length() > 0) sb.append(", ");
            sb.append("출퇴근 시간대 20%");
        }

        if (sb.length() == 0) {
            return "할인 없음";
        }

        sb.append(String.format(" (총 %.0f%%)", discountRate * 100));

        return sb.toString();
    }
}
