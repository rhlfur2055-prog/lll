package com.maas.service.service;

import com.maas.service.entity.PublicParking;
import com.maas.service.repository.PublicParkingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class SeoulParkingApiService {

    private final PublicParkingRepository parkingRepository;
    private final RestTemplate restTemplate = new RestTemplate();

    // 서울 공영주차장 API
    private static final String SEOUL_API_KEY = "6a4e6a6a6b6b6b6a6a6a6e6f6f6f6f6f";
    private static final String SEOUL_API_URL = "http://openapi.seoul.go.kr:8088/{key}/xml/GetParkingInfo/1/1000/";

    @Transactional
    public int fetchAndSaveSeoulParking() {
        log.info("Fetching Seoul parking data...");

        try {
            String url = SEOUL_API_URL.replace("{key}", SEOUL_API_KEY);
            // Uncomment when real API is available
            // String response = restTemplate.getForObject(url, String.class);
            // List<PublicParking> parkingList = parseSeoulParkingXml(response);

            // For now, generate mock data
            generateSeoulMockData();
            return 20;

        } catch (Exception e) {
            log.error("Failed to fetch Seoul parking data: {}", e.getMessage());
            generateSeoulMockData();
        }

        return 0;
    }

    @Transactional
    public void generateSeoulMockData() {
        log.info("Generating Seoul mock parking data...");

        List<PublicParking> mockData = List.of(
            createMockParking("SEL-001", "강남역 공영주차장", "서울 강남구 강남대로 396", 37.498095, 127.027610, 200, 45, "강남구"),
            createMockParking("SEL-002", "역삼역 공영주차장", "서울 강남구 테헤란로 151", 37.500510, 127.035760, 150, 32, "강남구"),
            createMockParking("SEL-003", "선릉역 공영주차장", "서울 강남구 선릉로 428", 37.504630, 127.048960, 180, 55, "강남구"),
            createMockParking("SEL-004", "삼성역 공영주차장", "서울 강남구 영동대로 513", 37.508490, 127.063370, 250, 78, "강남구"),
            createMockParking("SEL-005", "홍대입구역 공영주차장", "서울 마포구 양화로 160", 37.557192, 126.925381, 300, 120, "마포구"),
            createMockParking("SEL-006", "신촌역 공영주차장", "서울 서대문구 신촌로 83", 37.555134, 126.936893, 220, 88, "서대문구"),
            createMockParking("SEL-007", "서울역 공영주차장", "서울 용산구 한강대로 405", 37.554264, 126.970626, 400, 156, "용산구"),
            createMockParking("SEL-008", "시청역 공영주차장", "서울 중구 세종대로 110", 37.564214, 126.976738, 180, 65, "중구"),
            createMockParking("SEL-009", "광화문 공영주차장", "서울 종로구 세종대로 172", 37.571607, 126.976882, 350, 142, "종로구"),
            createMockParking("SEL-010", "종로3가 공영주차장", "서울 종로구 종로 151", 37.571607, 126.991806, 200, 75, "종로구"),
            createMockParking("SEL-011", "잠실역 공영주차장", "서울 송파구 올림픽로 240", 37.513292, 127.100109, 500, 225, "송파구"),
            createMockParking("SEL-012", "신도림역 공영주차장", "서울 구로구 경인로 661", 37.508426, 126.891234, 280, 98, "구로구"),
            createMockParking("SEL-013", "구로디지털단지역 공영주차장", "서울 구로구 디지털로 272", 37.485302, 126.901489, 320, 145, "구로구"),
            createMockParking("SEL-014", "여의도역 공영주차장", "서울 영등포구 여의대로 108", 37.521624, 126.924377, 280, 112, "영등포구"),
            createMockParking("SEL-015", "사당역 공영주차장", "서울 동작구 사당로 272", 37.476573, 126.981715, 240, 88, "동작구"),
            createMockParking("SEL-016", "교대역 공영주차장", "서울 서초구 서초중앙로 194", 37.492567, 127.012506, 190, 72, "서초구"),
            createMockParking("SEL-017", "고속터미널 공영주차장", "서울 서초구 신반포로 194", 37.504520, 127.004737, 450, 189, "서초구"),
            createMockParking("SEL-018", "노원역 공영주차장", "서울 노원구 동일로 1414", 37.655370, 127.061370, 300, 135, "노원구"),
            createMockParking("SEL-019", "왕십리역 공영주차장", "서울 성동구 왕십리로 83", 37.561887, 127.037523, 260, 98, "성동구"),
            createMockParking("SEL-020", "건대입구역 공영주차장", "서울 광진구 능동로 120", 37.540550, 127.070180, 280, 124, "광진구")
        );

        mockData.forEach(parking -> {
            if (parkingRepository.findByParkingCode(parking.getParkingCode()).isEmpty()) {
                parkingRepository.save(parking);
            }
        });

        log.info("Generated {} Seoul mock parking locations", mockData.size());
    }

    private PublicParking createMockParking(String code, String name, String address,
                                           double lat, double lng, int total, int available, String district) {
        return PublicParking.builder()
            .parkingCode(code)
            .parkingName(name)
            .address(address)
            .latitude(lat)
            .longitude(lng)
            .totalSpaces(total)
            .availableSpaces(available)
            .parkingType("노외")
            .operationType("공영")
            .weekdayBeginTime("00:00")
            .weekdayEndTime("24:00")
            .weekendBeginTime("00:00")
            .weekendEndTime("24:00")
            .rates("기본 30분 1,000원, 추가 10분당 500원")
            .payMethod("현금, 카드, 모바일")
            .telephone("02-1234-5678")
            .region("서울")
            .district(district)
            .build();
    }
}
