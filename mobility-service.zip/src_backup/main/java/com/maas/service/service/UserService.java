package com.maas.service.service;

import com.maas.service.entity.PointTransaction;
import com.maas.service.entity.User;
import com.maas.service.repository.PointTransactionRepository;
import com.maas.service.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepository;
    private final PointTransactionRepository pointTransactionRepository;

    /**
     * 회원가입
     */
    @Transactional
    public User register(String name, String email, String password, String phone) {
        // 이메일 중복 체크
        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("이미 가입된 이메일입니다");
        }

        // 사용자 생성 (기본 1000P 지급)
        User user = User.builder()
                .name(name)
                .email(email)
                .password(password) // 실제로는 암호화 필요
                .phone(phone)
                .points(1000)
                .build();

        User savedUser = userRepository.save(user);

        // 가입 포인트 트랜잭션 기록
        PointTransaction transaction = PointTransaction.builder()
                .userId(savedUser.getId())
                .amount(1000)
                .type("EARN")
                .reason("회원가입 축하 포인트")
                .build();

        pointTransactionRepository.save(transaction);

        log.info("User registered: {}", email);
        return savedUser;
    }

    /**
     * 로그인
     */
    public Optional<User> login(String email, String password) {
        Optional<User> user = userRepository.findByEmail(email);

        if (user.isPresent() && user.get().getPassword().equals(password)) {
            log.info("User logged in: {}", email);
            return user;
        }

        return Optional.empty();
    }

    /**
     * 사용자 조회
     */
    public Optional<User> getUserById(Long userId) {
        return userRepository.findById(userId);
    }

    /**
     * 포인트 적립
     */
    @Transactional
    public void earnPoints(Long userId, Integer amount, String reason) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setPoints(user.getPoints() + amount);
        userRepository.save(user);

        PointTransaction transaction = PointTransaction.builder()
                .userId(userId)
                .amount(amount)
                .type("EARN")
                .reason(reason)
                .build();

        pointTransactionRepository.save(transaction);

        log.info("Points earned: userId={}, amount={}, reason={}", userId, amount, reason);
    }

    /**
     * 포인트 사용
     */
    @Transactional
    public void usePoints(Long userId, Integer amount, String reason) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getPoints() < amount) {
            throw new RuntimeException("포인트가 부족합니다");
        }

        user.setPoints(user.getPoints() - amount);
        userRepository.save(user);

        PointTransaction transaction = PointTransaction.builder()
                .userId(userId)
                .amount(amount)
                .type("USE")
                .reason(reason)
                .build();

        pointTransactionRepository.save(transaction);

        log.info("Points used: userId={}, amount={}, reason={}", userId, amount, reason);
    }

    /**
     * 포인트 내역 조회
     */
    public List<PointTransaction> getPointHistory(Long userId) {
        return pointTransactionRepository.findByUserIdOrderByTransactionTimeDesc(userId);
    }
}
