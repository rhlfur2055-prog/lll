package com.maas.service.domain.highway;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TB_HIGHWAY_TOLL")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HighwayEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_highway_gen")
    @SequenceGenerator(name = "seq_highway_gen", sequenceName = "SEQ_HIGHWAY", allocationSize = 1)
    @Column(name = "TOLL_ID")
    private Long id;

    @Column(name = "ENTRY_GATE")
    private String entryGate;

    @Column(name = "EXIT_GATE")
    private String exitGate;

    @Column(name = "AMOUNT")
    private String amount;

    @Column(name = "ESTIMATED_TIME")
    private String estimatedTime;

    @Column(name = "QUERY_DATE")
    private LocalDateTime queryDate;

    @PrePersist
    public void prePersist() {
        this.queryDate = LocalDateTime.now();
    }
}
