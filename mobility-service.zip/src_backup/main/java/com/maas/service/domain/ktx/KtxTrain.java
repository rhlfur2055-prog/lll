package com.maas.service.domain.ktx;

/**
 * Legacy file neutralized to prevent build errors.
 * Use KtxEntity instead.
 */
public class KtxTrain {
}
