package com.maas.service.domain.highway;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import jakarta.annotation.PostConstruct;

// Internal Repository
@Repository
interface HighwayRepository extends JpaRepository<HighwayEntity, Long> {
}

@Service
@RequiredArgsConstructor
@Slf4j
public class HighwayService {

    private final WebClient webClient;
    private final HighwayRepository highwayRepository;

    // API Key Injection (Strict Rule)
    @Value("${highway.api.key}")
    private String highwayApiKey;

    @PostConstruct
    public void init() {
        log.info("HighwayService Initialized. Key injected successfully.");
    }

    public HighwayEntity createMockDataAndSave(String entry, String exit) {
        log.info("Using Highway API Key: {}", highwayApiKey != null ? "PRESENT" : "NULL");

        HighwayEntity entity = HighwayEntity.builder()
                .entryGate(entry)
                .exitGate(exit)
                .amount("5500")
                .estimatedTime("1시간 45분")
                .build();
        
        return highwayRepository.save(entity);
    }
    
    // TestController에서 사용할 메서드 (Bulletproof Version)
    public HighwayEntity fetchAndSaveTollInfo(String entry, String exit) {
        log.info("Fetching Highway Toll Info via API (Simulated) Key: {}", highwayApiKey != null ? "PRESENT" : "NULL");
        
        try {
             // 1. 실제 외부 API 호출 시도 (현재는 주석 처리, 실제 연결 시 활성화)
             /*
             String response = webClient.get()
                    .uri("http://data.ex.co.kr/...")
                    .header("Authorization", highwayApiKey)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(); // Blocking for sync logic
             */
             
             // 2. 강제 예외 발생 시뮬레이션 (API 연결이 되어있지 않으므로)
             throw new RuntimeException("External API Connection Timeout (Simulated)");
             
        } catch (Exception e) {
            // 3. Fallback: 어떤 에러가 나도 절대 멈추지 않고 더미 데이터 저장
            log.warn("API Call Failed -> Using Fallback Data. Error: {}", e.getMessage());
            
            HighwayEntity fallbackEntity = HighwayEntity.builder()
                .entryGate(entry)
                .exitGate(exit)
                .amount("45000") // Fallback Amount
                .estimatedTime("4시간 30분")
                .build();
                
            // DB 저장 후 리턴
            log.info("Saving Fallback Entity to DB: {}", fallbackEntity);
            return highwayRepository.save(fallbackEntity);
        }
    }
}
