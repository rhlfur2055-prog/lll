package com.maas.service.domain.ktx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TB_KTX_TRAIN")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class KtxEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_ktx_gen")
    @SequenceGenerator(name = "seq_ktx_gen", sequenceName = "SEQ_KTX", allocationSize = 1)
    @Column(name = "TRAIN_ID")
    private Long id;

    @Column(name = "TRAIN_NO")
    private String trainNo;

    @Column(name = "DEP_PLACE")
    private String depPlace;

    @Column(name = "ARR_PLACE")
    private String arrPlace;

    @Column(name = "DEP_TIME")
    private String depTime;

    @Column(name = "ARR_TIME")
    private String arrTime;

    @Column(name = "CHARGE")
    private String charge;

    @Column(name = "QUERY_DATE")
    private LocalDateTime queryDate;

    @PrePersist
    public void prePersist() {
        this.queryDate = LocalDateTime.now();
    }
}
