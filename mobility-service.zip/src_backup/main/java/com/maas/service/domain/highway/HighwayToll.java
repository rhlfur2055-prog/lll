package com.maas.service.domain.highway;

/**
 * Legacy file neutralized to prevent build errors.
 * Use HighwayEntity instead.
 */
public class HighwayToll {
}
