package com.maas.service.domain.ktx; 
 
import com.maas.service.entity.KtxSchedule; 
import org.springframework.data.jpa.repository.JpaRepository; 
import org.springframework.stereotype.Repository; 
import java.util.List; 
 
@Repository 
public interface KtxRepository extends JpaRepository<KtxSchedule, Long> { 
    List<KtxSchedule> findByDepPlaceAndArrPlace(String depPlace, String arrPlace); 
} 
