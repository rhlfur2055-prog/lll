package com.maas.service.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maas.service.entity.SubwayStation;
import com.maas.service.repository.SubwayStationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;


import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * 지하철 역 데이터 초기화
 * 애플리케이션 시작 시 subway-stations.json 파일을 읽어서 DB에 저장
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final SubwayStationRepository subwayStationRepository;
    private final ObjectMapper objectMapper;

    @Override
    public void run(String... args) throws Exception {
        // 이미 데이터가 있으면 스킵
        try {
            long count = subwayStationRepository.count();
            if (count > 0) {
                log.info("지하철 역 데이터가 이미 존재합니다. ({}개)", count);
                return;
            }
        } catch (Exception e) {
            log.info("테이블이 없거나 에러 발생, 데이터 초기화를 진행합니다.");
        }

        log.info("지하철 역 데이터 초기화 시작...");

        try {
            // JSON 파일 읽기
            ClassPathResource resource = new ClassPathResource("data/subway-stations.json");
            InputStream inputStream = resource.getInputStream();

            // JSON을 List<Map>으로 파싱
            List<Map<String, Object>> stationDataList = objectMapper.readValue(
                    inputStream,
                    new TypeReference<List<Map<String, Object>>>() {}
            );

            log.info("JSON 파일에서 {}개의 역 정보를 읽었습니다.", stationDataList.size());

            // 각 역 정보를 Entity로 변환하여 저장
            int savedCount = 0;
            for (Map<String, Object> data : stationDataList) {
                try {
                    SubwayStation station = SubwayStation.builder()
                            .stationName((String) data.get("stationName"))
                            .stationCode((String) data.get("stationCode"))
                            .lineName((String) data.get("lineName"))
                            .lineNumber(String.valueOf(data.get("lineNumber")))
                            .latitude(convertToDouble(data.get("latitude")))
                            .longitude(convertToDouble(data.get("longitude")))
                            .transferLines((String) data.get("transferLines"))
                            .isTransfer(data.get("transferLines") != null &&
                                       !((String) data.get("transferLines")).isEmpty())
                            .build();

                    subwayStationRepository.save(station);
                    savedCount++;
                } catch (Exception e) {
                    log.error("역 정보 저장 실패: {}", data.get("stationName"), e);
                }
            }

            log.info("지하철 역 데이터 초기화 완료: {}개 저장됨", savedCount);

        } catch (IOException e) {
            log.error("지하철 역 데이터 로드 실패", e);
            throw new RuntimeException("지하철 역 데이터 초기화 중 오류 발생", e);
        }
    }

    /**
     * Object를 Double로 변환
     */
    private Double convertToDouble(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Double) {
            return (Double) value;
        }
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        if (value instanceof String) {
            try {
                return Double.parseDouble((String) value);
            } catch (NumberFormatException e) {
                log.warn("Double 변환 실패: {}", value);
                return null;
            }
        }
        return null;
    }
}
