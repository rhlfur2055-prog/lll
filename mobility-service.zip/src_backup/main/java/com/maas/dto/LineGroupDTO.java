package com.maas.dto;

import lombok.*;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LineGroupDTO {
    private String lineName;
    private Integer stationCount;
    private String color;
    private List<StationResponseDTO> stations;
}
