package com.maas.dto;

import lombok.*;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchResultDTO {
    private List<StationResponseDTO> results;
    private Integer totalCount;
}
