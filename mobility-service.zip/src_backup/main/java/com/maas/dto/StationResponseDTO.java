package com.maas.dto;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StationResponseDTO {
    private Long id;
    private String category;
    private String lineName;
    private String stationName;
    private Double latitude;
    private Double longitude;
    private String addInfo;
}
