package com.maas.controller;

import com.maas.domain.MobilityHub;
import com.maas.domain.UserAsset;
import com.maas.service.IntegratedService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@Slf4j
public class IntegratedCoreController {
    private final IntegratedService integratedService;
    
    // User-Agent 기반 자동 라우팅
    @GetMapping("/")
    public String index(@RequestHeader(value = "User-Agent", required = false) String userAgent) {
        log.info("Access from: {}", userAgent);
        
        if (userAgent != null && 
            (userAgent.toLowerCase().contains("mobile") || 
             userAgent.toLowerCase().contains("android") || 
             userAgent.toLowerCase().contains("iphone"))) {
            return "redirect:/mobile/index";
        }
        return "redirect:/web/dashboard";
    }
    
    @GetMapping("/mobile/index")
    public String mobileIndex() {
        return "mobile/index";
    }
    
    @GetMapping("/web/dashboard")
    public String webDashboard() {
        return "web/dashboard";
    }
    
    // 통합 API
    @GetMapping("/api/transport/{type}")
    @ResponseBody
    public List<MobilityHub> getTransportData(@PathVariable String type) {
        switch (type.toUpperCase()) {
            case "SUBWAY": return integratedService.getSubwayStations();
            case "KTX": return integratedService.getKtxStations();
            case "PARKING": return integratedService.getParkingLots();
            case "BIKE": return integratedService.getBikeStations();
            default: return List.of();
        }
    }
    
    @GetMapping("/api/search")
    @ResponseBody
    public List<MobilityHub> search(@RequestParam String keyword) {
        return integratedService.search(keyword);
    }
    
    @GetMapping("/api/kpass/{userId}")
    @ResponseBody
    public Map<String, Object> getMileage(@PathVariable Long userId) {
        UserAsset asset = integratedService.getUserMileage(userId);
        if (asset != null) {
            return Map.of("success", true, "data", asset);
        }
        return Map.of("success", false, "message", "User not found");
    }
}
