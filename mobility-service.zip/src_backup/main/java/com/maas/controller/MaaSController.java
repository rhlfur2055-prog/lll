package com.maas.controller;

import com.maas.service.IntegratedService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@Controller
@RequiredArgsConstructor
@Slf4j
public class MaaSController {
    
    private final IntegratedService integratedService;
    
    @GetMapping("/")
    public String index(@RequestHeader(value = "User-Agent", required = false) String userAgent) {
        log.info("User-Agent: {}", userAgent);
        
        if (userAgent != null) {
            String ua = userAgent.toLowerCase();
            if (ua.contains("mobile") || ua.contains("android") || ua.contains("iphone") || ua.contains("ipad")) {
                log.info("Routing to mobile");
                return "mobile/index";
            }
        }
        
        log.info("Routing to web");
        return "web/index";
    }
    
    @GetMapping("/web")
    public String web() {
        return "web/index";
    }
    
    @GetMapping("/mobile")
    public String mobile() {
        return "mobile/index";
    }
}
