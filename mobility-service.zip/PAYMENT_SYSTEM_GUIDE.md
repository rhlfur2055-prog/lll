# K-MaaS 가상 결제 시스템 구현 가이드

## 📋 개요

K-MaaS 플랫폼의 통합 결제 시스템으로, 다음과 같은 기능을 제공합니다:
- **S-Pay 가상 지갑**: 충전 및 결제
- **포인트 시스템**: 적립 및 사용 (1% 적립률)
- **쿠폰 시스템**: 할인 쿠폰 발급 및 사용
- **예약 통합 관리**: KTX, 지하철, 따릉이, 주차장 통합 예약

## 🎯 시스템 아키텍처

```
외부 API (조회) → 내부 DB (예약/결제)
     ↓                    ↓
  시간표/노선 검색    가상 결제 처리 (SSOT)
```

### 핵심 원칙
1. **외부 API는 조회용**: 실시간 데이터 검색만
2. **내부 DB가 진실의 원천**: 예약/결제는 전부 내부 DB에서 관리
3. **완전한 트랜잭션 로그**: 모든 금액 이동 기록

## 📊 데이터베이스 스키마

### 1. 사용자 관리
```sql
-- USERS 테이블 (OAuth2 연동)
CREATE TABLE USERS (
    USER_ID VARCHAR2(100) PRIMARY KEY,
    EMAIL VARCHAR2(200) NOT NULL UNIQUE,
    NAME VARCHAR2(100),
    PROFILE_IMAGE VARCHAR2(500),
    PROVIDER VARCHAR2(20) NOT NULL,  -- KAKAO, GOOGLE, NAVER
    PROVIDER_ID VARCHAR2(200) NOT NULL,
    STATUS VARCHAR2(20) DEFAULT 'ACTIVE',
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. 결제 시스템
```sql
-- S-PAY 지갑
CREATE TABLE WALLETS (
    WALLET_ID NUMBER PRIMARY KEY,
    USER_ID VARCHAR2(100) REFERENCES USERS(USER_ID),
    BALANCE NUMBER(15,2) DEFAULT 0,
    TOTAL_CHARGED NUMBER(15,2) DEFAULT 0,
    TOTAL_SPENT NUMBER(15,2) DEFAULT 0,
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 포인트
CREATE TABLE POINTS (
    POINT_ID NUMBER PRIMARY KEY,
    USER_ID VARCHAR2(100) REFERENCES USERS(USER_ID),
    BALANCE NUMBER(10) DEFAULT 0,
    TOTAL_EARNED NUMBER(10) DEFAULT 0,
    TOTAL_USED NUMBER(10) DEFAULT 0
);
```

### 3. 쿠폰 시스템
```sql
-- 쿠폰 마스터 (관리자가 발급)
CREATE TABLE COUPON_MASTERS (
    COUPON_MASTER_ID NUMBER PRIMARY KEY,
    COUPON_NAME VARCHAR2(100) NOT NULL,
    COUPON_TYPE VARCHAR2(20),  -- PERCENT, AMOUNT
    DISCOUNT_VALUE NUMBER(10,2),
    VALID_FROM DATE,
    VALID_UNTIL DATE,
    MAX_ISSUE_COUNT NUMBER(10)
);

-- 사용자 쿠폰
CREATE TABLE USER_COUPONS (
    USER_COUPON_ID NUMBER PRIMARY KEY,
    USER_ID VARCHAR2(100) REFERENCES USERS(USER_ID),
    COUPON_MASTER_ID NUMBER REFERENCES COUPON_MASTERS,
    STATUS VARCHAR2(20) DEFAULT 'AVAILABLE'  -- AVAILABLE, USED, EXPIRED
);
```

### 4. 예약 시스템
```sql
-- 통합 예약 테이블
CREATE TABLE RESERVATIONS (
    RESERVATION_ID VARCHAR2(50) PRIMARY KEY,
    USER_ID VARCHAR2(100) REFERENCES USERS(USER_ID),
    TRANSPORT_TYPE VARCHAR2(20),  -- TRAIN, SUBWAY, BIKE, PARKING
    DEPARTURE_PLACE VARCHAR2(200),
    ARRIVAL_PLACE VARCHAR2(200),
    DEPARTURE_TIME TIMESTAMP,
    ORIGINAL_PRICE NUMBER(10,2),
    FINAL_PRICE NUMBER(10,2),
    STATUS VARCHAR2(30) DEFAULT 'PAYMENT_PENDING'
);
```

### 5. 트랜잭션 로그
```sql
-- 결제 트랜잭션 (모든 금액 이동 기록)
CREATE TABLE PAYMENT_TRANSACTIONS (
    TRANSACTION_ID VARCHAR2(50) PRIMARY KEY,
    USER_ID VARCHAR2(100) REFERENCES USERS(USER_ID),
    RESERVATION_ID VARCHAR2(50) REFERENCES RESERVATIONS,
    TRANSACTION_TYPE VARCHAR2(30),  -- CHARGE, PAYMENT, REFUND, POINT_EARN
    AMOUNT NUMBER(15,2),
    BEFORE_BALANCE NUMBER(15,2),
    AFTER_BALANCE NUMBER(15,2),
    STATUS VARCHAR2(20) DEFAULT 'SUCCESS',
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 🔐 보안 설정 (OAuth2)

### application.yml 설정
```yaml
spring:
  security:
    oauth2:
      client:
        registration:
          kakao:
            client-id: ${KAKAO_CLIENT_ID}
            client-secret: ${KAKAO_CLIENT_SECRET}
            redirect-uri: "{baseUrl}/login/oauth2/code/kakao"
          google:
            client-id: ${GOOGLE_CLIENT_ID}
            client-secret: ${GOOGLE_CLIENT_SECRET}
          naver:
            client-id: ${NAVER_CLIENT_ID}
            client-secret: ${NAVER_CLIENT_SECRET}
```

## 💰 결제 플로우

### 1. 회원가입
```
사용자 OAuth2 로그인
  ↓
신규 사용자 감지
  ↓
자동 지급:
- S-Pay 5,000원 환영 보너스
- 10% 할인 환영 쿠폰
```

### 2. 예약 및 결제
```
1. 외부 API로 열차/노선 검색
2. 사용자가 선택 → 예약 생성 (PAYMENT_PENDING)
3. 결제 페이지로 이동
4. 쿠폰/포인트 적용
5. S-Pay 잔액 확인
6. 결제 완료 → 예약 확정 (CONFIRMED)
7. 포인트 1% 자동 적립
```

### 3. 환불
```
1. 예약 취소 요청
2. 취소 수수료 계산 (출발 60분 전까지 무료)
3. 환불 금액 = 결제 금액 - 수수료
4. S-Pay 잔액 환불
5. 예약 상태 변경 (REFUNDED)
```

## 🛠️ 주요 엔티티 클래스

### User.java
```java
@Entity
@Table(name = "USERS")
public class User {
    @Id
    private String userId;
    private String email;
    private String name;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private Wallet wallet;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private Point point;

    public void initializeNewUser() {
        this.wallet = Wallet.createWithWelcomeBonus(this, new BigDecimal("5000"));
        this.point = Point.create(this);
    }
}
```

### Wallet.java
```java
@Entity
@Table(name = "WALLETS")
public class Wallet {
    @Id
    @GeneratedValue
    private Long walletId;

    private BigDecimal balance = BigDecimal.ZERO;

    public void charge(BigDecimal amount) {
        this.balance = this.balance.add(amount);
        this.totalCharged = this.totalCharged.add(amount);
    }

    public void deduct(BigDecimal amount) {
        if (balance.compareTo(amount) < 0) {
            throw new InsufficientBalanceException();
        }
        this.balance = this.balance.subtract(amount);
    }
}
```

## 🌐 REST API 엔드포인트

### PaymentController

#### 1. S-Pay 충전
```http
POST /api/payment/charge
Content-Type: application/json

{
  "amount": 50000
}

Response:
{
  "success": true,
  "data": {
    "transactionId": "TXN-20240112-000001",
    "chargedAmount": 50000,
    "currentBalance": 55000
  }
}
```

#### 2. 결제 처리
```http
POST /api/payment/pay
Content-Type: application/json

{
  "reservationId": "TRAIN-20240112-000001",
  "couponId": 123,
  "usePoints": 1000
}

Response:
{
  "success": true,
  "data": {
    "transactionId": "TXN-20240112-000002",
    "paidAmount": 53820,
    "usedCoupon": true,
    "usedPoints": 1000,
    "earnedPoints": 538,
    "remainingBalance": 1180
  }
}
```

#### 3. 환불 처리
```http
POST /api/payment/refund
Content-Type: application/json

{
  "reservationId": "TRAIN-20240112-000001",
  "reason": "일정 변경"
}

Response:
{
  "success": true,
  "data": {
    "transactionId": "TXN-20240112-000003",
    "originalAmount": 53820,
    "refundAmount": 53820,
    "feeAmount": 0,
    "currentBalance": 55000
  }
}
```

### ReservationController

#### 1. KTX 예약 생성
```http
POST /api/reservation/train
Content-Type: application/json

{
  "userId": "KAKAO:1234567890",
  "trainNumber": "KTX101",
  "departureStation": "서울",
  "arrivalStation": "부산",
  "departureTime": "2024-01-12T10:00:00",
  "arrivalTime": "2024-01-12T12:40:00",
  "price": 59800,
  "passengerCount": 1
}

Response:
{
  "success": true,
  "data": {
    "reservationId": "TRAIN-20240112-000001",
    "status": "PAYMENT_PENDING",
    "paymentUrl": "/payment?reservationId=TRAIN-20240112-000001"
  }
}
```

## 🎨 프론트엔드 페이지

### payment.html
- **결제 페이지**: 쿠폰/포인트 선택 및 결제 처리
- **위치**: `/src/main/resources/templates/payment.html`
- **URL**: `/payment?reservationId={id}`

### 주요 기능
1. 예약 정보 표시
2. 쿠폰 선택 (드롭다운)
3. 포인트 사용 (입력 + 전액 사용 버튼)
4. 실시간 최종 금액 계산
5. S-Pay 잔액 표시 및 충전
6. 결제 처리

## 📝 구현 체크리스트

### Phase 1: 데이터베이스 (완료)
- [x] payment.html 템플릿 저장
- [ ] SQL 스키마 실행
- [ ] 초기 데이터 삽입 (환영 쿠폰 등)

### Phase 2: 엔티티 클래스
- [ ] User.java
- [ ] Wallet.java
- [ ] Point.java
- [ ] Reservation.java
- [ ] PaymentTransaction.java
- [ ] CouponMaster.java / UserCoupon.java

### Phase 3: Repository
- [ ] UserRepository
- [ ] WalletRepository
- [ ] PointRepository
- [ ] ReservationRepository
- [ ] PaymentTransactionRepository
- [ ] CouponRepository

### Phase 4: Service 계층
- [ ] PaymentService (충전/결제/환불)
- [ ] ReservationService (예약 생성/조회)
- [ ] CouponService (쿠폰 발급/사용)

### Phase 5: Controller
- [ ] PaymentController
- [ ] ReservationController

### Phase 6: 보안 설정
- [ ] SecurityConfig
- [ ] CustomOAuth2UserService
- [ ] OAuth2SuccessHandler

### Phase 7: 테스트
- [ ] 회원가입 테스트
- [ ] 충전 테스트
- [ ] 예약 및 결제 테스트
- [ ] 쿠폰/포인트 사용 테스트
- [ ] 환불 테스트

## 🚀 실행 방법

### 1. 데이터베이스 설정
```bash
# Oracle SQL*Plus 접속
sqlplus system/1234@localhost:1521/xe

# 스키마 실행
@kmaas-payment-system.sql
```

### 2. 환경 변수 설정 (.env 파일)
```
KAKAO_CLIENT_ID=your_kakao_client_id
KAKAO_CLIENT_SECRET=your_kakao_client_secret
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
NAVER_CLIENT_ID=your_naver_client_id
NAVER_CLIENT_SECRET=your_naver_client_secret
```

### 3. 애플리케이션 실행
```bash
./gradlew bootRun
```

### 4. 테스트
```
1. http://localhost:9999 접속
2. 소셜 로그인 (카카오/구글/네이버)
3. 자동으로 5,000원 충전 및 환영 쿠폰 발급 확인
4. KTX 예약 → 결제 페이지 이동
5. 쿠폰/포인트 적용 후 결제
```

## 💡 주요 기능 설명

### 가상 결제 시스템
- 실제 PG사 연동 없이 내부 DB로 완전한 결제 흐름 구현
- 개발/테스트/프로토타입에 최적화
- 나중에 실제 PG(토스페이먼츠, 아임포트 등)로 전환 가능

### OAuth2 소셜 로그인
- 카카오, 구글, 네이버 지원
- 회원가입 시 자동으로 지갑/포인트 생성
- 환영 보너스 5,000원 자동 지급

### 쿠폰 시스템
- 퍼센트 할인 (예: 10% 할인)
- 정액 할인 (예: 5,000원 할인)
- 최소 주문 금액 설정 가능
- 유효기간 설정 가능
- 특정 교통수단 전용 쿠폰 가능

### 포인트 시스템
- 결제 금액의 1% 자동 적립
- 포인트 사용 시 즉시 차감
- 환불 시 사용한 포인트 복구

## 🔧 커스터마이징

### 포인트 적립률 변경
```yaml
# application.yml
kmaas:
  payment:
    point-earn-rate: 0.02  # 2%로 변경
```

### 환불 수수료율 변경
```yaml
kmaas:
  payment:
    refund-fee-rate: 0.05  # 5%로 변경
    free-cancel-minutes: 120  # 2시간 전까지 무료 취소
```

### 환영 보너스 변경
```yaml
kmaas:
  payment:
    welcome-bonus: 10000  # 10,000원으로 변경
```

## 📚 참고 자료

- Spring Security OAuth2: https://spring.io/guides/tutorials/spring-boot-oauth2/
- Oracle Database: https://docs.oracle.com/en/database/
- Bootstrap 5: https://getbootstrap.com/docs/5.3/
- Thymeleaf: https://www.thymeleaf.org/documentation.html

## 🎯 다음 단계

1. **실제 API 연동**: 코레일 API, 따릉이 API 등 실제 데이터 연동
2. **관리자 페이지**: 쿠폰 발급, 사용자 관리, 통계 대시보드
3. **알림 시스템**: 예약 확인, 결제 완료, 출발 알림 등
4. **모바일 최적화**: 반응형 디자인 개선
5. **실제 PG 연동**: 토스페이먼츠, 카카오페이 등

---

**작성일**: 2026-01-12
**버전**: 1.0.0
**프로젝트**: K-MaaS Platform
