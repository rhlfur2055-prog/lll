package com.maas.service.repository;

import com.maas.service.entity.BikeStation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BikeStationRepository extends JpaRepository<BikeStation, String> {
}
