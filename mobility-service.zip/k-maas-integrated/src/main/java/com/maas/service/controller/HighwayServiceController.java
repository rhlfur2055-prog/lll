package com.maas.service.controller;

import com.maas.service.entity.TollRecord;
import com.maas.service.service.HighwayService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/highway")
@RequiredArgsConstructor
public class HighwayServiceController {

    private final HighwayService highwayService;

    @PostMapping("/entry")
    public ResponseEntity<TollRecord> recordEntry(@RequestBody Map<String, Object> req) {
        Long userId = Long.valueOf(req.get("userId").toString());
        String vNum = (String) req.get("vehicleNumber");
        String tgName = (String) req.get("entryTollgate");
        String tgCode = (String) req.get("entryCode");
        String rName = (String) req.get("routeName");
        return ResponseEntity.ok(highwayService.recordEntry(userId, vNum, tgName, tgCode, rName));
    }

    @PostMapping("/exit")
    public ResponseEntity<TollRecord> recordExit(@RequestBody Map<String, Object> req) {
        Long userId = Long.valueOf(req.get("userId").toString());
        String tgName = (String) req.get("exitTollgate");
        String tgCode = (String) req.get("exitCode");
        String pMethod = (String) req.get("paymentMethod");
        String rNo = (String) req.get("routeNo");
        Double dist = Double.valueOf(req.get("distance").toString());
        return ResponseEntity.ok(highwayService.recordExit(userId, tgName, tgCode, pMethod, rNo, dist));
    }

    @GetMapping("/history/{userId}")
    public ResponseEntity<List<TollRecord>> getHistory(@PathVariable Long userId) {
        return ResponseEntity.ok(highwayService.getHistory(userId));
    }
}
