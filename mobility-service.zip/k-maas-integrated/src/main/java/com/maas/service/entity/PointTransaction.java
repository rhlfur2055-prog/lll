package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "POINT_TRANSACTIONS")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PointTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "point_seq")
    @SequenceGenerator(name = "point_seq", sequenceName = "POINT_SEQ", allocationSize = 1)
    @Column(name = "TRANSACTION_ID")
    private Long id;

    @Column(name = "USER_ID", nullable = false)
    private Long userId;

    @Column(name = "AMOUNT", nullable = false)
    private Integer amount;

    @Column(name = "TYPE", nullable = false)
    private String type; // EARN, USE

    @Column(name = "REASON")
    private String reason;

    @Column(name = "TRANSACTION_TIME")
    private LocalDateTime transactionTime;

    @PrePersist
    protected void onCreate() {
        transactionTime = LocalDateTime.now();
    }
}
