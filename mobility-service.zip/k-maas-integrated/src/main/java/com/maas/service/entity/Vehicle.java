package com.maas.service.entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "VEHICLE")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(
    name = "VEHICLE_SEQ_GENERATOR",
    sequenceName = "VEHICLE_SEQ",
    initialValue = 1,
    allocationSize = 1
)
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "VEHICLE_SEQ_GENERATOR")
    @Column(name = "VEHICLE_ID")
    private Long vehicleId;

    @Column(name = "USER_ID", nullable = false)
    private Long userId;

    @Column(name = "VEHICLE_NUMBER", length = 20, unique = true, nullable = false)
    private String vehicleNumber;

    @Column(name = "VEHICLE_TYPE", length = 20, nullable = false)
    private String vehicleType;

    @Column(name = "VEHICLE_CLASS")
    private Integer vehicleClass;

    @Column(name = "IS_ELECTRIC")
    private Boolean isElectric;

    @Column(name = "IS_DISABLED")
    private Boolean isDisabled;

    @Column(name = "IS_ECO_FRIENDLY")
    private Boolean isEcoFriendly;

    @Column(name = "OWNER_NAME", length = 50)
    private String ownerName;

    @Column(name = "MODEL_NAME", length = 100)
    private String modelName;

    @Column(name = "MANUFACTURER", length = 50)
    private String manufacturer;

    @Column(name = "YEAR")
    private Integer year;

    @Column(name = "REGISTERED_AT")
    private LocalDateTime registeredAt;

    @Column(name = "IS_ACTIVE")
    private Boolean isActive;

    @PrePersist
    protected void onCreate() {
        this.registeredAt = LocalDateTime.now();
        if (this.isActive == null) this.isActive = true;
        if (this.isElectric == null) this.isElectric = false;
        if (this.isDisabled == null) this.isDisabled = false;
        if (this.isEcoFriendly == null) this.isEcoFriendly = false;
    }
}
