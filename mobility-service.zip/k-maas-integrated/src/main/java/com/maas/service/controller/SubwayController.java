package com.maas.service.controller;

import com.maas.service.service.SubwayService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class SubwayController {
    private final SubwayService subwayService;

    @GetMapping("/api/subway/search")
    public List<Map<String, String>> searchStation(@RequestParam String keyword) {
        return subwayService.search(keyword);
    }
}
