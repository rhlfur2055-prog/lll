package com.maas.service.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(WebClientResponseException.Unauthorized.class)
    public String handleUnauthorized(Exception ex, Model model) {
        model.addAttribute("error", "키 확인 필요 (API Key Unauthorized)");
        return "error/api-error";
    }

    @ExceptionHandler(Exception.class)
    public String handleGeneralException(Exception ex, Model model) {
        model.addAttribute("error", "정보 없음 (Information Not Available)");
        model.addAttribute("message", ex.getMessage());
        return "error/api-error";
    }
}
