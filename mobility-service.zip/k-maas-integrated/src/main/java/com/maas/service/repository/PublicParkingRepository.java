package com.maas.service.repository;

import com.maas.service.entity.PublicParking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PublicParkingRepository extends JpaRepository<PublicParking, Long> {
    List<PublicParking> findByParkingNameContaining(String parkingName);
}
