package com.maas.service.controller;
import com.maas.service.entity.BikeStation;
import com.maas.service.service.BikeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class BikeController {
    private final BikeService bikeService;

    @GetMapping("/api/bike/stations/search")
    public ResponseEntity<List<BikeStation>> searchStations(@RequestParam String keyword) {
        return ResponseEntity.ok(bikeService.searchStations(keyword));
    }

    @GetMapping("/api/bike/stations")
    public ResponseEntity<List<BikeStation>> getAllStations() {
        return ResponseEntity.ok(bikeService.getAllStations());
    }
}
