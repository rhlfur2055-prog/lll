package com.maas.service.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maas.service.entity.TollRecord;
import com.maas.service.entity.Vehicle;
import com.maas.service.repository.TollRecordRepository;
import com.maas.service.repository.VehicleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class HighwayService {

    private final TollRecordRepository tollRecordRepository;
    private final VehicleRepository vehicleRepository;
    private final ObjectMapper objectMapper;
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${api.highway.base-url:https://data.ex.co.kr/openapi/business}")
    private String baseUrl;

    @Value("${api.highway.key:999e18155e95152d406654bf617a494c9312a98456a7e8e7e4a904a50d1be29b}")
    private String apiKey;

    @Transactional
    public TollRecord recordEntry(Long userId, String vehicleNumber, String entryTollgate, String entryCode, String routeName) {
        Optional<TollRecord> active = tollRecordRepository.findActiveRecordByUserId(userId);
        if (active.isPresent()) throw new RuntimeException("이미 진행 중인 통행이 있습니다.");

        Vehicle vehicle = vehicleRepository.findByVehicleNumber(vehicleNumber)
                .orElseThrow(() -> new RuntimeException("등록되지 않은 차량입니다."));

        return tollRecordRepository.save(TollRecord.builder()
                .userId(userId)
                .vehicleNumber(vehicleNumber)
                .entryTollgate(entryTollgate)
                .entryTollgateCode(entryCode)
                .routeName(routeName)
                .vehicleType(vehicle.getVehicleType())
                .entryTime(LocalDateTime.now())
                .build());
    }

    @Transactional
    public TollRecord recordExit(Long userId, String exitTollgate, String exitCode, String paymentMethod, String routeNo, Double distance) {
        TollRecord record = tollRecordRepository.findActiveRecordByUserId(userId)
                .orElseThrow(() -> new RuntimeException("진입 기록이 없습니다."));

        Vehicle vehicle = vehicleRepository.findByVehicleNumber(record.getVehicleNumber())
                .orElseThrow(() -> new RuntimeException("차량 정보를 찾을 수 없습니다."));

        int baseFee = fetchTollFee(routeNo, record.getEntryTollgateCode(), exitCode, vehicle.getVehicleClass(), distance);
        double discountRate = calculateDiscountRate(vehicle, "HIPASS".equalsIgnoreCase(paymentMethod));
        int finalFee = (int) (baseFee * (1 - discountRate));
        finalFee = (finalFee / 10) * 10; // 10원 단위 절사

        record.setExitTollgate(exitTollgate);
        record.setExitTollgateCode(exitCode);
        record.setExitTime(LocalDateTime.now());
        record.setPaymentMethod(paymentMethod);
        record.setDistanceKm(distance);
        record.setBaseFee(baseFee);
        record.setFinalFee(Math.max(finalFee, 100));
        record.setDiscountAmount(baseFee - record.getFinalFee());

        return tollRecordRepository.save(record);
    }

    private int fetchTollFee(String routeNo, String startCode, String endCode, Integer vClass, Double distance) {
        try {
            String url = UriComponentsBuilder.fromHttpUrl(baseUrl + "/curTollfeeSearch")
                    .queryParam("serviceKey", apiKey)
                    .queryParam("type", "json")
                    .queryParam("routeNo", routeNo)
                    .queryParam("startTollgate", startCode)
                    .queryParam("endTollgate", endCode)
                    .queryParam("vehicleClass", vClass != null ? vClass : 2)
                    .build(true).toUriString();

            String response = restTemplate.getForObject(url, String.class);
            JsonNode root = objectMapper.readTree(response);
            if (root.has("list") && root.get("list").isArray() && root.get("list").size() > 0) {
                return root.get("list").get(0).get("tollFee").asInt();
            }
        } catch (Exception e) {
            log.error("Highway API Error: {}", e.getMessage());
        }
        return (int) (distance * 76); // Fallback: 76원/km
    }

    private double calculateDiscountRate(Vehicle v, boolean isHipass) {
        double rate = 0.0;
        if (Boolean.TRUE.equals(v.getIsElectric())) rate += 0.5;
        if (Boolean.TRUE.equals(v.getIsDisabled())) rate += 0.5;
        if (isHipass) rate += 0.1;
        return Math.min(rate, 0.8); // 최대 80%
    }

    public List<TollRecord> getHistory(Long userId) {
        return tollRecordRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }
}
