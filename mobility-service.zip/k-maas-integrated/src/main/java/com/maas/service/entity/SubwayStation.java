package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "subway_station")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubwayStation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "subway_seq")
    @SequenceGenerator(name = "subway_seq", sequenceName = "SUBWAY_STATION_SEQ", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "STATION_NAME", nullable = false, length = 100)
    private String stationName;

    @Column(name = "LINE_NUMBER", nullable = false, length = 10)
    private String lineNumber;

    @Column(name = "LATITUDE", nullable = false)
    private Double latitude;

    @Column(name = "LONGITUDE", nullable = false)
    private Double longitude;

    @Column(name = "STATION_NUMBER", length = 10)
    private String stationNumber;

    @Column(name = "STATION_CODE", length = 20)
    private String stationCode;

    @Column(name = "ADDRESS", length = 200)
    private String address;

    @Column(name = "IS_TRANSFER", length = 1)
    private String isTransfer; // '0' or '1'

    @Column(name = "TRANSFER_LINES", length = 50)
    private String transferLines;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}
