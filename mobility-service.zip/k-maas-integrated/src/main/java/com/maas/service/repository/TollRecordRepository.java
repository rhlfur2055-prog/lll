package com.maas.service.repository;

import com.maas.service.entity.TollRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface TollRecordRepository extends JpaRepository<TollRecord, Long> {
    
    @Query("SELECT t FROM TollRecord t WHERE t.userId = :userId AND t.exitTime IS NULL")
    Optional<TollRecord> findActiveRecordByUserId(@Param("userId") Long userId);
    
    List<TollRecord> findByUserIdOrderByCreatedAtDesc(Long userId);
    
    List<TollRecord> findByVehicleNumberOrderByCreatedAtDesc(String vehicleNumber);
    
    @Query("SELECT SUM(t.finalFee) FROM TollRecord t WHERE t.userId = :userId AND YEAR(t.createdAt) = :year AND MONTH(t.createdAt) = :month")
    Integer sumMonthlyFeeByUserId(@Param("userId") Long userId, @Param("year") int year, @Param("month") int month);
}
