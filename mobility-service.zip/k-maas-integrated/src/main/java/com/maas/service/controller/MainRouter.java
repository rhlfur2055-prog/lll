package com.maas.service.controller;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainRouter {
    @GetMapping("/")
    public String root(HttpServletRequest request) {
        String ua = request.getHeader("User-Agent");
        boolean isMobile = ua != null && (ua.contains("Mobile") || ua.contains("Android") || ua.contains("iPhone"));
        return isMobile ? "redirect:/mobile" : "redirect:/subway";
    }
    // PC Pages
    @GetMapping("/ktx") public String ktx() { return "ktx"; }
    @GetMapping("/subway") public String subway() { return "subway"; }
    @GetMapping("/bike") public String bike() { return "bike"; }
    @GetMapping("/parking") public String parking() { return "parking"; }
    
    // Mobile Pages
    @GetMapping("/mobile") public String mobileHome() { return "mobile/index"; }
    @GetMapping("/mobile/ktx") public String mobileKtx() { return "mobile/ktx"; }
    @GetMapping("/mobile/subway") public String mobileSubway() { return "mobile/subway"; }
    @GetMapping("/mobile/bike") public String mobileBike() { return "mobile/bike"; }
    @GetMapping("/mobile/parking") public String mobileParking() { return "mobile/parking"; }
    @GetMapping("/login") public String login() { return "auth/login"; }
}
