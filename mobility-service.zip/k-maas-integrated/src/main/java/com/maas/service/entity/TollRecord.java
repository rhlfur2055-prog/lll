package com.maas.service.entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "TOLL_RECORD")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(
    name = "TOLL_SEQ_GENERATOR",
    sequenceName = "TOLL_SEQ",
    initialValue = 1,
    allocationSize = 1
)
public class TollRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TOLL_SEQ_GENERATOR")
    @Column(name = "TOLL_ID")
    private Long tollId;

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "VEHICLE_NUMBER", length = 20, nullable = false)
    private String vehicleNumber;

    @Column(name = "ENTRY_TOLLGATE", length = 100, nullable = false)
    private String entryTollgate;

    @Column(name = "ENTRY_TOLLGATE_CODE", length = 20)
    private String entryTollgateCode;

    @Column(name = "EXIT_TOLLGATE", length = 100, nullable = false)
    private String exitTollgate;

    @Column(name = "EXIT_TOLLGATE_CODE", length = 20)
    private String exitTollgateCode;

    @Column(name = "ROUTE_NAME", length = 50)
    private String routeName;

    @Column(name = "VEHICLE_TYPE", length = 20, nullable = false)
    private String vehicleType;

    @Column(name = "ENTRY_TIME", nullable = false)
    private LocalDateTime entryTime;

    @Column(name = "EXIT_TIME")
    private LocalDateTime exitTime;

    @Column(name = "BASE_FEE")
    private Integer baseFee;

    @Column(name = "DISCOUNT_AMOUNT")
    private Integer discountAmount;

    @Column(name = "FINAL_FEE")
    private Integer finalFee;

    @Column(name = "PAYMENT_METHOD", length = 20)
    private String paymentMethod;

    @Column(name = "DISCOUNT_REASON", length = 200)
    private String discountReason;

    @Column(name = "DISTANCE_KM")
    private Double distanceKm;

    @Column(name = "IS_RUSH_HOUR")
    private Boolean isRushHour;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
