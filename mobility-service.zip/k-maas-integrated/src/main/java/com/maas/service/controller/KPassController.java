package com.maas.service.controller;
import com.maas.service.service.KPassService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/kpass")
@RequiredArgsConstructor
public class KPassController {
    private final KPassService kPassService;

    @GetMapping("/balance/{userId}")
    public ResponseEntity<Map<String, Object>> getBalance(@PathVariable Long userId) {
        return ResponseEntity.ok(Map.of("success", true, "balance", kPassService.getBalance(userId), "userName", "테스트유저"));
    }

    @PostMapping("/earn")
    public ResponseEntity<Map<String, Object>> earnPoints(@RequestBody Map<String, Object> request) {
        Long userId = Long.valueOf(request.get("userId").toString());
        String type = (String) request.get("transportType");
        int fare = Integer.parseInt(request.get("fare").toString());
        String route = (String) request.getOrDefault("routeInfo", "");
        
        int earned = kPassService.earnPointsWithPolicy(userId, type, fare, route);
        return ResponseEntity.ok(Map.of("success", true, "earnedPoints", earned, "newBalance", kPassService.getBalance(userId)));
    }
}
