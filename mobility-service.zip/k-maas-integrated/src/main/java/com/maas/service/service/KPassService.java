package com.maas.service.service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.maas.service.entity.PointTransaction;
import com.maas.service.entity.Policy;
import com.maas.service.entity.UsageRecord;
import com.maas.service.entity.User;
import com.maas.service.repository.PointTransactionRepository;
import com.maas.service.repository.PolicyRepository;
import com.maas.service.repository.UsageRecordRepository;
import com.maas.service.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class KPassService {

    private final UserRepository userRepository;
    private final PointTransactionRepository pointTransactionRepository;
    private final UsageRecordRepository usageRecordRepository;
    private final PolicyRepository policyRepository;

    private static final Map<String, Double> BASE_EARN_RATES = Map.of(
            "SUBWAY", 0.10,
            "BUS", 0.10,
            "KTX", 0.05,
            "BIKE", 0.0,
            "HIGHWAY", 0.03,
            "PARKING", 0.05
    );

    private static final int BIKE_FIXED_POINTS = 100;

    @Transactional
    public int earnPointsWithPolicy(Long userId, String transportType, int fare, String routeInfo) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다: " + userId));

        int basePoints;
        if ("BIKE".equalsIgnoreCase(transportType)) {
            basePoints = BIKE_FIXED_POINTS;
        } else {
            double rate = BASE_EARN_RATES.getOrDefault(transportType.toUpperCase(), 0.05);
            basePoints = (int) Math.round(fare * rate);
        }

        double policyMultiplier = getPolicyMultiplier(transportType);
        int finalPoints = (int) Math.round(basePoints * policyMultiplier);

        if (finalPoints <= 0) return 0;

        user.setPoints(user.getPoints() + finalPoints);
        userRepository.save(user);

        pointTransactionRepository.save(PointTransaction.builder()
                .userId(userId)
                .amount(finalPoints)
                .type("EARN")
                .reason(String.format("K-Pass 적립: %s (%s)", transportType, routeInfo))
                .build());

        usageRecordRepository.save(UsageRecord.builder()
                .userId(String.valueOf(userId))
                .transportType(transportType)
                .routeInfo(routeInfo)
                .usageTime(LocalDateTime.now())
                .points(finalPoints)
                .policyApplied(policyMultiplier > 1.0)
                .build());

        log.info("[K-Pass 적립] userId={}, type={}, 최종={}P", userId, transportType, finalPoints);
        return finalPoints;
    }

    public int getBalance(Long userId) {
        return userRepository.findById(userId).map(User::getPoints).orElse(0);
    }

    private double getPolicyMultiplier(String transportType) {
        LocalTime now = LocalTime.now();
        int hour = now.getHour();
        double timeMultiplier = (hour >= 10 && hour < 16) ? 1.5 : 1.0;
        double ecoMultiplier = "BIKE".equalsIgnoreCase(transportType) ? 2.0 : 1.0;
        
        double policyWeight = 1.0;
        try {
            if ("BIKE".equalsIgnoreCase(transportType)) {
                if (policyRepository.findByPolicyTypeAndEnabledTrue("eco").isPresent()) policyWeight = 1.5;
            }
            if (hour >= 10 && hour < 16) {
                if (policyRepository.findByPolicyTypeAndEnabledTrue("off-peak").isPresent()) policyWeight *= 1.2;
            }
        } catch (Exception e) {
            log.warn("[K-Pass] 정책 조회 실패: {}", e.getMessage());
        }
        return timeMultiplier * ecoMultiplier * policyWeight;
    }
}
