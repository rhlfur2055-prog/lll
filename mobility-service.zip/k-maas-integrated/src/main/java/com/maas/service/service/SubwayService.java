package com.maas.service.service;

import com.maas.service.entity.SubwayStation;
import com.maas.service.repository.SubwayStationRepository;
import com.maas.service.service.integration.SeoulMetroRealtimeClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SubwayService {

    private final SeoulMetroRealtimeClient seoulMetroRealtimeClient;
    private final SubwayStationRepository subwayStationRepository;

    /**
     * 지하철 역 검색 (DB 데이터 기반 + 실시간 정보 매칭)
     */
    public List<Map<String, String>> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return new ArrayList<>();
        }

        // 1. DB에서 역 정보 검색
        String searchName = keyword;
        if (!searchName.endsWith("역")) {
            searchName += "역";
        }
        List<SubwayStation> dbStations = subwayStationRepository.findByStationNameContaining(keyword);
        if (dbStations.isEmpty()) {
            dbStations = subwayStationRepository.findByStationNameContaining(searchName.replace("역", ""));
        }

        // 2. 실시간 도착 정보 조회
        List<Map<String, Object>> realData = seoulMetroRealtimeClient.getRealtimeArrival(keyword.replace("역", ""));

        // 3. 매칭 및 데이터 가공
        List<Map<String, String>> finalResults = new ArrayList<>();

        for (SubwayStation dbStation : dbStations) {
            Map<String, String> result = new HashMap<>();
            result.put("name", dbStation.getStationName());
            result.put("line", dbStation.getLineNumber() + "호선");
            result.put("lat", String.valueOf(dbStation.getLatitude()));
            result.put("lng", String.valueOf(dbStation.getLongitude()));
            result.put("transferInfo", dbStation.getTransferLines());

            // API 정보와 매칭 (호선 기준)
            Optional<Map<String, Object>> match = realData.stream()
                .filter(data -> {
                    String apiLine = String.valueOf(data.get("lineName"));
                    return apiLine.contains(dbStation.getLineNumber() + "호선") || 
                           apiLine.contains(dbStation.getLineNumber());
                })
                .findFirst();

            if (match.isPresent()) {
                Map<String, Object> data = match.get();
                result.put("status", formatStatus(data));
                result.put("type", String.valueOf(data.get("trainType")));
            } else {
                result.put("status", "실시간 정보 없음");
                result.put("type", "완행");
            }
            finalResults.add(result);
        }

        return finalResults;
    }

    private String formatStatus(Map<String, Object> data) {
        Object secondsObj = data.get("arrivalSeconds");
        int seconds = 0;
        if (secondsObj != null) {
            try {
                seconds = Integer.parseInt(String.valueOf(secondsObj));
            } catch (Exception e) {
                seconds = 0;
            }
        }

        String msg = (seconds < 60) ? "곧 도착" : (seconds / 60) + "분 후";
        return msg + " [" + data.getOrDefault("currentStation", "진입중") + "]";
    }
}
