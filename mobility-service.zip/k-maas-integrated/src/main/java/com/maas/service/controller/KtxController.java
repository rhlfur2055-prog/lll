package com.maas.service.controller;
import com.maas.service.service.KtxService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/ktx")
@RequiredArgsConstructor
public class KtxController {
    private final KtxService ktxService;

    @GetMapping("/api/search")
    public ResponseEntity<List<Map<String, Object>>> searchKtxApi(
            @RequestParam String depStation, @RequestParam String arrStation,
            @RequestParam String date, @RequestParam(defaultValue = "1") int passengers) {
        return ResponseEntity.ok(ktxService.searchKtxSchedule(depStation, arrStation, date, 20));
    }
    
    @PostMapping("/api/reserve")
    public Map<String, Object> reservePost(@RequestParam Map<String, String> params) {
        return Map.of("success", true, "reservationId", "KTX" + System.currentTimeMillis(), "message", "예약 완료");
    }
}
