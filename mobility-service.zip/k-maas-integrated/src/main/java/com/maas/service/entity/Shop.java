package com.maas.service.entity;

import java.time.LocalDateTime;
import java.time.LocalTime;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "shop")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Shop {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "shop_seq")
    @SequenceGenerator(name = "shop_seq", sequenceName = "SHOP_SEQ", allocationSize = 1)
    @Column(name = "shop_id")
    private Long shopId;

    @Column(name = "shop_name", nullable = false, length = 100)
    private String shopName;

    @Column(name = "category", nullable = false, length = 50)
    private String category;

    @Column(name = "address", nullable = false, length = 200)
    private String address;

    @Column(name = "latitude", nullable = false)
    private Double latitude;

    @Column(name = "longitude", nullable = false)
    private Double longitude;

    @Column(name = "phone", length = 20)
    private String phone;

    @Column(name = "rating")
    private Double rating;

    @Column(name = "discount_rate", nullable = false)
    private Integer discountRate;

    @Column(name = "visit_count")
    private Integer visitCount;

    @Column(name = "opening_time")
    private LocalTime openingTime;

    @Column(name = "closing_time")
    private LocalTime closingTime;

    @Column(name = "status", nullable = false, length = 20)
    private String status;

    @Column(name = "partner_since")
    private LocalDateTime partnerSince;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "image_url", length = 500)
    private String imageUrl;

    @Lob
    @Column(name = "description")
    private String description;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (visitCount == null) visitCount = 0;
        if (active == null) active = true;
        if (status == null) status = "open";
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
