package com.maas.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class SqlTransformer {
    public static void main(String[] args) throws IOException {
        Path sourcePath = Paths.get("c:/tools/mobility-service/insert_subway_corrected.sql");
        Path targetPath = Paths.get("c:/tools/mobility-service/k-maas-integrated/src/main/resources/data.sql");
        
        if (!Files.exists(sourcePath)) {
            System.err.println("Source file not found: " + sourcePath);
            return;
        }

        String content = Files.readString(sourcePath);
        content = content.replace("SUBWAY_STATION_SEQ.NEXTVAL", "(NEXT VALUE FOR SUBWAY_STATION_SEQ)");
        content = content.replace("COMMIT;", "");
        
        StringBuilder sampleData = new StringBuilder();
        sampleData.append("\n-- 1. 회원 샘플 데이터\n");
        sampleData.append("INSERT INTO USERS (USER_ID, NAME, EMAIL, PASSWORD, PHONE, POINTS) VALUES\n");
        sampleData.append("((NEXT VALUE FOR USER_SEQ), '김철수', 'kim@example.com', '$2a$10$dummyHashedPassword1', '010-1234-5678', 5000);\n");
        sampleData.append("INSERT INTO USERS (USER_ID, NAME, EMAIL, PASSWORD, PHONE, POINTS) VALUES\n");
        sampleData.append("((NEXT VALUE FOR USER_SEQ), '이영희', 'lee@example.com', '$2a$10$dummyHashedPassword2', '010-2345-6789', 3000);\n");
        
        sampleData.append("\n-- 3. 따릉이 대여소 샘플 데이터\n");
        sampleData.append("INSERT INTO BIKE_STATIONS (STATION_ID, STATION_NAME, LATITUDE, LONGITUDE, AVAILABLE_BIKES, TOTAL_DOCKS, DISTRICT, ADDRESS) VALUES\n");
        sampleData.append("('ST-001', '강남역 1번출구', 37.498095, 127.027610, 12, 20, '강남구', '서울특별시 강남구 강남대로 지하396');\n");
        
        sampleData.append("\n-- 4. 공영 주차장 샘플 데이터\n");
        sampleData.append("INSERT INTO PUBLIC_PARKING (PARKING_ID, PARKING_CODE, PARKING_NAME, ADDRESS, LATITUDE, LONGITUDE, TOTAL_SPACES, AVAILABLE_SPACES, PARKING_TYPE, OPERATION_TYPE, WEEKDAY_BEGIN_TIME, WEEKDAY_END_TIME, RATES, PAY_METHOD, TELEPHONE, REGION, DISTRICT) VALUES\n");
        sampleData.append("((NEXT VALUE FOR PARKING_SEQ), 'SEL-001', '강남역 공영주차장', '서울 강남구 강남대로 396', 37.498095, 127.027610, 200, 45, '노외', '공영', '00:00', '24:00', '기본 30분 1,000원, 추가 10분당 500원', '현금, 카드, 모바일', '02-1234-5678', '서울', '강남구');\n");
        
        sampleData.append("\n-- 5. 정책 샘플 데이터\n");
        sampleData.append("INSERT INTO POLICY (POLICY_ID, POLICY_NAME, POLICY_TYPE, ENABLED, START_DATE, END_DATE, INCENTIVE_POINT, DESCRIPTION, TARGET_GROUP) VALUES\n");
        sampleData.append("((NEXT VALUE FOR POLICY_SEQ), '비혼잡 시간대 인센티브', 'off-peak', TRUE, '2026-01-01', '2026-12-31', 500, '오전 10시~오후 4시 이용 시 포인트 지급', '전체');\n");
        
        sampleData.append("\n-- 6. 제휴 상점 샘플 데이터\n");
        sampleData.append("INSERT INTO SHOP (SHOP_ID, SHOP_NAME, CATEGORY, ADDRESS, LATITUDE, LONGITUDE, PHONE, RATING, DISCOUNT_RATE, VISIT_COUNT, OPENING_TIME, CLOSING_TIME, STATUS, ACTIVE, DESCRIPTION) VALUES\n");
        sampleData.append("((NEXT VALUE FOR SHOP_SEQ), '스타벅스 강남역점', '카페', '서울 강남구 강남대로 지하396', 37.498095, 127.027610, '02-1111-2222', 4.5, 10, 523, '07:00:00', '23:00:00', 'open', TRUE, '강남역 1번출구 앞 스타벅스');\n");
        
        sampleData.append("\n-- 7. 이용 기록 샘플 데이터\n");
        sampleData.append("INSERT INTO USAGE_RECORDS (RECORD_ID, USER_ID, TRANSPORT_TYPE, ROUTE_INFO, REGION, POINTS, POLICY_APPLIED, DAY_OF_WEEK) VALUES\n");
        sampleData.append("((NEXT VALUE FOR USAGE_SEQ), '1', 'SUBWAY', '강남역 → 서울역 (2호선)', '서울', 100, '1', 'MON');\n");
        
        sampleData.append("\n-- 8. 포인트 거래 샘플 데이터\n");
        sampleData.append("INSERT INTO POINT_TRANSACTIONS (TRANSACTION_ID, USER_ID, AMOUNT, TYPE, REASON) VALUES\n");
        sampleData.append("((NEXT VALUE FOR POINT_SEQ), 1, 1000, 'EARN', '회원가입 보너스');\n");

        Files.writeString(targetPath, content + sampleData.toString());
        System.out.println("data.sql generated successfully at " + targetPath);
    }
}
