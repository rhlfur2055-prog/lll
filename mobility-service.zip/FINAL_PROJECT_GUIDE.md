# K-MaaS Platform - 최종 프로젝트 가이드

**서울·경기·인천 통합 모빌리티 플랫폼**

---

## 📋 프로젝트 개요

### 프로젝트명
**K-MaaS (Korea Mobility as a Service)**

### 개발 기간
2026년 1월 (Spring Boot 풀스택 개발 과정)

### 개발 목적
수도권(서울·경기·인천) 전역의 교통수단을 하나의 플랫폼에서 통합 제공하여 시민들의 이동 편의성을 극대화하고, 스마트시티 교통 혁신을 실현합니다.

### 핵심 기술 스택
- **Backend**: Spring Boot 3.x, Java 17
- **Database**: Oracle 11g Express Edition
- **Frontend**: Thymeleaf, HTML5, CSS3, JavaScript
- **Build Tool**: Gradle 8.14.3
- **ORM**: JPA/Hibernate
- **API Integration**: 카카오맵 API, 서울 열린데이터광장

---

## 🏗️ 프로젝트 구조

```
mobility-service/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/maas/service/
│   │   │       ├── MobilityServiceApplication.java
│   │   │       ├── controller/          # REST 컨트롤러
│   │   │       │   ├── HomeController.java
│   │   │       │   ├── UserController.java
│   │   │       │   ├── KtxController.java
│   │   │       │   ├── SubwayController.java
│   │   │       │   ├── BusController.java
│   │   │       │   ├── BikeController.java
│   │   │       │   ├── ParkingController.java
│   │   │       │   ├── PolicyController.java
│   │   │       │   ├── ShopController.java
│   │   │       │   ├── DashboardController.java
│   │   │       │   └── AnalyticsController.java
│   │   │       ├── service/             # 비즈니스 로직
│   │   │       │   ├── UserService.java
│   │   │       │   ├── ParkingService.java
│   │   │       │   ├── SeoulParkingApiService.java
│   │   │       │   └── GyeonggiParkingApiService.java
│   │   │       ├── repository/          # 데이터 액세스
│   │   │       │   ├── UserRepository.java
│   │   │       │   ├── BikeStationRepository.java
│   │   │       │   ├── SubwayStationRepository.java
│   │   │       │   ├── PublicParkingRepository.java
│   │   │       │   ├── PolicyRepository.java
│   │   │       │   └── ShopRepository.java
│   │   │       └── entity/              # 엔티티 (DB 모델)
│   │   │           ├── User.java
│   │   │           ├── PointTransaction.java
│   │   │           ├── UsageRecord.java
│   │   │           ├── BikeStation.java
│   │   │           ├── SubwayStation.java
│   │   │           ├── PublicParking.java
│   │   │           ├── Policy.java
│   │   │           └── Shop.java
│   │   └── resources/
│   │       ├── application.properties   # 설정 파일
│   │       ├── static/                  # 정적 리소스
│   │       └── templates/               # Thymeleaf 템플릿
│   │           ├── index.html           # 메인 페이지
│   │           ├── login.html
│   │           ├── register.html
│   │           ├── profile.html
│   │           ├── ktx.html
│   │           ├── subway.html
│   │           ├── bus.html
│   │           ├── bike.html
│   │           ├── parking.html
│   │           ├── dashboard.html
│   │           ├── policy.html
│   │           ├── analytics.html
│   │           └── shops.html
├── build.gradle                         # Gradle 빌드 설정
├── CREATE_ALL_TABLES.sql                # 데이터베이스 스키마
├── API_DOCUMENTATION.md                 # API 문서
└── FINAL_PROJECT_GUIDE.md               # 이 문서
```

---

## 🗄️ 데이터베이스 설계

### 테이블 목록 (총 8개)

| 번호 | 테이블명 | 설명 | 주요 컬럼 |
|------|----------|------|-----------|
| 1 | USERS | 회원 정보 | USER_ID, NAME, EMAIL, PASSWORD, POINTS |
| 2 | POINT_TRANSACTIONS | 포인트 거래 내역 | TRANSACTION_ID, USER_ID, AMOUNT, TYPE |
| 3 | USAGE_RECORDS | 이용 기록 | RECORD_ID, USER_ID, TRANSPORT_TYPE, POINTS |
| 4 | SUBWAY_STATION | 지하철역 정보 | ID, STATION_NAME, LINE_NUMBER, LATITUDE, LONGITUDE |
| 5 | BIKE_STATIONS | 따릉이 대여소 | STATION_ID, STATION_NAME, AVAILABLE_BIKES |
| 6 | PUBLIC_PARKING | 공영 주차장 | PARKING_ID, PARKING_NAME, AVAILABLE_SPACES |
| 7 | POLICY | 정책 관리 | POLICY_ID, POLICY_NAME, POLICY_TYPE, ENABLED |
| 8 | SHOP | 제휴 상점 | SHOP_ID, SHOP_NAME, CATEGORY, DISCOUNT_RATE |

### ERD (Entity Relationship Diagram)

```
USERS (회원)
  ├── 1:N → POINT_TRANSACTIONS (포인트 거래)
  └── 1:N → USAGE_RECORDS (이용 기록)

SUBWAY_STATION (지하철역) - 독립 테이블
BIKE_STATIONS (따릉이) - 독립 테이블
PUBLIC_PARKING (주차장) - 독립 테이블
POLICY (정책) - 독립 테이블
SHOP (상점) - 독립 테이블
```

---

## 🚀 기능 목록

### 1. 회원 관리 시스템
- ✅ 회원가입 (이메일, 비밀번호, 이름, 전화번호)
- ✅ 로그인/로그아웃
- ✅ 마이페이지 (내 정보, 포인트 내역)
- ✅ 포인트 시스템 (가입 시 1,000P 지급)

### 2. KTX 예약
- ✅ KTX 열차 시간표 조회
- ✅ 출발지/도착지 선택 (서울, 수원, 평택, 천안아산)
- ✅ 좌석 선택 및 예약

### 3. 지하철 실시간 정보
- ✅ 서울 지하철 1~9호선 전체 노선도
- ✅ 역별 실시간 도착 정보
- ✅ 노선별 역 필터링
- ✅ 환승역 정보 제공

### 4. 버스 실시간 정보
- ✅ 시내버스/광역버스 실시간 위치 추적
- ✅ 버스 도착 예정 시간 표시
- ✅ 정류장별 버스 노선 정보

### 5. 공유 모빌리티 (따릉이/킥보드)
- ✅ 카카오맵 연동 지도 표시
- ✅ 따릉이 대여소 위치 및 재고 표시
- ✅ 킥보드 실시간 위치 및 배터리 상태
- ✅ 내 위치 기반 근처 대여소 검색

### 6. 공영 주차장
- ✅ 서울·경기 공영주차장 49개소 정보
- ✅ 실시간 주차 가능 현황
- ✅ 지역별/구역별 필터링
- ✅ 근처 주차장 검색 (Haversine 거리 계산)
- ✅ 주차 요금, 운영 시간, 결제 수단 정보

### 7. 정책 관리
- ✅ 비혼잡 시간대 인센티브
- ✅ 친환경 교통수단 이용 인센티브
- ✅ 정액 요금제 (월간패스)
- ✅ 사용지 지정 정책

### 8. 제휴 상점 연계
- ✅ 카페, 음식점, 편의점, 주유소, 운동시설
- ✅ 할인율 및 포인트 적립
- ✅ 영업 시간, 평점, 방문 횟수

### 9. 운영 대시보드
- ✅ 실시간 통계 (회원 수, 이용 건수, 포인트)
- ✅ 교통수단별 이용 현황 그래프
- ✅ 지역별 이용 분석

### 10. 데이터 분석
- ✅ 월별/일별 이용 추이
- ✅ 교통수단별 선호도 분석
- ✅ 정책 효과 분석

---

## 🔧 설치 및 실행 가이드

### 1. 사전 준비 사항

#### 필수 소프트웨어
- **JDK 17 이상** 설치
- **Oracle Database 11g XE** 설치 및 실행
- **Gradle 8.14.3** (프로젝트에 포함된 Wrapper 사용)
- **IDE**: IntelliJ IDEA 또는 Eclipse

#### Oracle 데이터베이스 설정
```sql
-- 사용자 생성 (선택사항, system 계정 사용 가능)
CREATE USER maas IDENTIFIED BY maas123;
GRANT CONNECT, RESOURCE, DBA TO maas;

-- 또는 system 계정 사용
-- Username: system
-- Password: oracle (설치 시 설정한 비밀번호)
```

### 2. 프로젝트 다운로드

```bash
cd c:\tools
# Git clone 또는 압축파일 해제
cd mobility-service
```

### 3. 데이터베이스 스키마 생성

#### SQL*Plus 사용
```bash
sqlplus system/oracle@localhost:1521/xe
SQL> @CREATE_ALL_TABLES.sql
```

#### SQL Developer 사용
1. SQL Developer 실행
2. `CREATE_ALL_TABLES.sql` 파일 열기
3. 전체 스크립트 실행 (F5)

### 4. application.properties 확인

파일 위치: `src/main/resources/application.properties`

```properties
# Server Port
server.port=9999

# Oracle Database Connection
spring.datasource.url=jdbc:oracle:thin:@localhost:1521:xe
spring.datasource.username=system
spring.datasource.password=oracle
spring.datasource.driver-class-name=oracle.jdbc.OracleDriver

# JPA/Hibernate
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.Oracle12cDialect

# Thymeleaf
spring.thymeleaf.cache=false
```

**⚠️ 주의**: 데이터베이스 비밀번호를 설치 시 설정한 값으로 변경하세요.

### 5. 빌드 및 실행

#### Windows 환경

```bash
# 1. 빌드 (테스트 제외)
gradlew.bat clean build -x test

# 2. 애플리케이션 실행
gradlew.bat bootRun

# 또는 백그라운드 실행
start /B cmd /c "gradlew.bat bootRun --no-daemon"
```

#### Linux/Mac 환경

```bash
# 1. 빌드
./gradlew clean build -x test

# 2. 애플리케이션 실행
./gradlew bootRun

# 또는 백그라운드 실행
./gradlew bootRun --no-daemon &
```

### 6. 실행 확인

#### 콘솔 로그 확인
```
Started MobilityServiceApplication in X.XXX seconds
Tomcat started on port(s): 9999 (http)
```

#### 브라우저 접속
```
http://localhost:9999
```

#### API 테스트
```bash
# 주차장 데이터 업데이트
curl -X POST http://localhost:9999/api/parking/update

# 전체 주차장 조회
curl -X GET http://localhost:9999/api/parking/all
```

---

## 📱 화면 구성

### 1. 메인 페이지 (/)
- 히어로 섹션: K-MaaS 플랫폼 소개
- 교통수단 카드: KTX, 지하철, 버스, 공유 모빌리티, 주차장
- 관리 카드: 대시보드, 정책 관리, 데이터 분석, 상권 연계
- 지역 배지: 서울, 경기, 인천

### 2. KTX 예약 (/ktx)
- 출발지/도착지 선택
- 날짜 선택
- 열차 시간표
- 좌석 선택

### 3. 지하철 실시간 (/subway)
- 노선 선택 (1~9호선)
- 역 목록
- 실시간 도착 정보
- 환승 정보

### 4. 버스 실시간 (/bus)
- 버스 노선 검색
- 정류장 정보
- 실시간 도착 예정 시간

### 5. 공유 모빌리티 (/bike)
- 카카오맵 지도
- 따릉이 대여소 마커
- 킥보드 위치 마커
- 재고 및 배터리 정보
- 내 위치 기반 검색

### 6. 공영 주차장 (/parking)
- 검색 필터 (지역, 키워드, 최소 여유 공간)
- 통계 대시보드 (4개 카드)
- 주차장 그리드 (3열)
- 주차 가능 상태 (색상 코드)

### 7. 대시보드 (/dashboard)
- 전체 통계 카드
- 교통수단별 이용 그래프
- 최근 활동 로그
- 실시간 주차장 가동률

### 8. 정책 관리 (/policy)
- 정책 목록
- 정책 활성화/비활성화
- 정책 설정 수정

### 9. 데이터 분석 (/analytics)
- 이용 추이 그래프
- 교통수단별 선호도
- 지역별 분석

### 10. 상권 연계 (/shops)
- 제휴 상점 목록
- 카테고리별 필터
- 할인율 표시
- 지도 위치 표시

---

## 🔐 보안 고려사항

### 1. 비밀번호 암호화
- BCrypt 알고리즘 사용 (향후 적용 예정)
- 현재는 평문 저장 (개발 환경)

### 2. SQL Injection 방지
- JPA의 Prepared Statement 자동 사용
- Native Query에서 `@Param` 사용

### 3. CORS 설정
- 개발 환경: 모든 Origin 허용
- 운영 환경: 특정 도메인만 허용 (설정 필요)

---

## 🧪 테스트 가이드

### 1. 주차장 시스템 테스트

```bash
# 1. 주차장 데이터 업데이트
curl -X POST http://localhost:9999/api/parking/update

# 2. 전체 주차장 조회 (49개소)
curl -X GET http://localhost:9999/api/parking/all

# 3. 서울 지역 주차장 조회
curl -X GET http://localhost:9999/api/parking/region/서울

# 4. 강남구 주차장 조회
curl -X GET http://localhost:9999/api/parking/district/강남구

# 5. 여유 공간 100개 이상 주차장 조회
curl -X GET "http://localhost:9999/api/parking/available?minSpaces=100"

# 6. 근처 주차장 검색 (강남역 기준)
curl -X GET "http://localhost:9999/api/parking/nearby?latitude=37.498&longitude=127.027&radius=5"
```

### 2. 웹 페이지 테스트

브라우저에서 다음 URL 접속하여 테스트:

- http://localhost:9999/ - 메인 페이지
- http://localhost:9999/ktx - KTX 예약
- http://localhost:9999/subway - 지하철
- http://localhost:9999/bus - 버스
- http://localhost:9999/bike - 공유 모빌리티
- http://localhost:9999/parking - 공영 주차장
- http://localhost:9999/dashboard - 대시보드
- http://localhost:9999/policy - 정책 관리
- http://localhost:9999/analytics - 데이터 분석
- http://localhost:9999/shops - 상권 연계

---

## 🐛 문제 해결 (Troubleshooting)

### 1. 포트 충돌 (Port already in use)

**증상**: `Port 9999 is already in use`

**해결방법**:
```bash
# Windows
netstat -ano | findstr :9999
taskkill /PID [프로세스ID] /F

# Linux/Mac
lsof -i :9999
kill -9 [프로세스ID]
```

### 2. 데이터베이스 연결 실패

**증상**: `Cannot create PoolableConnectionFactory`

**해결방법**:
1. Oracle Database 실행 확인
2. `application.properties`에서 연결 정보 확인
3. 방화벽에서 1521 포트 허용 확인

```bash
# Oracle 서비스 시작 (Windows)
net start OracleServiceXE
net start OracleXETNSListener
```

### 3. 빌드 실패

**증상**: `Could not resolve dependencies`

**해결방법**:
```bash
# Gradle 캐시 삭제 후 재빌드
gradlew.bat clean
gradlew.bat build --refresh-dependencies
```

### 4. Oracle Sequence 오류

**증상**: `Sequence does not exist`

**해결방법**:
```sql
-- CREATE_ALL_TABLES.sql 재실행
sqlplus system/oracle@localhost:1521/xe
SQL> @CREATE_ALL_TABLES.sql
```

---

## 📊 성능 최적화

### 1. 데이터베이스 인덱스

주요 검색 컬럼에 인덱스 적용:
- `SUBWAY_STATION`: LINE_NUMBER, STATION_NAME
- `BIKE_STATIONS`: DISTRICT
- `PUBLIC_PARKING`: REGION, DISTRICT, PARKING_CODE
- `SHOP`: CATEGORY, STATUS

### 2. JPA 쿼리 최적화

- N+1 문제 방지: `@EntityGraph` 사용
- Lazy Loading 적용: 연관 관계 최적화
- Native Query 사용: 복잡한 공간 검색 (Haversine)

### 3. 캐싱 전략

- 정적 데이터: 지하철역, 정책 정보 캐싱
- 동적 데이터: 실시간 주차 정보 짧은 TTL

---

## 🚀 배포 가이드

### 1. JAR 파일 생성

```bash
# 실행 가능한 JAR 빌드
gradlew.bat clean build -x test

# 생성된 파일 위치
build/libs/mobility-service-0.0.1-SNAPSHOT.jar
```

### 2. JAR 파일 실행

```bash
# 기본 실행
java -jar build/libs/mobility-service-0.0.1-SNAPSHOT.jar

# 프로파일 지정 실행
java -jar -Dspring.profiles.active=prod build/libs/mobility-service-0.0.1-SNAPSHOT.jar

# 백그라운드 실행 (Linux)
nohup java -jar build/libs/mobility-service-0.0.1-SNAPSHOT.jar > app.log 2>&1 &
```

### 3. 운영 환경 설정

`application-prod.properties` 생성:

```properties
server.port=80

spring.datasource.url=jdbc:oracle:thin:@운영DB주소:1521:xe
spring.datasource.username=운영계정
spring.datasource.password=운영비밀번호

spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=false

logging.level.root=INFO
```

---

## 📈 향후 개선 계획

### Phase 1: 보안 강화
- [ ] Spring Security 적용
- [ ] JWT 인증 시스템
- [ ] 비밀번호 암호화 (BCrypt)
- [ ] HTTPS 적용

### Phase 2: 기능 확장
- [ ] 결제 시스템 연동
- [ ] 실시간 알림 (WebSocket)
- [ ] 모바일 앱 개발
- [ ] 소셜 로그인 (카카오, 네이버)

### Phase 3: 데이터 분석
- [ ] 빅데이터 분석 (Spark)
- [ ] 머신러닝 예측 모델
- [ ] 추천 시스템
- [ ] 실시간 혼잡도 예측

### Phase 4: 인프라 확장
- [ ] 클라우드 배포 (AWS, Azure)
- [ ] Docker 컨테이너화
- [ ] Kubernetes 오케스트레이션
- [ ] CI/CD 파이프라인 (Jenkins, GitHub Actions)

---

## 👥 팀 정보

**프로젝트명**: K-MaaS Platform
**개발 과정**: Spring Boot 풀스택 개발
**협업사**: 에스트래픽 (태그리스 교통 기술)
**개발 기간**: 2026년 1월

---

## 📞 문의 및 지원

- **이메일**: contact@k-maas.kr
- **전화**: 02-1234-5678
- **GitHub**: (프로젝트 저장소 URL)

---

## 📄 라이선스

이 프로젝트는 교육 목적으로 개발되었습니다.

---

## 🎓 참고 자료

### 기술 문서
- [Spring Boot 공식 문서](https://spring.io/projects/spring-boot)
- [Oracle Database 11g 문서](https://docs.oracle.com/cd/E11882_01/index.htm)
- [Thymeleaf 공식 가이드](https://www.thymeleaf.org/documentation.html)

### API 문서
- [카카오맵 API](https://apis.map.kakao.com/)
- [서울 열린데이터광장](https://data.seoul.go.kr/)
- [경기데이터드림](https://data.gg.go.kr/)

---

**최종 업데이트**: 2026-01-12
**문서 버전**: 1.0.0

---

## 빠른 시작 (Quick Start)

```bash
# 1. 프로젝트 이동
cd c:\tools\mobility-service

# 2. 데이터베이스 스키마 생성
sqlplus system/oracle@localhost:1521/xe @CREATE_ALL_TABLES.sql

# 3. 애플리케이션 빌드
gradlew.bat clean build -x test

# 4. 애플리케이션 실행
gradlew.bat bootRun

# 5. 브라우저 접속
# http://localhost:9999

# 6. 주차장 데이터 로드
curl -X POST http://localhost:9999/api/parking/update

# 완료!
```

---

**Happy Coding! 🚀**
