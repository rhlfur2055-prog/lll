package com.maas.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_HIGHWAY_SESSION")
public class HighwaySession {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "maas_seq")
    @SequenceGenerator(name = "maas_seq", sequenceName = "MAAS_SEQ", allocationSize = 1)
    @Column(name = "SESSION_ID")
    private Long sessionId;

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "ENTRY_TOLLGATE")
    private String entryTollgate;

    @Column(name = "EXIT_TOLLGATE")
    private String exitTollgate;

    @Column(name = "ENTRY_TIME")
    private LocalDateTime entryTime;

    @Column(name = "EXIT_TIME")
    private LocalDateTime exitTime;

    @Column(name = "DISTANCE_KM")
    private Double distanceKm;

    @Column(name = "TOLL_FEE")
    private Integer tollFee;

    public HighwaySession() {}

    // Getters and Setters
    public Long getSessionId() { return sessionId; }
    public void setSessionId(Long sessionId) { this.sessionId = sessionId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getEntryTollgate() { return entryTollgate; }
    public void setEntryTollgate(String entryTollgate) { this.entryTollgate = entryTollgate; }

    public String getExitTollgate() { return exitTollgate; }
    public void setExitTollgate(String exitTollgate) { this.exitTollgate = exitTollgate; }

    public LocalDateTime getEntryTime() { return entryTime; }
    public void setEntryTime(LocalDateTime entryTime) { this.entryTime = entryTime; }

    public LocalDateTime getExitTime() { return exitTime; }
    public void setExitTime(LocalDateTime exitTime) { this.exitTime = exitTime; }

    public Double getDistanceKm() { return distanceKm; }
    public void setDistanceKm(Double distanceKm) { this.distanceKm = distanceKm; }

    public Integer getTollFee() { return tollFee; }
    public void setTollFee(Integer tollFee) { this.tollFee = tollFee; }
}
