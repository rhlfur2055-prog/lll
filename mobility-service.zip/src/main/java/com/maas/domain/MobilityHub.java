package com.maas.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_MOBILITY_HUB")
public class MobilityHub {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "maas_seq")
    @SequenceGenerator(name = "maas_seq", sequenceName = "MAAS_SEQ", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "CATEGORY", nullable = false)
    private String category;

    @Column(name = "LINE_NAME")
    private String lineName;

    @Column(name = "STATION_NAME", nullable = false)
    private String stationName;

    @Column(name = "LATITUDE")
    private Double latitude;

    @Column(name = "LONGITUDE")
    private Double longitude;

    @Column(name = "ADD_INFO", length = 1000)
    private String addInfo;

    public MobilityHub() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getLineName() { return lineName; }
    public void setLineName(String lineName) { this.lineName = lineName; }

    public String getStationName() { return stationName; }
    public void setStationName(String stationName) { this.stationName = stationName; }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    public String getAddInfo() { return addInfo; }
    public void setAddInfo(String addInfo) { this.addInfo = addInfo; }
}
