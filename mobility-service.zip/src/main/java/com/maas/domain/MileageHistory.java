package com.maas.domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TB_MILEAGE_HISTORY")
public class MileageHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "maas_seq")
    @SequenceGenerator(name = "maas_seq", sequenceName = "MAAS_SEQ", allocationSize = 1)
    @Column(name = "HISTORY_ID")
    private Long historyId;

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "SERVICE_TYPE")
    private String serviceType;

    @Column(name = "TRANSACTION_TYPE")
    private String transactionType;

    @Column(name = "POINTS")
    private Integer points;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @PrePersist
    public void setCreatedTimestamp() {
        this.createdAt = LocalDateTime.now();
    }

    public MileageHistory() {}

    public MileageHistory(Long historyId, Long userId, String serviceType, String transactionType, Integer points, LocalDateTime createdAt) {
        this.historyId = historyId;
        this.userId = userId;
        this.serviceType = serviceType;
        this.transactionType = transactionType;
        this.points = points;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Long getHistoryId() { return historyId; }
    public void setHistoryId(Long historyId) { this.historyId = historyId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getServiceType() { return serviceType; }
    public void setServiceType(String serviceType) { this.serviceType = serviceType; }

    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }

    public Integer getPoints() { return points; }
    public void setPoints(Integer points) { this.points = points; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
