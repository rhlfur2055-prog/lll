package com.maas.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_USER_ASSET")
public class UserAsset {
    @Id
    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "USERNAME")
    private String username;

    @Column(name = "MILEAGE")
    private Integer mileage;

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    public UserAsset() {}

    public UserAsset(Long userId, String username, Integer mileage, LocalDateTime updatedAt) {
        this.userId = userId;
        this.username = username;
        this.mileage = mileage;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public Integer getMileage() { return mileage; }
    public void setMileage(Integer mileage) { this.mileage = mileage; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    @PrePersist
    @PreUpdate
    public void updateTimestamp() {
        this.updatedAt = LocalDateTime.now();
    }
}
