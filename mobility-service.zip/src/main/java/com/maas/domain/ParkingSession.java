package com.maas.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.time.Duration;

@Entity
@Table(name = "TB_PARKING_SESSION")
public class ParkingSession {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "maas_seq")
    @SequenceGenerator(name = "maas_seq", sequenceName = "MAAS_SEQ", allocationSize = 1)
    @Column(name = "SESSION_ID")
    private Long sessionId;

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "PARKING_LOT_ID")
    private Long parkingLotId;

    @Column(name = "CAR_NUMBER")
    private String carNumber;

    @Column(name = "QR_CODE")
    private String qrCode;

    @Column(name = "ENTRY_TIME")
    private LocalDateTime entryTime;

    @Column(name = "EXIT_TIME")
    private LocalDateTime exitTime;

    @Column(name = "PARKING_FEE")
    private Integer parkingFee;

    public ParkingSession() {}

    // Getters and Setters
    public Long getSessionId() { return sessionId; }
    public void setSessionId(Long sessionId) { this.sessionId = sessionId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getParkingLotId() { return parkingLotId; }
    public void setParkingLotId(Long parkingLotId) { this.parkingLotId = parkingLotId; }

    public String getCarNumber() { return carNumber; }
    public void setCarNumber(String carNumber) { this.carNumber = carNumber; }

    public String getQrCode() { return qrCode; }
    public void setQrCode(String qrCode) { this.qrCode = qrCode; }

    public LocalDateTime getEntryTime() { return entryTime; }
    public void setEntryTime(LocalDateTime entryTime) { this.entryTime = entryTime; }

    public LocalDateTime getExitTime() { return exitTime; }
    public void setExitTime(LocalDateTime exitTime) { this.exitTime = exitTime; }

    public Integer getParkingFee() { return parkingFee; }
    public void setParkingFee(Integer parkingFee) { this.parkingFee = parkingFee; }

    // 최종 요금 계산
    public Integer getFinalFee() {
        if (exitTime == null) return 0;

        long minutes = Duration.between(entryTime, exitTime).toMinutes();
        int baseFee = 1000; // 기본 30분
        int baseTime = 30;

        if (minutes <= baseTime) {
            return baseFee;
        }

        long extraMinutes = minutes - baseTime;
        int extraFee = (int) ((extraMinutes / 10) * 500);

        return baseFee + extraFee;
    }
}
