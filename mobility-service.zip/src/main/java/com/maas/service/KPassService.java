package com.maas.service;

import com.maas.domain.UserAsset;
import com.maas.domain.MileageHistory;
import com.maas.repository.UserAssetRepository;
import com.maas.repository.MileageHistoryRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
@Transactional
public class KPassService {

    private static final Logger log = LoggerFactory.getLogger(KPassService.class);

    private final UserAssetRepository userAssetRepository;
    private final MileageHistoryRepository mileageHistoryRepository;

    public KPassService(UserAssetRepository userAssetRepository, MileageHistoryRepository mileageHistoryRepository) {
        this.userAssetRepository = userAssetRepository;
        this.mileageHistoryRepository = mileageHistoryRepository;
    }

    public Map<String, Object> earnMileage(Long userId, String serviceType, Double distanceKm) {
        UserAsset user = userAssetRepository.findById(userId)
            .orElseGet(() -> createDefaultUser(userId));

        int rate = getRate(serviceType);
        int earnedPoints = (int) (distanceKm * rate);

        user.setMileage(user.getMileage() + earnedPoints);
        user.setUpdatedAt(LocalDateTime.now());
        userAssetRepository.save(user);

        MileageHistory history = new MileageHistory();
        history.setUserId(userId);
        history.setServiceType(serviceType);
        history.setTransactionType("EARN");
        history.setPoints(earnedPoints);
        history.setCreatedAt(LocalDateTime.now());
        
        mileageHistoryRepository.save(history);

        log.info("User {} earned {} points via {}", userId, earnedPoints, serviceType);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("earnedPoints", earnedPoints);
        result.put("totalMileage", user.getMileage());
        return result;
    }

    public Map<String, Object> useMileage(Long userId, Integer points) {
        UserAsset user = userAssetRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getMileage() < points) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Insufficient mileage");
            return error;
        }

        user.setMileage(user.getMileage() - points);
        user.setUpdatedAt(LocalDateTime.now());
        userAssetRepository.save(user);

        MileageHistory history = new MileageHistory();
        history.setUserId(userId);
        history.setTransactionType("USE");
        history.setPoints(-points);
        history.setCreatedAt(LocalDateTime.now());
        
        mileageHistoryRepository.save(history);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("usedPoints", points);
        result.put("remainingMileage", user.getMileage());
        return result;
    }

    public List<MileageHistory> getMileageHistory(Long userId) {
        return mileageHistoryRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    private UserAsset createDefaultUser(Long userId) {
        UserAsset newUser = new UserAsset();
        newUser.setUserId(userId);
        newUser.setUsername("User" + userId);
        newUser.setMileage(0);
        newUser.setUpdatedAt(LocalDateTime.now());
        return userAssetRepository.save(newUser);
    }

    private int getRate(String serviceType) {
        return switch (serviceType.toUpperCase()) {
            case "SUBWAY" -> 10;
            case "BUS" -> 8;
            case "BIKE" -> 15;
            case "KTX" -> 50;
            default -> 5;
        };
    }
}