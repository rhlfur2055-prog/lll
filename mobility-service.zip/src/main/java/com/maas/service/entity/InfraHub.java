package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "TB_INFRA_HUB")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InfraHub {
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "TYPE_NAME")
    private String typeName;

    @Column(name = "STATION_NAME")
    private String stationName;

    @Column(name = "LATITUDE")
    private Double latitude;

    @Column(name = "LONGITUDE")
    private Double longitude;

    @Column(name = "ADD_INFO")
    private String addInfo;

    @Column(name = "IS_TAGLESS")
    private Integer isTagless;
}
