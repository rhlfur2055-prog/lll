package com.maas.service.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 정책 정보 엔티티
 * 비혼잡 시간대, 친환경, 정액요금제, 사용지 지정 정책 관리
 */
@Entity
@Table(name = "policy")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Policy {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "policy_seq")
    @SequenceGenerator(name = "policy_seq", sequenceName = "POLICY_SEQ", allocationSize = 1)
    @Column(name = "policy_id")
    private Long policyId;

    /**
     * 정책명
     */
    @Column(name = "policy_name", nullable = false, length = 100)
    private String policyName;

    /**
     * 정책 타입 (off-peak: 비혼잡, eco: 친환경, flat: 정액, area: 사용지지정)
     */
    @Column(name = "policy_type", nullable = false, length = 20)
    private String policyType;

    /**
     * 활성화 여부
     */
    @Column(name = "enabled", nullable = false)
    private Boolean enabled;

    /**
     * 설정값 (JSON 형식)
     * 예: {"10:00-12:00": 1.0, "12:00-14:00": 1.5}
     */
    @Lob
    @Column(name = "config")
    private String config;

    /**
     * 시작일
     */
    @Column(name = "start_date")
    private LocalDate startDate; // context for safe replacement
    
    // ...

    /**
     * 설명
     */
    @Lob
    @Column(name = "description")
    private String description;

    /**
     * 적용 대상 (전체/학생/직장인/노인)
     */
    @Column(name = "target_group", length = 50)
    private String targetGroup;

    /**
     * 생성일
     */
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    /**
     * 수정일
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
