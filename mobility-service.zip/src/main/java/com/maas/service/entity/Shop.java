package com.maas.service.entity;

import java.time.LocalDateTime;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 제휴 상점 정보 엔티티
 */
@Entity
@Table(name = "shop")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Shop {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "shop_seq")
    @SequenceGenerator(name = "shop_seq", sequenceName = "SHOP_SEQ", allocationSize = 1)
    @Column(name = "shop_id")
    private Long shopId;

    /**
     * 상점명
     */
    @Column(name = "shop_name", nullable = false, length = 100)
    private String shopName;

    /**
     * 카테고리 (카페, 음식점, 편의점, 주유소, 운동)
     */
    @Column(name = "category", nullable = false, length = 50)
    private String category;

    /**
     * 주소
     */
    @Column(name = "address", nullable = false, length = 200)
    private String address;

    /**
     * 위도
     */
    @Column(name = "latitude", nullable = false)
    private Double latitude;

    /**
     * 경도
     */
    @Column(name = "longitude", nullable = false)
    private Double longitude;

    /**
     * 전화번호
     */
    @Column(name = "phone", length = 20)
    private String phone;

    /**
     * 평점 (1.0 ~ 5.0)
     */
    @Column(name = "rating")
    private Double rating;

    /**
     * 할인율 (%)
     */
    @Column(name = "discount_rate", nullable = false)
    private Integer discountRate;

    /**
     * 방문/이용 횟수
     */
    @Column(name = "visit_count")
    private Integer visitCount;

    /**
     * 영업 시작 시간
     */
    @Column(name = "opening_time")
    private LocalTime openingTime;

    /**
     * 영업 종료 시간
     */
    @Column(name = "closing_time")
    private LocalTime closingTime;

    /**
     * 영업 상태 (open: 영업중, closed: 휴무, preparing: 준비중)
     */
    @Column(name = "status", nullable = false, length = 20)
    private String status;

    /**
     * 제휴 시작일
     */
    @Column(name = "partner_since")
    private LocalDateTime partnerSince;

    /**
     * 활성화 여부
     */
    @Column(name = "active")
    private Boolean active;

    /**
     * 상점 이미지 URL
     */
    @Column(name = "image_url", length = 500)
    private String imageUrl;

    /**
     * 상점 설명
     */
    @Lob
    @Column(name = "description")
    private String description;

    /**
     * 생성일
     */
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    /**
     * 수정일
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (visitCount == null) {
            visitCount = 0;
        }
        if (active == null) {
            active = true;
        }
        if (status == null) {
            status = "open";
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
