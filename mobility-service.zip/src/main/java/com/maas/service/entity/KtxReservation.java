package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * KTX 예매 내역 엔티티
 * 사용자의 KTX 예매 정보를 DB에 저장
 */
@Entity
@Table(name = "KTX_RESERVATION")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class KtxReservation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ktx_seq")
    @SequenceGenerator(name = "ktx_seq", sequenceName = "KTX_RESERVATION_SEQ", allocationSize = 1)
    @Column(name = "RESERVATION_ID")
    private Long reservationId;

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "TRAIN_NO", length = 20)
    private String trainNo; // 열차 번호

    @Column(name = "DEP_STATION", length = 50)
    private String depStation; // 출발역

    @Column(name = "ARR_STATION", length = 50)
    private String arrStation; // 도착역

    @Column(name = "DEP_DATE")
    private LocalDateTime depDate; // 출발 날짜/시간

    @Column(name = "ARR_DATE")
    private LocalDateTime arrDate; // 도착 날짜/시간

    @Column(name = "PASSENGER_NAME", length = 50)
    private String passengerName; // 승객명

    @Column(name = "PASSENGER_PHONE", length = 20)
    private String passengerPhone; // 승객 전화번호

    @Column(name = "SEAT_TYPE", length = 20)
    private String seatType; // 좌석 종류 (일반실/특실)

    @Column(name = "SEAT_NUMBER", length = 10)
    private String seatNumber; // 좌석 번호

    @Column(name = "FARE")
    private Integer fare; // 운임

    @Column(name = "DISCOUNT_RATE")
    private Integer discountRate; // 할인율

    @Column(name = "FINAL_FARE")
    private Integer finalFare; // 최종 요금

    @Column(name = "PAYMENT_METHOD", length = 20)
    private String paymentMethod; // 결제 방법

    @Column(name = "RESERVATION_STATUS", length = 20)
    private String reservationStatus; // 예매 상태 (RESERVED, CANCELLED, COMPLETED)

    @Column(name = "RESERVATION_DATE")
    private LocalDateTime reservationDate; // 예매일시

    @Column(name = "CONFIRMATION_NUMBER", length = 50, unique = true)
    private String confirmationNumber; // 예매 확인 번호

    @Column(name = "KPASS_POINTS_EARNED")
    private Integer kpassPointsEarned; // K-Pass 적립 포인트

    @Column(name = "NOTES", length = 500)
    private String notes; // 비고
}
