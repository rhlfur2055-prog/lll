package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TB_MILEAGE_HISTORY")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MileageHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mileage_seq")
    @SequenceGenerator(name = "mileage_seq", sequenceName = "MILEAGE_SEQ", allocationSize = 1)
    @Column(name = "HISTORY_ID")
    private Long historyId;
    
    @Column(name = "USER_ID")
    private Long userId;
    
    @Column(name = "SERVICE_TYPE")
    private String serviceType;
    
    @Column(name = "TRANSACTION_TYPE")
    private String transactionType;
    
    @Column(name = "POINTS")
    private Integer points;
    
    @Column(name = "BALANCE_AFTER")
    private Integer balanceAfter;
    
    @Column(name = "DESCRIPTION")
    private String description;
    
    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}
