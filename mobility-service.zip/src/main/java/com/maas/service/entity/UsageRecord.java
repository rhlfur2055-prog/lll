package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "USAGE_RECORDS")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UsageRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "usage_seq")
    @SequenceGenerator(name = "usage_seq", sequenceName = "USAGE_SEQ", allocationSize = 1)
    @Column(name = "RECORD_ID")
    private Long id;

    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "TRANSPORT_TYPE")
    private String transportType; // BUS, SUBWAY, TRAIN, BIKE

    @Column(name = "ROUTE_INFO")
    private String routeInfo;

    @Column(name = "USAGE_TIME")
    private LocalDateTime usageTime;

    @Column(name = "REGION")
    private String region;

    @Column(name = "POINTS")
    private Integer points;

    @Column(name = "POLICY_APPLIED")
    private String policyApplied;

    @Column(name = "DAY_OF_WEEK")
    private String dayOfWeek;

    @PrePersist
    protected void onCreate() {
        if (usageTime == null) {
            usageTime = LocalDateTime.now();
        }
    }
}
