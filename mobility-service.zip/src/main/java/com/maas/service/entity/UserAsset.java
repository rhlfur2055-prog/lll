package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TB_USER_ASSETS")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserAsset {
    @Id
    @Column(name = "USER_ID")
    private Long userId;
    
    @Column(name = "MILEAGE")
    private Integer mileage;
    
    @Column(name = "CARBON_SAVED")
    private Double carbonSaved;
    
    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;
}

