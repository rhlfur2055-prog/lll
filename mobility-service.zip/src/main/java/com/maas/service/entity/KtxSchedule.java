package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "TB_KTX_SCHEDULE")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KtxSchedule {
    @Id
    @Column(name = "SCH_ID")
    private Long schId;

    @Column(name = "TRAIN_NO")
    private String trainNo;

    @Column(name = "DEP_PLACE")
    private String depPlace;

    @Column(name = "ARR_PLACE")
    private String arrPlace;

    @Column(name = "DEP_TIME")
    private String depTime;

    @Column(name = "ARR_TIME")
    private String arrTime;

    @Column(name = "CHARGE")
    private Integer charge;
}
