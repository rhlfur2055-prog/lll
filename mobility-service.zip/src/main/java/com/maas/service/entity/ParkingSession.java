package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "parking_session")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ParkingSession {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "parking_seq_gen")
    @SequenceGenerator(name = "parking_seq_gen", sequenceName = "PARKING_SEQ", allocationSize = 1)
    private Long sessionId;

    @Column(nullable = false)
    private String carNumber;
    
    @Column(nullable = false)
    private LocalDateTime entryTime;
    
    private LocalDateTime exitTime;
    private Integer parkingFee;
    private Integer discountRate;
    private String discountReason;
    private Integer finalFee;
    private Integer freeMinutes;
    private Double latitude;
    private Double longitude;
    private String parkingLotId;
    private String parkingLotName;
    private String paymentStatus;
    private String qrCode;
    private Long userId;
    private String vehicleType;
    private String parkingGrade;
    private Integer maxDailyFee;
    
    @Column(columnDefinition = "NUMBER(1)")
    private Boolean isEcoDiscount;
    
    @Column(columnDefinition = "NUMBER(1)")
    private Boolean isDisabledDiscount;
}
