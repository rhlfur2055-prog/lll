/*
package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;

// NEUTRALIZED LEGACY FILE - DUPLICATE OF com.maas.domain.MobilityHub
// @Entity
// @Table(name = "TB_MOBILITY_HUB")
// @Getter @Setter
// @NoArgsConstructor
// @AllArgsConstructor
// @Builder
public class MobilityHub {
    // ... content removed ...
}
*/
