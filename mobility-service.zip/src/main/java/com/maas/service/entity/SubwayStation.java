/*
package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;

// NEUTRALIZED LEGACY FILE
// @Entity
public class SubwayStation {
}
*/
