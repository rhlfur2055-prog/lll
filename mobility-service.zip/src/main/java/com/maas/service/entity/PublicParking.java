package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "PUBLIC_PARKING")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PublicParking {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "parking_seq")
    @SequenceGenerator(name = "parking_seq", sequenceName = "PARKING_SEQ", allocationSize = 1)
    @Column(name = "PARKING_ID")
    private Long parkingId;

    @Column(name = "PARKING_CODE", unique = true)
    private String parkingCode;

    @Column(name = "PARKING_NAME", nullable = false)
    private String parkingName;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "LATITUDE")
    private Double latitude;

    @Column(name = "LONGITUDE")
    private Double longitude;

    @Column(name = "TOTAL_SPACES")
    private Integer totalSpaces;

    @Column(name = "AVAILABLE_SPACES")
    private Integer availableSpaces;

    @Column(name = "PARKING_TYPE")
    private String parkingType; // 노외, 노상

    @Column(name = "OPERATION_TYPE")
    private String operationType; // 공영, 민영

    @Column(name = "WEEKDAY_BEGIN_TIME")
    private String weekdayBeginTime;

    @Column(name = "WEEKDAY_END_TIME")
    private String weekdayEndTime;

    @Column(name = "WEEKEND_BEGIN_TIME")
    private String weekendBeginTime;

    @Column(name = "WEEKEND_END_TIME")
    private String weekendEndTime;

    @Column(name = "RATES")
    private String rates; // 요금 정보

    @Column(name = "PAY_METHOD")
    private String payMethod;

    @Column(name = "TELEPHONE")
    private String telephone;

    @Column(name = "REGION")
    private String region; // 서울, 경기

    @Column(name = "DISTRICT")
    private String district; // 구/시

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
