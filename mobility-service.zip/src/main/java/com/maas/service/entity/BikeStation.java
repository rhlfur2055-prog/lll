package com.maas.service.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "BIKE_STATIONS")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BikeStation {

    @Id
    @Column(name = "STATION_ID")
    private String stationId;

    @Column(name = "STATION_NAME", nullable = false)
    private String stationName;

    @Column(name = "LATITUDE", nullable = false)
    private Double latitude;

    @Column(name = "LONGITUDE", nullable = false)
    private Double longitude;

    @Column(name = "AVAILABLE_BIKES")
    private Integer availableBikes;

    @Column(name = "TOTAL_DOCKS")
    private Integer totalDocks;

    @Column(name = "DISTRICT")
    private String district;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
