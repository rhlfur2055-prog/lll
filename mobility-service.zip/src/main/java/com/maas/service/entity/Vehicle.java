package com.maas.service.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 차량 정보 엔티티
 * 사용자의 차량 정보 및 할인 혜택 관리
 */
@Entity
@Table(name = "VEHICLE")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(
    name = "VEHICLE_SEQ_GENERATOR",
    sequenceName = "VEHICLE_SEQ",
    initialValue = 1,
    allocationSize = 1
)
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "VEHICLE_SEQ_GENERATOR")
    @Column(name = "VEHICLE_ID")
    private Long vehicleId;

    @Column(name = "USER_ID", nullable = false)
    private Long userId;

    @Column(name = "VEHICLE_NUMBER", length = 20, unique = true, nullable = false)
    private String vehicleNumber; // 번호판 (예: 12가3456)

    @Column(name = "VEHICLE_TYPE", length = 20, nullable = false)
    private String vehicleType; // COMPACT(경차), SEDAN(승용차), SUV, TRUCK(화물차), SPECIAL(특수차)

    @Column(name = "VEHICLE_CLASS")
    private Integer vehicleClass; // 고속도로 차종 (1~5종)

    @Column(name = "IS_ELECTRIC")
    private Boolean isElectric; // 전기차 여부

    @Column(name = "IS_DISABLED")
    private Boolean isDisabled; // 장애인 차량 여부

    @Column(name = "IS_ECO_FRIENDLY")
    private Boolean isEcoFriendly; // 친환경 차량 여부 (하이브리드 포함)

    @Column(name = "OWNER_NAME", length = 50)
    private String ownerName;

    @Column(name = "MODEL_NAME", length = 100)
    private String modelName; // 차량 모델명

    @Column(name = "MANUFACTURER", length = 50)
    private String manufacturer; // 제조사

    @Column(name = "YEAR")
    private Integer year; // 연식

    @Column(name = "REGISTERED_AT")
    private LocalDateTime registeredAt;

    @Column(name = "IS_ACTIVE")
    private Boolean isActive; // 활성 차량 여부

    @PrePersist
    protected void onCreate() {
        this.registeredAt = LocalDateTime.now();
        if (this.isActive == null) {
            this.isActive = true;
        }
        if (this.isElectric == null) {
            this.isElectric = false;
        }
        if (this.isDisabled == null) {
            this.isDisabled = false;
        }
        if (this.isEcoFriendly == null) {
            this.isEcoFriendly = false;
        }
    }
}
