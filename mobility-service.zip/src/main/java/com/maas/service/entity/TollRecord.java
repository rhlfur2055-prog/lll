package com.maas.service.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 고속도로 통행 기록 엔티티
 * 한국도로공사 API 연동하여 하이패스/현금 결제 정보 관리
 */
@Entity
@Table(name = "TOLL_RECORD")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(
    name = "TOLL_SEQ_GENERATOR",
    sequenceName = "TOLL_SEQ",
    initialValue = 1,
    allocationSize = 1
)
public class TollRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TOLL_SEQ_GENERATOR")
    @Column(name = "TOLL_ID")
    private Long tollId;

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "VEHICLE_NUMBER", length = 20, nullable = false)
    private String vehicleNumber;

    @Column(name = "ENTRY_TOLLGATE", length = 100, nullable = false)
    private String entryTollgate;

    @Column(name = "ENTRY_TOLLGATE_CODE", length = 20)
    private String entryTollgateCode;

    @Column(name = "EXIT_TOLLGATE", length = 100, nullable = false)
    private String exitTollgate;

    @Column(name = "EXIT_TOLLGATE_CODE", length = 20)
    private String exitTollgateCode;

    @Column(name = "ROUTE_NAME", length = 50)
    private String routeName; // 경부선, 남해선 등

    @Column(name = "VEHICLE_TYPE", length = 20, nullable = false)
    private String vehicleType; // 1종(경차), 2종(승용차), 3종(중형), 4종(대형), 5종(특수)

    @Column(name = "ENTRY_TIME", nullable = false)
    private LocalDateTime entryTime;

    @Column(name = "EXIT_TIME")
    private LocalDateTime exitTime;

    @Column(name = "BASE_FEE")
    private Integer baseFee; // 기본 통행료

    @Column(name = "DISCOUNT_AMOUNT")
    private Integer discountAmount; // 할인 금액

    @Column(name = "FINAL_FEE")
    private Integer finalFee; // 최종 결제 금액

    @Column(name = "PAYMENT_METHOD", length = 20)
    private String paymentMethod; // HIPASS, CASH, CARD

    @Column(name = "DISCOUNT_REASON", length = 200)
    private String discountReason; // 경차 50%, 출퇴근 20%, 전기차 50%, 하이패스 10%

    @Column(name = "DISTANCE_KM")
    private Double distanceKm; // 주행 거리 (km)

    @Column(name = "IS_RUSH_HOUR")
    private Boolean isRushHour; // 출퇴근 시간대 여부

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
