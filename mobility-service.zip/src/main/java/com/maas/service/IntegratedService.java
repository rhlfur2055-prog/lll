package com.maas.service;

import com.maas.domain.MobilityHub;
import com.maas.domain.UserAsset;
import com.maas.service.dto.LineGroupDTO;
import com.maas.service.dto.StationResponseDTO;
import com.maas.repository.MobilityHubRepository;
import com.maas.repository.UserAssetRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jakarta.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class IntegratedService {

    private static final Logger log = LoggerFactory.getLogger(IntegratedService.class);

    private final MobilityHubRepository mobilityHubRepository;
    private final UserAssetRepository userAssetRepository;
    private final SubwayRealtimeService subwayRealtimeService;

    public IntegratedService(MobilityHubRepository mobilityHubRepository,
                           UserAssetRepository userAssetRepository,
                           SubwayRealtimeService subwayRealtimeService) {
        this.mobilityHubRepository = mobilityHubRepository;
        this.userAssetRepository = userAssetRepository;
        this.subwayRealtimeService = subwayRealtimeService;
    }

    @PostConstruct
    @Transactional
    public void initializeMockData() {
        // DB에 데이터가 없으면 초기 목 데이터 생성 -> DISABLE FOR REAL DATA
        // if (mobilityHubRepository.count() == 0) {
        //     log.info("🚀 Initializing mock subway station data...");
        //     createMockSubwayStations();
        //     log.info("✅ Mock data initialized successfully!");
        // }
    }

    @Transactional
    public void createMockSubwayStations() {
        List<MobilityHub> stations = new ArrayList<>();

        // 1호선 주요역 (서울)
        stations.add(createStation("SUBWAY", "1호선", "소요산역", 37.9481, 127.0611));
        stations.add(createStation("SUBWAY", "1호선", "서울역", 37.5547, 126.9708));
        stations.add(createStation("SUBWAY", "1호선", "신도림역", 37.5087, 126.8912));
        stations.add(createStation("SUBWAY", "1호선", "구로역", 37.5034, 126.8816));
        stations.add(createStation("SUBWAY", "1호선", "가산디지털단지역", 37.4817, 126.8828));
        stations.add(createStation("SUBWAY", "1호선", "금천구청역", 37.4569, 126.8955));
        stations.add(createStation("SUBWAY", "1호선", "광명역", 37.4161, 126.8845));
        stations.add(createStation("SUBWAY", "1호선", "석수역", 37.4351, 126.9229));
        stations.add(createStation("SUBWAY", "1호선", "안양역", 37.4014, 126.9217));
        stations.add(createStation("SUBWAY", "1호선", "명학역", 37.3887, 126.9367));
        stations.add(createStation("SUBWAY", "1호선", "금정역", 37.3696, 126.9453));
        stations.add(createStation("SUBWAY", "1호선", "군포역", 37.3614, 126.9348));
        stations.add(createStation("SUBWAY", "1호선", "당정역", 37.3523, 126.9256));
        stations.add(createStation("SUBWAY", "1호선", "의왕역", 37.3446, 126.9683));
        stations.add(createStation("SUBWAY", "1호선", "성균관대역", 37.2979, 126.9753));
        stations.add(createStation("SUBWAY", "1호선", "화서역", 37.2833, 127.0043));
        stations.add(createStation("SUBWAY", "1호선", "수원역", 37.2657, 127.0013));
        stations.add(createStation("SUBWAY", "1호선", "세류역", 37.2477, 127.0486));
        stations.add(createStation("SUBWAY", "1호선", "병점역", 37.1903, 126.9835));
        stations.add(createStation("SUBWAY", "1호선", "세마역", 37.1616, 126.9478));
        stations.add(createStation("SUBWAY", "1호선", "오산대역", 37.1397, 126.9629));
        stations.add(createStation("SUBWAY", "1호선", "오산역", 37.1330, 126.9904));
        stations.add(createStation("SUBWAY", "1호선", "진위역", 37.0830, 127.0411));
        stations.add(createStation("SUBWAY", "1호선", "송탄역", 37.0632, 127.0754));
        stations.add(createStation("SUBWAY", "1호선", "서정리역", 37.0189, 127.0870));
        stations.add(createStation("SUBWAY", "1호선", "평택역", 36.9916, 127.0851));
        stations.add(createStation("SUBWAY", "1호선", "성환역", 36.9159, 127.1323));
        stations.add(createStation("SUBWAY", "1호선", "직산역", 36.8871, 127.1763));
        stations.add(createStation("SUBWAY", "1호선", "두정역", 36.8164, 127.1584));
        stations.add(createStation("SUBWAY", "1호선", "천안역", 36.8099, 127.1453));
        stations.add(createStation("SUBWAY", "1호선", "봉명역", 36.7924, 127.1314));
        stations.add(createStation("SUBWAY", "1호선", "쌍용역", 36.7656, 127.1199));
        stations.add(createStation("SUBWAY", "1호선", "아산역", 36.7399, 127.1024));
        stations.add(createStation("SUBWAY", "1호선", "탕정역", 36.7010, 127.0851));
        stations.add(createStation("SUBWAY", "1호선", "배방역", 36.6697, 127.0663));
        stations.add(createStation("SUBWAY", "1호선", "온양온천역", 36.6438, 127.0698));
        stations.add(createStation("SUBWAY", "1호선", "신창역", 36.6285, 127.0812));

        // 2호선 주요역
        stations.add(createStation("SUBWAY", "2호선", "시청역", 37.5646, 126.9769));
        stations.add(createStation("SUBWAY", "2호선", "강남역", 37.498, 127.0276));
        stations.add(createStation("SUBWAY", "2호선", "역삼역", 37.5004, 127.0365));
        stations.add(createStation("SUBWAY", "2호선", "선릉역", 37.5045, 127.0491));
        stations.add(createStation("SUBWAY", "2호선", "삼성역", 37.5088, 127.0633));
        stations.add(createStation("SUBWAY", "2호선", "홍대입구역", 37.5571, 126.9245));
        stations.add(createStation("SUBWAY", "2호선", "신촌역", 37.5559, 126.9368));

        // 3호선 주요역
        stations.add(createStation("SUBWAY", "3호선", "양재역", 37.4845, 127.0345));
        stations.add(createStation("SUBWAY", "3호선", "교대역", 37.4934, 127.0143));
        stations.add(createStation("SUBWAY", "3호선", "고속터미널역", 37.5044, 127.0047));

        // 4호선 주요역
        stations.add(createStation("SUBWAY", "4호선", "사당역", 37.4764, 126.9813));
        stations.add(createStation("SUBWAY", "4호선", "수유역", 37.6386, 127.0253));

        // 7호선 주요역
        stations.add(createStation("SUBWAY", "7호선", "강남구청역", 37.5172, 127.0417));
        stations.add(createStation("SUBWAY", "7호선", "논현역", 37.5107, 127.0227));

        // 신분당선
        stations.add(createStation("SUBWAY", "신분당선", "강남역", 37.498, 127.0276));
        stations.add(createStation("SUBWAY", "신분당선", "신논현역", 37.5047, 127.0249));

        // 수인분당선
        stations.add(createStation("SUBWAY", "수인분당선", "강남구청역", 37.5172, 127.0417));
        stations.add(createStation("SUBWAY", "수인분당선", "선릉역", 37.5045, 127.0491));

        // 인천1호선 전체역 (송내역 포함!)
        stations.add(createStation("SUBWAY", "인천1호선", "계양역", 37.5378, 126.7373));
        stations.add(createStation("SUBWAY", "인천1호선", "귤현역", 37.5272, 126.7291));
        stations.add(createStation("SUBWAY", "인천1호선", "박촌역", 37.5162, 126.7211));
        stations.add(createStation("SUBWAY", "인천1호선", "임학역", 37.5051, 126.7131));
        stations.add(createStation("SUBWAY", "인천1호선", "계산역", 37.4970, 126.7108));
        stations.add(createStation("SUBWAY", "인천1호선", "경인교대입구역", 37.4865, 126.7032));
        stations.add(createStation("SUBWAY", "인천1호선", "작전역", 37.4763, 126.6938));
        stations.add(createStation("SUBWAY", "인천1호선", "갈산역", 37.4681, 126.6881));
        stations.add(createStation("SUBWAY", "인천1호선", "부평구청역", 37.4582, 126.6837));
        stations.add(createStation("SUBWAY", "인천1호선", "부평시장역", 37.4503, 126.6725));
        stations.add(createStation("SUBWAY", "인천1호선", "부평역", 37.4428, 126.6637));
        stations.add(createStation("SUBWAY", "인천1호선", "동수역", 37.4361, 126.6559));
        stations.add(createStation("SUBWAY", "인천1호선", "부평삼거리역", 37.4286, 126.6475));
        stations.add(createStation("SUBWAY", "인천1호선", "간석오거리역", 37.4205, 126.6393));
        stations.add(createStation("SUBWAY", "인천1호선", "인천시청역", 37.4126, 126.6311));
        stations.add(createStation("SUBWAY", "인천1호선", "예술회관역", 37.4051, 126.6229));
        stations.add(createStation("SUBWAY", "인천1호선", "인천터미널역", 37.3975, 126.6147));
        stations.add(createStation("SUBWAY", "인천1호선", "문학경기장역", 37.3901, 126.6065));
        stations.add(createStation("SUBWAY", "인천1호선", "선학역", 37.3829, 126.5983));
        stations.add(createStation("SUBWAY", "인천1호선", "신연수역", 37.3757, 126.5901));
        stations.add(createStation("SUBWAY", "인천1호선", "원인재역", 37.3685, 126.5819));
        stations.add(createStation("SUBWAY", "인천1호선", "동춘역", 37.3613, 126.5737));
        stations.add(createStation("SUBWAY", "인천1호선", "동막역", 37.3541, 126.5655));
        stations.add(createStation("SUBWAY", "인천1호선", "캠퍼스타운역", 37.3469, 126.5573));
        stations.add(createStation("SUBWAY", "인천1호선", "테크노파크역", 37.3397, 126.5491));
        stations.add(createStation("SUBWAY", "인천1호선", "지식정보단지역", 37.3325, 126.5409));
        stations.add(createStation("SUBWAY", "인천1호선", "인천대입구역", 37.3253, 126.5327));
        stations.add(createStation("SUBWAY", "인천1호선", "센트럴파크역", 37.3181, 126.5245));
        stations.add(createStation("SUBWAY", "인천1호선", "국제업무지구역", 37.3109, 126.5163));

        // 수인선 (송내역 포함!)
        stations.add(createStation("SUBWAY", "수인선", "인천역", 37.4755, 126.6165));
        stations.add(createStation("SUBWAY", "수인선", "신포역", 37.4656, 126.6164));
        stations.add(createStation("SUBWAY", "수인선", "숭의역", 37.4557, 126.6380));
        stations.add(createStation("SUBWAY", "수인선", "인하대역", 37.4486, 126.6541));
        stations.add(createStation("SUBWAY", "수인선", "송도역", 37.4405, 126.6667));
        stations.add(createStation("SUBWAY", "수인선", "연수역", 37.4103, 126.6782));
        stations.add(createStation("SUBWAY", "수인선", "원인재역", 37.3956, 126.6893));
        stations.add(createStation("SUBWAY", "수인선", "남동인더스파크역", 37.3809, 126.7004));
        stations.add(createStation("SUBWAY", "수인선", "호구포역", 37.3662, 126.7115));
        stations.add(createStation("SUBWAY", "수인선", "인천논현역", 37.3515, 126.7226));
        stations.add(createStation("SUBWAY", "수인선", "소래포구역", 37.3368, 126.7337));
        stations.add(createStation("SUBWAY", "수인선", "월곶역", 37.3221, 126.7448));
        stations.add(createStation("SUBWAY", "수인선", "달월역", 37.3074, 126.7559));
        stations.add(createStation("SUBWAY", "수인선", "오이도역", 37.2927, 126.7670));
        stations.add(createStation("SUBWAY", "수인선", "정왕역", 37.2780, 126.7781));
        stations.add(createStation("SUBWAY", "수인선", "신길온천역", 37.2633, 126.7892));
        stations.add(createStation("SUBWAY", "수인선", "안산역", 37.2486, 126.8003));
        stations.add(createStation("SUBWAY", "수인선", "초지역", 37.2339, 126.8114));
        stations.add(createStation("SUBWAY", "수인선", "고잔역", 37.2192, 126.8225));
        stations.add(createStation("SUBWAY", "수인선", "중앙역", 37.2045, 126.8336));
        stations.add(createStation("SUBWAY", "수인선", "한대앞역", 37.1898, 126.8447));
        stations.add(createStation("SUBWAY", "수인선", "사리역", 37.1751, 126.8558));
        stations.add(createStation("SUBWAY", "수인선", "야목역", 37.1604, 126.8669));
        stations.add(createStation("SUBWAY", "수인선", "어천역", 37.1457, 126.8780));
        stations.add(createStation("SUBWAY", "수인선", "오목천역", 37.1310, 126.8891));
        stations.add(createStation("SUBWAY", "수인선", "고색역", 37.1163, 126.9002));
        stations.add(createStation("SUBWAY", "수인선", "수원역", 37.2657, 127.0013));
        stations.add(createStation("SUBWAY", "수인선", "매교역", 37.2511, 127.0124));
        stations.add(createStation("SUBWAY", "수인선", "수원시청역", 37.2365, 127.0235));
        stations.add(createStation("SUBWAY", "수인선", "매탄권선역", 37.2219, 127.0346));
        stations.add(createStation("SUBWAY", "수인선", "망포역", 37.2073, 127.0457));
        stations.add(createStation("SUBWAY", "수인선", "영통역", 37.1927, 127.0568));
        stations.add(createStation("SUBWAY", "수인선", "청명역", 37.1781, 127.0679));
        stations.add(createStation("SUBWAY", "수인선", "상갈역", 37.1635, 127.0790));
        stations.add(createStation("SUBWAY", "수인선", "기흥역", 37.1489, 127.0901));
        stations.add(createStation("SUBWAY", "수인선", "신갈역", 37.1343, 127.1012));
        stations.add(createStation("SUBWAY", "수인선", "구성역", 37.1197, 127.1123));
        stations.add(createStation("SUBWAY", "수인선", "보정역", 37.1051, 127.1234));
        stations.add(createStation("SUBWAY", "수인선", "죽전역", 37.0905, 127.1345));
        stations.add(createStation("SUBWAY", "수인선", "오리역", 37.0759, 127.1456));
        stations.add(createStation("SUBWAY", "수인선", "미금역", 37.0613, 127.1567));
        stations.add(createStation("SUBWAY", "수인선", "정자역", 37.0467, 127.1678));
        stations.add(createStation("SUBWAY", "수인선", "수내역", 37.0321, 127.1789));
        stations.add(createStation("SUBWAY", "수인선", "서현역", 37.0175, 127.1900));
        stations.add(createStation("SUBWAY", "수인선", "이매역", 37.0029, 127.2011));
        stations.add(createStation("SUBWAY", "수인선", "야탑역", 36.9883, 127.2122));
        stations.add(createStation("SUBWAY", "수인선", "모란역", 36.9737, 127.2233));
        stations.add(createStation("SUBWAY", "수인선", "태평역", 36.9591, 127.2344));
        stations.add(createStation("SUBWAY", "수인선", "가천대역", 36.9445, 127.2455));
        stations.add(createStation("SUBWAY", "수인선", "복정역", 36.9299, 127.2566));
        stations.add(createStation("SUBWAY", "수인선", "수서역", 36.9153, 127.2677));
        stations.add(createStation("SUBWAY", "수인선", "대모산입구역", 36.9007, 127.2788));
        stations.add(createStation("SUBWAY", "수인선", "개포동역", 36.8861, 127.2899));
        stations.add(createStation("SUBWAY", "수인선", "구룡역", 36.8715, 127.3010));
        stations.add(createStation("SUBWAY", "수인선", "도곡역", 36.8569, 127.3121));
        stations.add(createStation("SUBWAY", "수인선", "한티역", 36.8423, 127.3232));
        stations.add(createStation("SUBWAY", "수인선", "선릉역", 37.5045, 127.0491));
        stations.add(createStation("SUBWAY", "수인선", "선정릉역", 37.5169, 127.0412));
        stations.add(createStation("SUBWAY", "수인선", "강남구청역", 37.5172, 127.0417));
        stations.add(createStation("SUBWAY", "수인선", "압구정로데오역", 37.5275, 127.0405));
        stations.add(createStation("SUBWAY", "수인선", "서울숲역", 37.5443, 127.0443));
        stations.add(createStation("SUBWAY", "수인선", "왕십리역", 37.5613, 127.0371));

        // 경인선 (송내역 핵심!)
        stations.add(createStation("SUBWAY", "경인선", "구로역", 37.5034, 126.8816));
        stations.add(createStation("SUBWAY", "경인선", "개봉역", 37.4886, 126.8558));
        stations.add(createStation("SUBWAY", "경인선", "오류동역", 37.4944, 126.8463));
        stations.add(createStation("SUBWAY", "경인선", "온수역", 37.4917, 126.8256));
        stations.add(createStation("SUBWAY", "경인선", "역곡역", 37.4865, 126.8118));
        stations.add(createStation("SUBWAY", "경인선", "소사역", 37.4788, 126.7923));
        stations.add(createStation("SUBWAY", "경인선", "부천역", 37.4838, 126.7829));
        stations.add(createStation("SUBWAY", "경인선", "중동역", 37.5030, 126.7643));
        stations.add(createStation("SUBWAY", "경인선", "송내역", 37.5048, 126.7515)); // 송내역!!!
        stations.add(createStation("SUBWAY", "경인선", "부개역", 37.5091, 126.7347));
        stations.add(createStation("SUBWAY", "경인선", "부평역", 37.4897, 126.7228));
        stations.add(createStation("SUBWAY", "경인선", "백운역", 37.4800, 126.7072));
        stations.add(createStation("SUBWAY", "경인선", "동암역", 37.4697, 126.6834));
        stations.add(createStation("SUBWAY", "경인선", "간석역", 37.4513, 126.6598));
        stations.add(createStation("SUBWAY", "경인선", "주안역", 37.4395, 126.6784));
        stations.add(createStation("SUBWAY", "경인선", "도화역", 37.4517, 126.6478));
        stations.add(createStation("SUBWAY", "경인선", "제물포역", 37.4647, 126.6180));
        stations.add(createStation("SUBWAY", "경인선", "도원역", 37.4750, 126.6327));
        stations.add(createStation("SUBWAY", "경인선", "인천역", 37.4755, 126.6165));

        mobilityHubRepository.saveAll(stations);
    }

    private MobilityHub createStation(String category, String lineName, String stationName, double lat, double lon) {
        MobilityHub hub = new MobilityHub();
        hub.setCategory(category);
        hub.setLineName(lineName);
        hub.setStationName(stationName);
        hub.setLatitude(lat);
        hub.setLongitude(lon);
        hub.setAddInfo("{}");
        return hub;
    }
    
    public List<MobilityHub> getAllStations() {
        return mobilityHubRepository.findAll();
    }
    
    public List<MobilityHub> getStationsByCategory(String category) {
        return mobilityHubRepository.findByCategoryOrderByLineNameAscStationNameAsc(category);
    }

    public Map<String, Object> getStationWithRealtime(String stationName) {
        List<MobilityHub> stations = mobilityHubRepository.findByStationNameContainingOrderByLineName(stationName);
        
        if (stations.isEmpty()) {
            return Map.of("error", "Station not found");
        }
        
        MobilityHub station = stations.get(0);
        List<Map<String, Object>> arrivals = subwayRealtimeService.getRealtimeArrivals(stationName);
        
        return Map.of(
            "station", toDTO(station),
            "arrivals", arrivals
        );
    }
    
    public List<String> getSubwayLines() {
        return mobilityHubRepository.findDistinctSubwayLines();
    }
    
    public Map<String, List<MobilityHub>> getSubwayStationsGroupedByLine() {
        List<MobilityHub> stations = mobilityHubRepository
            .findByCategoryOrderByLineNameAscStationNameAsc("SUBWAY");
        return stations.stream()
            .collect(Collectors.groupingBy(
                MobilityHub::getLineName,
                LinkedHashMap::new,
                Collectors.toList()
            ));
    }
    
    public List<MobilityHub> getStationsByLine(String lineName) {
        return mobilityHubRepository.findByLineNameOrderByStationNameAsc(lineName);
    }
    
    public List<MobilityHub> searchStations(String keyword) {
        return mobilityHubRepository.findByStationNameContainingOrderByLineName(keyword);
    }
    
    public List<MobilityHub> search(String keyword) {
        return searchStations(keyword);
    }
    
    public List<MobilityHub> getSubwayStations() {
        return getStationsByCategory("SUBWAY");
    }
    
    public List<MobilityHub> getKtxStations() {
        return getStationsByCategory("KTX");
    }
    
    public List<MobilityHub> getParkingLots() {
        return getStationsByCategory("PARKING");
    }
    
    public List<MobilityHub> getBikeStations() {
        return getStationsByCategory("BIKE");
    }
    
    public UserAsset getUserMileage(Long userId) {
        return userAssetRepository.findById(userId).orElse(null);
    }
    
    public Map<String, Integer> getLineStationCounts() {
        List<Object[]> results = mobilityHubRepository.countStationsByLine();
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (Object[] result : results) {
            counts.put((String) result[0], ((Long) result[1]).intValue());
        }
        return counts;
    }
    
    public List<LineGroupDTO> getLineGroupsWithStations() {
        Map<String, List<MobilityHub>> grouped = getSubwayStationsGroupedByLine();
        Map<String, Integer> counts = getLineStationCounts();
        
        return grouped.entrySet().stream()
            .map(entry -> new LineGroupDTO(
                entry.getKey(),
                counts.getOrDefault(entry.getKey(), 0),
                getLineColor(entry.getKey()),
                entry.getValue().stream()
                    .map(this::toDTO)
                    .collect(Collectors.toList())
            ))
            .collect(Collectors.toList());
    }
    
    public StationResponseDTO toDTO(MobilityHub hub) {
        return new StationResponseDTO(
            hub.getId(),
            hub.getCategory(),
            hub.getLineName(),
            hub.getStationName(),
            hub.getLatitude(),
            hub.getLongitude(),
            hub.getAddInfo()
        );
    }
    
    public String getLineColor(String lineName) {
        Map<String, String> colors = new HashMap<>();
        colors.put("1호선", "#0052A4");
        colors.put("2호선", "#00A84D");
        colors.put("3호선", "#EF7C1C");
        colors.put("4호선", "#00A5DE");
        colors.put("5호선", "#996CAC");
        colors.put("6호선", "#CD7C2F");
        colors.put("7호선", "#747F00");
        colors.put("8호선", "#E6186C");
        colors.put("9호선", "#BDB092");
        colors.put("인천1호선", "#7CA8D5");
        colors.put("인천2호선", "#F5A200");
        colors.put("수인분당선", "#FABE00");
        colors.put("신분당선", "#D4003B");
        colors.put("경의중앙선", "#77C4A3");
        colors.put("경춘선", "#0C8E72");
        colors.put("공항철도", "#0090D2");
        colors.put("우이신설선", "#B0CE18");
        colors.put("서해선", "#8FC31F");
        colors.put("김포골드라인", "#A17E00");
        return colors.getOrDefault(lineName, "#999999");
    }

    // --- Mock Data Methods for Legacy/Missing Endpoints ---

    public List<Map<String, Object>> getBusStops(double lat, double lng, double radius) {
        // Mock Bus Stops
        List<Map<String, Object>> stops = new ArrayList<>();
        stops.add(Map.of("name", "강남역.교보타워사거리", "id", "22001", "lat", lat + 0.001, "lng", lng + 0.001, "routes", List.of("144", "402", "420")));
        stops.add(Map.of("name", "논현역.신사역", "id", "22002", "lat", lat - 0.001, "lng", lng - 0.001, "routes", List.of("140", "470", "741")));
        return stops;
    }

    public List<Map<String, Object>> searchKtx(String departure, String arrival, String date) {
        // Mock KTX Schedules
        List<Map<String, Object>> schedules = new ArrayList<>();
        schedules.add(Map.of("trainNo", "KTX 101", "departureTime", "08:00", "arrivalTime", "10:30", "price", 59800));
        schedules.add(Map.of("trainNo", "KTX 103", "departureTime", "09:00", "arrivalTime", "11:30", "price", 59800));
        return schedules;
    }
    
    public List<Map<String, Object>> getShopList(String category) {
        // Mock Shops
        List<Map<String, Object>> shops = new ArrayList<>();
        shops.add(Map.of("name", "스타벅스 강남점", "category", "CAFE", "discount", "10%", "distance", "150m"));
        shops.add(Map.of("name", "CU 역삼점", "category", "CONVENIENCE", "discount", "5%", "distance", "300m"));
        return shops;
    }
    
    public Map<String, Object> getAnalyticsStats() {
        // Mock Analytics
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalPassengers", 15420);
        stats.put("congestionLevel", "MEDIUM");
        stats.put("popularRoute", "강남-삼성");
        stats.put("message", "지난주 대비 이용객 5% 증가");
        return stats;
    }
}

