package com.maas.service.config;

import com.maas.service.util.ApiKeyDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * API 키 설정 및 자동 디코딩
 * application.properties의 HEX 인코딩된 키를 자동으로 디코딩
 */
@Configuration
public class ApiKeyConfig implements InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(ApiKeyConfig.class);

    private final ApiKeyDecoder decoder;

    // Raw values from properties
    @Value("${seoul.metro.arrival.key}")
    private String seoulMetroArrivalKeyRaw;

    @Value("${seoul.metro.congestion.key}")
    private String seoulMetroCongestionKeyRaw;

    @Value("${gyeonggi.bus.key}")
    private String gyeonggiBusKeyRaw;

    @Value("${incheon.bus.key}")
    private String incheonBusKeyRaw;

    @Value("${public.data.api.key}")
    private String publicDataPortalKeyRaw;

    @Value("${ktx.api.key}")
    private String ktxApiKeyRaw;

    @Value("${bike.api.key}")
    private String bikeApiKeyRaw;

    @Value("${air.quality.key}")
    private String airQualityKeyRaw;

    @Value("${shop.api.key}")
    private String shopApiKeyRaw;

    @Value("${seoul.congestion.key}")
    private String seoulCongestionKeyRaw;

    @Value("${kakao.rest.api.key}")
    private String kakaoRestApiKey;

    @Value("${kakao.js.key}")
    private String kakaoJsKey;

    @Value("${naver.client.id}")
    private String naverClientId;

    @Value("${naver.client.secret}")
    private String naverClientSecret;

    @Value("${highway.api.key:YOUR_API_KEY_HERE}")
    private String highwayApiKeyRaw;

    // Decoded keys
    private String seoulMetroArrivalKey;
    private String seoulMetroCongestionKey;
    private String gyeonggiBusKey;
    private String incheonBusKey;
    private String publicDataPortalKey;
    private String ktxApiKey;
    private String bikeApiKey;
    private String airQualityKey;
    private String shopApiKey;
    private String seoulCongestionKey;
    private String highwayApiKey;

    public ApiKeyConfig(ApiKeyDecoder decoder) {
        this.decoder = decoder;
    }

    /**
     * 애플리케이션 시작 시 모든 API 키 자동 디코딩
     * InitializingBean 인터페이스를 통한 초기화
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        decodeApiKeys();
    }

    private void decodeApiKeys() {
        log.info("=".repeat(80));
        log.info("API 키 디코딩 시작...");
        log.info("=".repeat(80));

        seoulMetroArrivalKey = decoder.decodeHex(seoulMetroArrivalKeyRaw);
        seoulMetroCongestionKey = decoder.decodeHex(seoulMetroCongestionKeyRaw);
        gyeonggiBusKey = decoder.decodeHex(gyeonggiBusKeyRaw);
        incheonBusKey = decoder.decodeHex(incheonBusKeyRaw);
        publicDataPortalKey = decoder.decodeHex(publicDataPortalKeyRaw);
        ktxApiKey = decoder.decodeHex(ktxApiKeyRaw);
        bikeApiKey = decoder.decodeHex(bikeApiKeyRaw);
        airQualityKey = decoder.decodeHex(airQualityKeyRaw);
        shopApiKey = decoder.decodeHex(shopApiKeyRaw);
        seoulCongestionKey = decoder.decodeHex(seoulCongestionKeyRaw);
        highwayApiKey = decoder.decodeHex(highwayApiKeyRaw);

        log.info("✅ Seoul Metro Arrival Key: {}", decoder.isHexEncoded(seoulMetroArrivalKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Seoul Metro Congestion Key: {}", decoder.isHexEncoded(seoulMetroCongestionKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Gyeonggi Bus Key: {}", decoder.isHexEncoded(gyeonggiBusKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Incheon Bus Key: {}", decoder.isHexEncoded(incheonBusKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Public Data Portal Key: {}", decoder.isHexEncoded(publicDataPortalKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ KTX API Key: {}", decoder.isHexEncoded(ktxApiKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Bike API Key: {}", decoder.isHexEncoded(bikeApiKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Air Quality Key: {}", decoder.isHexEncoded(airQualityKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Shop API Key: {}", decoder.isHexEncoded(shopApiKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Seoul Congestion Key: {}", decoder.isHexEncoded(seoulCongestionKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Highway API Key: {}", decoder.isHexEncoded(highwayApiKeyRaw) ? "디코딩 완료" : "원본 사용");
        log.info("✅ Kakao Keys: 원본 사용 (평문)");
        log.info("✅ Naver Keys: 원본 사용 (평문)");

        log.info("=".repeat(80));
        log.info("=".repeat(80));
    }

    // --- Manual Getters ---

    public ApiKeyDecoder getDecoder() { return decoder; }
    public String getSeoulMetroArrivalKeyRaw() { return seoulMetroArrivalKeyRaw; }
    public String getSeoulMetroCongestionKeyRaw() { return seoulMetroCongestionKeyRaw; }
    public String getGyeonggiBusKeyRaw() { return gyeonggiBusKeyRaw; }
    public String getIncheonBusKeyRaw() { return incheonBusKeyRaw; }
    public String getPublicDataPortalKeyRaw() { return publicDataPortalKeyRaw; }
    public String getKtxApiKeyRaw() { return ktxApiKeyRaw; }
    public String getBikeApiKeyRaw() { return bikeApiKeyRaw; }
    public String getAirQualityKeyRaw() { return airQualityKeyRaw; }
    public String getShopApiKeyRaw() { return shopApiKeyRaw; }
    public String getSeoulCongestionKeyRaw() { return seoulCongestionKeyRaw; }
    public String getKakaoRestApiKey() { return kakaoRestApiKey; }
    public String getKakaoJsKey() { return kakaoJsKey; }
    public String getNaverClientId() { return naverClientId; }
    public String getNaverClientSecret() { return naverClientSecret; }
    public String getHighwayApiKeyRaw() { return highwayApiKeyRaw; }

    public String getSeoulMetroArrivalKey() { return seoulMetroArrivalKey; }
    public String getSeoulMetroCongestionKey() { return seoulMetroCongestionKey; }
    public String getGyeonggiBusKey() { return gyeonggiBusKey; }
    public String getIncheonBusKey() { return incheonBusKey; }
    public String getPublicDataPortalKey() { return publicDataPortalKey; }
    public String getKtxApiKey() { return ktxApiKey; }
    public String getBikeApiKey() { return bikeApiKey; }
    public String getAirQualityKey() { return airQualityKey; }
    public String getShopApiKey() { return shopApiKey; }
    public String getSeoulCongestionKey() { return seoulCongestionKey; }
    public String getHighwayApiKey() { return highwayApiKey; }
}
