package com.maas.service.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;

/**
 * 캐시 설정
 * API 응답을 메모리에 캐싱하여 외부 API 호출 빈도 감소
 */
@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public CacheManager cacheManager() {
        SimpleCacheManager cacheManager = new SimpleCacheManager();
        cacheManager.setCaches(Arrays.asList(
                // 지하철 캐시 (5분)
                new ConcurrentMapCache("metroArrival"),
                new ConcurrentMapCache("metroStations"),
                new ConcurrentMapCache("metroCongestion"),

                // 버스 캐시 (1분)
                new ConcurrentMapCache("gyeonggiBusLocation"),
                new ConcurrentMapCache("gyeonggiBusRoute"),
                new ConcurrentMapCache("incheonBusLocation"),
                new ConcurrentMapCache("incheonBusRoute"),

                // 공공데이터 캐시
                new ConcurrentMapCache("ktxTrains"),          // 10분
                new ConcurrentMapCache("bikeStations"),       // 5분
                new ConcurrentMapCache("subwayStations"),     // 1시간
                new ConcurrentMapCache("airQuality"),         // 30분
                new ConcurrentMapCache("shopInfo"),           // 1일
                new ConcurrentMapCache("seoulCongestion")     // 5분
        ));
        return cacheManager;
    }
}
