package com.maas.service.exception;



import java.time.LocalDateTime;

public class ErrorResponse {
    private boolean success;
    private String errorCode;
    private String message;
    private String details;
    private LocalDateTime timestamp;

    public ErrorResponse() {}

    public ErrorResponse(boolean success, String errorCode, String message, String details, LocalDateTime timestamp) {
        this.success = success;
        this.errorCode = errorCode;
        this.message = message;
        this.details = details;
        this.timestamp = timestamp;
    }

    public boolean isSuccess() { return success; }
    public String getErrorCode() { return errorCode; }
    public String getMessage() { return message; }
    public String getDetails() { return details; }
    public LocalDateTime getTimestamp() { return timestamp; }

    public void setSuccess(boolean success) { this.success = success; }
    public void setErrorCode(String errorCode) { this.errorCode = errorCode; }
    public void setMessage(String message) { this.message = message; }
    public void setDetails(String details) { this.details = details; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public static ErrorResponse of(String errorCode, String message) {
        return new ErrorResponse(false, errorCode, message, null, LocalDateTime.now());
    }

    public static ErrorResponse of(String errorCode, String message, String details) {
        return new ErrorResponse(false, errorCode, message, details, LocalDateTime.now());
    }
}
