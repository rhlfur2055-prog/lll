package com.maas.service;

import com.maas.domain.ParkingSession;
import com.maas.repository.ParkingSessionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Service
@Transactional
public class ParkingQrService {

    private static final Logger log = LoggerFactory.getLogger(ParkingQrService.class);

    private final ParkingSessionRepository parkingSessionRepository;

    public ParkingQrService(ParkingSessionRepository parkingSessionRepository) {
        this.parkingSessionRepository = parkingSessionRepository;
    }

    public Map<String, Object> generateEntryQr(Long userId, Long parkingLotId, String carNumber) {
        String qrData = String.format("KMAAS-PARKING-%d-%d-%s-%d",
            userId, parkingLotId, carNumber, System.currentTimeMillis());

        ParkingSession session = new ParkingSession();
        session.setUserId(userId);
        session.setParkingLotId(parkingLotId);
        session.setCarNumber(carNumber);
        session.setQrCode(qrData);
        session.setEntryTime(LocalDateTime.now());

        parkingSessionRepository.save(session);

        log.info("Generated entry QR for user {} at parking {}", userId, parkingLotId);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("qrCode", qrData);
        result.put("qrCodeImage", generateQrCodeImage(qrData));
        result.put("entryTime", session.getEntryTime().toString());
        result.put("message", "입차 완료");
        return result;
    }

    public Map<String, Object> scanExitQr(String qrCode) {
        ParkingSession session = parkingSessionRepository.findByQrCode(qrCode)
            .orElseThrow(() -> new RuntimeException("Invalid QR code"));

        session.setExitTime(LocalDateTime.now());
        int fee = session.getFinalFee();
        session.setParkingFee(fee);
        parkingSessionRepository.save(session);

        long minutes = Duration.between(session.getEntryTime(), session.getExitTime()).toMinutes();

        log.info("Scanned exit QR: {}, Fee: {}", qrCode, fee);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("entryTime", session.getEntryTime().toString());
        result.put("exitTime", session.getExitTime().toString());
        result.put("durationMinutes", minutes);
        result.put("parkingFee", fee);
        result.put("message", "출차 완료");
        return result;
    }

    private String generateQrCodeImage(String data) {
        return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
    }
}
