package com.maas.service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubwaySearchResponseDTO {
    private boolean success;
    private String message;
    private List<SubwayStationDTO> stations;
    private int totalCount;
}
