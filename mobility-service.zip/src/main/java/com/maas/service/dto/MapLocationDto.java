package com.maas.service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MapLocationDto {
    private String name;
    private Double latitude;
    private Double longitude;
    private String type; // SUBWAY, KTX, BIKE, PARKING
    private String lineName;
    private String address;
}
