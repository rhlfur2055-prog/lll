package com.maas.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubwayStationDTO {
    private Long id;
    private String stationName;
    private String lineName;
    private String lineColor;
    private String previousStation;
    private String nextStation;
    private Double latitude;
    private Double longitude;
    private Integer isTaglessZone;
}
