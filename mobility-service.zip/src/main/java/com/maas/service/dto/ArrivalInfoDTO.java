package com.maas.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 실시간 도착 정보 DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ArrivalInfoDTO {
    private String stationName;
    private String stationCode;
    private Integer lineNumber;
    private String lineName;
    private String lineColor;
    private Double latitude;
    private Double longitude;
    private String transferLines;
    private List<TrainArrivalDTO> upTrains;     // 상행 열차
    private List<TrainArrivalDTO> downTrains;   // 하행 열차
    private LocalDateTime lastUpdated;
    private Integer totalTrains;                // 전체 열차 수
    private Integer averageWaitTime;            // 평균 대기 시간 (초)
}
