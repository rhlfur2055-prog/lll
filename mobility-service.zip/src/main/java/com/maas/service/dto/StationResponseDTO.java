package com.maas.service.dto;



public class StationResponseDTO {
    private Long id;
    private String category;
    private String lineName;
    private String stationName;
    private Double latitude;
    private Double longitude;
    private String addInfo;

    public StationResponseDTO() {}

    public StationResponseDTO(Long id, String category, String lineName, String stationName, Double latitude, Double longitude, String addInfo) {
        this.id = id;
        this.category = category;
        this.lineName = lineName;
        this.stationName = stationName;
        this.latitude = latitude;
        this.longitude = longitude;
        this.addInfo = addInfo;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getLineName() { return lineName; }
    public void setLineName(String lineName) { this.lineName = lineName; }

    public String getStationName() { return stationName; }
    public void setStationName(String stationName) { this.stationName = stationName; }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    public String getAddInfo() { return addInfo; }
    public void setAddInfo(String addInfo) { this.addInfo = addInfo; }
}
