package com.maas.service.dto;


import java.util.List;

public class LineGroupDTO {
    private String lineName;
    private Integer stationCount;
    private String color;
    private List<StationResponseDTO> stations;

    public LineGroupDTO() {}

    public LineGroupDTO(String lineName, Integer stationCount, String color, List<StationResponseDTO> stations) {
        this.lineName = lineName;
        this.stationCount = stationCount;
        this.color = color;
        this.stations = stations;
    }

    // Getters and Setters
    public String getLineName() { return lineName; }
    public void setLineName(String lineName) { this.lineName = lineName; }

    public Integer getStationCount() { return stationCount; }
    public void setStationCount(Integer stationCount) { this.stationCount = stationCount; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public List<StationResponseDTO> getStations() { return stations; }
    public void setStations(List<StationResponseDTO> stations) { this.stations = stations; }
}
