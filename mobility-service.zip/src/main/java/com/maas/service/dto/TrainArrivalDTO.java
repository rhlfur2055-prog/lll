package com.maas.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 열차 도착 정보 DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TrainArrivalDTO {
    private String direction;           // 방향 (상행/하행)
    private String destination;         // 종착역
    private String arrivalTime;         // 도착 예정 시간
    private Integer arrivalSeconds;     // 도착 예정 시간 (초)
    private String currentStation;      // 현재 위치
    private String trainType;           // 열차 종류 (일반/급행)
    private String congestion;          // 혼잡도 (여유/보통/혼잡)
    private Integer congestionLevel;    // 혼잡도 레벨 (0-100)
    private String trainNo;             // 열차 번호
}
