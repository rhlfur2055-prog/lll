package com.maas.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 역 정보 DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StationDTO {
    private Long stationId;
    private String stationName;
    private String stationCode;
    private Integer lineNumber;
    private String lineName;
    private String lineColor;
    private Double latitude;
    private Double longitude;
    private String transferLines;
}
