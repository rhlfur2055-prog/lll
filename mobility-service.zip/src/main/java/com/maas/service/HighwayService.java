package com.maas.service;

import com.maas.domain.HighwaySession;
import com.maas.repository.HighwaySessionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
@Transactional
public class HighwayService {

    private static final Logger log = LoggerFactory.getLogger(HighwayService.class);

    private final HighwaySessionRepository highwaySessionRepository;
    private final KPassService kPassService;

    public HighwayService(HighwaySessionRepository highwaySessionRepository, KPassService kPassService) {
        this.highwaySessionRepository = highwaySessionRepository;
        this.kPassService = kPassService;
    }

    public Map<String, Object> enterHighway(Long userId, String tollgateName) {
        HighwaySession session = new HighwaySession();
        session.setUserId(userId);
        session.setEntryTollgate(tollgateName);
        session.setEntryTime(LocalDateTime.now());

        highwaySessionRepository.save(session);

        log.info("User {} entered highway at {}", userId, tollgateName);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", tollgateName + " 진입 완료");
        result.put("entryTime", session.getEntryTime().toString());
        return result;
    }

    public Map<String, Object> exitHighway(Long userId, String tollgateName) {
        HighwaySession session = highwaySessionRepository.findByUserIdAndExitTimeIsNull(userId)
            .orElseThrow(() -> new RuntimeException("No active highway session"));

        // 거리 계산 (Mock - 실제로는 톨게이트 DB 조회)
        double distanceKm = new Random().nextDouble(10, 100);

        // 요금 계산 (기본 900원 + km당 100원)
        int tollFee = 900 + (int)(distanceKm * 100);

        session.setExitTollgate(tollgateName);
        session.setExitTime(LocalDateTime.now());
        session.setDistanceKm(distanceKm);
        session.setTollFee(tollFee);
        highwaySessionRepository.save(session);

        // 마일리지 차감
        kPassService.useMileage(userId, tollFee);

        log.info("User {} exited highway. Distance: {}km, Fee: {}", userId, distanceKm, tollFee);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("distanceKm", String.format("%.1f", distanceKm));
        result.put("tollFee", tollFee);
        result.put("message", "통행료 " + tollFee + "원이 결제되었습니다");
        return result;
    }
}
