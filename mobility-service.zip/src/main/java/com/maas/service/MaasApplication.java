package com.maas.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * K-MaaS (Korea Mobility as a Service) 통합 모빌리티 플랫폼
 *
 * 수도권 통합 교통 서비스를 제공하는 메인 애플리케이션
 * - KTX 예약
 * - 지하철 실시간 도착 정보
 * - 버스 실시간 위치
 * - 공유 모빌리티 (따릉이, 킥보드)
 * - 정책 관리 및 데이터 분석
 * - 상권 연계 서비스
 */
@SpringBootApplication(scanBasePackages = "com.maas")
@EnableJpaRepositories(basePackages = "com.maas.repository")
@EntityScan(basePackages = "com.maas.domain")
public class MaasApplication {

    public static void main(String[] args) {
        SpringApplication.run(MaasApplication.class, args);
    }
}
