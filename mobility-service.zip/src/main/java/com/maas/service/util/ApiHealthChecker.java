package com.maas.service.util;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ApiHealthChecker implements CommandLineRunner {

    @Override
    public void run(String... args) {
        log.info("");
        log.info("╔═══════════════════════════════════════════════════════╗");
        log.info("║                                                       ║");
        log.info("║   🚀 K-MaaS Platform Started Successfully           ║");
        log.info("║                                                       ║");
        log.info("╚═══════════════════════════════════════════════════════╝");
        log.info("");
        log.info("║   ✅ Phase 10 Features Ready                         ║");
        log.info("║   🌐 Server: http://localhost:9999                   ║");
        log.info("║   📊 API Endpoints: /api/*                           ║");
        log.info("╚═══════════════════════════════════════════════════════╝");
        log.info("");
    }
}
