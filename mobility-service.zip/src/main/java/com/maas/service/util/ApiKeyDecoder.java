package com.maas.service.util;

import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;

/**
 * API 키 디코딩 유틸리티
 * HEX 인코딩된 API 키를 디코딩하여 실제 사용 가능한 키로 변환
 */
@Slf4j
@Component
public class ApiKeyDecoder {

    /**
     * HEX 문자열을 디코딩
     * @param hexString HEX 인코딩된 문자열
     * @return 디코딩된 문자열
     */
    public String decodeHex(String hexString) {
        if (hexString == null || hexString.isEmpty()) {
            log.warn("Empty or null hex string provided");
            return hexString;
        }

        // HEX 패턴인지 확인 (모든 문자가 0-9, a-f, A-F)
        if (!hexString.matches("^[0-9a-fA-F]+$")) {
            log.debug("String is not HEX encoded, returning as-is: {}", maskKey(hexString));
            return hexString;
        }

        // HEX 길이가 홀수면 원본 반환
        if (hexString.length() % 2 != 0) {
            log.debug("HEX string has odd length, returning as-is: {}", maskKey(hexString));
            return hexString;
        }

        try {
            byte[] bytes = new byte[hexString.length() / 2];
            for (int i = 0; i < hexString.length(); i += 2) {
                bytes[i / 2] = (byte) Integer.parseInt(hexString.substring(i, i + 2), 16);
            }
            String decoded = new String(bytes, StandardCharsets.UTF_8);
            log.info("Successfully decoded HEX key: {} -> {}",
                    maskKey(hexString), maskKey(decoded));
            return decoded;
        } catch (Exception e) {
            log.error("Failed to decode HEX string, returning original: {}", maskKey(hexString), e);
            return hexString;
        }
    }

    /**
     * API 키가 HEX 인코딩되어 있는지 확인
     * @param key API 키
     * @return HEX 인코딩 여부
     */
    public boolean isHexEncoded(String key) {
        if (key == null || key.isEmpty()) {
            return false;
        }
        // HEX 패턴이고 길이가 짝수이며, 길이가 40자 이상인 경우 인코딩된 것으로 판단
        return key.matches("^[0-9a-fA-F]+$") && key.length() % 2 == 0 && key.length() >= 40;
    }

    /**
     * API 키를 마스킹하여 로그에 안전하게 출력
     * @param key API 키
     * @return 마스킹된 키 (앞 4자, 뒤 4자만 표시)
     */
    private String maskKey(String key) {
        if (key == null || key.length() <= 8) {
            return "***";
        }
        return key.substring(0, 4) + "..." + key.substring(key.length() - 4);
    }

    /**
     * 여러 키를 한번에 디코딩
     * @param keys 디코딩할 키 배열
     * @return 디코딩된 키 배열
     */
    public String[] decodeMultiple(String... keys) {
        String[] decoded = new String[keys.length];
        for (int i = 0; i < keys.length; i++) {
            decoded[i] = decodeHex(keys[i]);
        }
        return decoded;
    }

    /**
     * 키를 인코딩 (테스트용)
     * @param plainKey 평문 키
     * @return HEX 인코딩된 키
     */
    public String encodeToHex(String plainKey) {
        if (plainKey == null || plainKey.isEmpty()) {
            return plainKey;
        }

        byte[] bytes = plainKey.getBytes(StandardCharsets.UTF_8);
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            hexString.append(String.format("%02x", b));
        }
        return hexString.toString();
    }
}
