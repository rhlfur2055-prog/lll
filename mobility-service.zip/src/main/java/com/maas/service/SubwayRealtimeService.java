package com.maas.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SubwayRealtimeService {

    private static final Logger log = LoggerFactory.getLogger(SubwayRealtimeService.class);

    public List<Map<String, Object>> getRealtimeArrivals(String stationName) {
        log.info("Fetching real-time data for: {}", stationName);
        return generateMockArrivals(stationName);
    }

    private List<Map<String, Object>> generateMockArrivals(String stationName) {
        List<Map<String, Object>> arrivals = new ArrayList<>();
        String[] directions = {"상행", "하행"};
        String[] destinations = {"소요산", "인천", "계양", "국제업무지구"};

        for (int i = 0; i < 4; i++) {
            Map<String, Object> arrival = new HashMap<>();
            arrival.put("trainNo", "K" + (100 + i));
            arrival.put("direction", directions[i % 2]);
            arrival.put("arrivalTime", (i * 3 + 2) + "분 후");
            arrival.put("destination", destinations[i % destinations.length]);
            arrival.put("currentStation", "전역 도착");
            arrivals.add(arrival);
        }

        return arrivals;
    }
}
