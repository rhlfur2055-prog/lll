package com.maas.service.repository;

import com.maas.service.entity.KtxReservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * KTX 예매 정보 Repository
 */
@Repository
public interface KtxReservationRepository extends JpaRepository<KtxReservation, Long> {
    
    /**
     * 사용자 ID로 예매 내역 조회
     */
    List<KtxReservation> findByUserIdOrderByReservationDateDesc(Long userId);
    
    /**
     * 예매 확인 번호로 조회
     */
    Optional<KtxReservation> findByConfirmationNumber(String confirmationNumber);
    
    /**
     * 예매 상태별 조회
     */
    List<KtxReservation> findByReservationStatus(String reservationStatus);
}
