package com.maas.service.repository;

import com.maas.service.entity.MileageHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MileageHistoryRepository extends JpaRepository<MileageHistory, Long> {
    List<MileageHistory> findByUserIdOrderByCreatedAtDesc(Long userId);
}
