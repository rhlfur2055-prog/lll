package com.maas.service.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.maas.service.entity.TollRecord;

/**
 * 고속도로 통행 기록 리포지토리
 */
@Repository
public interface TollRecordRepository extends JpaRepository<TollRecord, Long> {

    /**
     * 사용자별 통행 기록 조회 (최신순)
     */
    List<TollRecord> findByUserIdOrderByCreatedAtDesc(Long userId);

    /**
     * 사용자의 미결제 통행 기록 조회
     */
    @Query("SELECT t FROM TollRecord t WHERE t.userId = :userId AND t.exitTime IS NULL")
    Optional<TollRecord> findActiveRecordByUserId(Long userId);

    /**
     * 차량번호로 통행 기록 조회
     */
    List<TollRecord> findByVehicleNumberOrderByCreatedAtDesc(String vehicleNumber);

    /**
     * 날짜 범위로 통행 기록 조회
     */
    List<TollRecord> findByCreatedAtBetween(LocalDateTime start, LocalDateTime end);

    /**
     * 특정 노선의 통행 기록 조회
     */
    List<TollRecord> findByRouteNameOrderByCreatedAtDesc(String routeName);

    /**
     * 사용자의 월별 통행료 합계
     */
    @Query("SELECT SUM(t.finalFee) FROM TollRecord t WHERE t.userId = :userId AND YEAR(t.createdAt) = :year AND MONTH(t.createdAt) = :month")
    Integer sumMonthlyFeeByUserId(Long userId, int year, int month);
}
