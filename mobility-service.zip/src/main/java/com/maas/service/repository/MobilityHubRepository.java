/*
package com.maas.service.repository;

// NEUTRALIZED LEGACY REPOSITORY
// import com.maas.service.entity.MobilityHub;
// import org.springframework.data.jpa.repository.JpaRepository;
// @Repository
public interface MobilityHubRepository {}
*/
