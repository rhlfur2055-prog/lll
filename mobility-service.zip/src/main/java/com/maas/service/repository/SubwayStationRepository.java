/*
package com.maas.service.repository;

// NEUTRALIZED LEGACY REPOSITORY
// import com.maas.service.entity.SubwayStation;
// import org.springframework.data.jpa.repository.JpaRepository;
// @Repository
public interface SubwayStationRepository {}
*/
