package com.maas.service.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.maas.service.entity.Vehicle;

/**
 * 차량 정보 리포지토리
 */
@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {

    /**
     * 사용자의 차량 목록 조회
     */
    List<Vehicle> findByUserId(Long userId);

    /**
     * 사용자의 활성 차량 목록 조회
     */
    List<Vehicle> findByUserIdAndIsActiveTrue(Long userId);

    /**
     * 번호판으로 차량 조회
     */
    Optional<Vehicle> findByVehicleNumber(String vehicleNumber);

    /**
     * 전기차 목록 조회
     */
    List<Vehicle> findByIsElectricTrue();

    /**
     * 장애인 차량 목록 조회
     */
    List<Vehicle> findByIsDisabledTrue();

    /**
     * 친환경 차량 목록 조회
     */
    List<Vehicle> findByIsEcoFriendlyTrue();
}
