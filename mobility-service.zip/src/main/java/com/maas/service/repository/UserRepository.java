package com.maas.service.repository;

import com.maas.service.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    
    // 이메일로 찾기
    Optional<User> findByEmail(String email);
    
    // 이메일 중복 확인
    boolean existsByEmail(String email);

    // 평균 포인트 (대시보드용)
    @Query("SELECT AVG(u.points) FROM User u")
    Double findAveragePoints();
}