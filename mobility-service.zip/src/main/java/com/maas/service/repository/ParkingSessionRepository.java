package com.maas.service.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.maas.service.entity.ParkingSession;

/**
 * 주차 세션 리포지토리
 */
@Repository
public interface ParkingSessionRepository extends JpaRepository<ParkingSession, Long> {

    /**
     * 사용자의 활성 주차 세션 조회 (출차하지 않은 세션)
     */
    @Query("SELECT p FROM ParkingSession p WHERE p.userId = :userId AND p.exitTime IS NULL")
    Optional<ParkingSession> findActiveSessionByUserId(Long userId);

    /**
     * 사용자의 모든 주차 이력 조회
     */
    List<ParkingSession> findByUserIdOrderByEntryTimeDesc(Long userId);

    /**
     * QR 코드로 주차 세션 조회
     */
    Optional<ParkingSession> findByQrCode(String qrCode);

    /**
     * 차량번호로 활성 세션 조회
     */
    @Query("SELECT p FROM ParkingSession p WHERE p.carNumber = :carNumber AND p.exitTime IS NULL")
    Optional<ParkingSession> findActiveSessionByCarNumber(String carNumber);

    /**
     * 결제 대기 중인 세션 조회
     */
    List<ParkingSession> findByPaymentStatus(String paymentStatus);
}
