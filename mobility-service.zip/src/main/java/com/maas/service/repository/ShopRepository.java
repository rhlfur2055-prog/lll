package com.maas.service.repository;

import com.maas.service.entity.Shop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 제휴 상점 Repository
 */
@Repository
public interface ShopRepository extends JpaRepository<Shop, Long> {

    /**
     * 카테고리로 상점 목록 조회
     */
    List<Shop> findByCategory(String category);

    /**
     * 활성화된 상점 목록 조회
     */
    List<Shop> findByActiveTrue();

    /**
     * 영업 상태로 조회
     */
    List<Shop> findByStatus(String status);

    /**
     * 카테고리와 상태로 조회
     */
    List<Shop> findByCategoryAndStatus(String category, String status);

    /**
     * 상점명으로 검색
     */
    List<Shop> findByShopNameContaining(String shopName);

    /**
     * 특정 위치 근처의 상점 검색
     */
    @Query(value = "SELECT * FROM shop " +
            "WHERE active = true AND " +
            "(6371 * ACOS(COS(RADIANS(:lat)) * COS(RADIANS(latitude)) * " +
            "COS(RADIANS(longitude) - RADIANS(:lng)) + SIN(RADIANS(:lat)) * " +
            "SIN(RADIANS(latitude)))) < :radius " +
            "ORDER BY (6371 * ACOS(COS(RADIANS(:lat)) * COS(RADIANS(latitude)) * " +
            "COS(RADIANS(longitude) - RADIANS(:lng)) + SIN(RADIANS(:lat)) * " +
            "SIN(RADIANS(latitude))))",
            nativeQuery = true)
    List<Shop> findNearbyShops(@Param("lat") Double latitude,
                               @Param("lng") Double longitude,
                               @Param("radius") Double radiusKm);

    /**
     * 평점 순으로 상점 조회
     */
    List<Shop> findByActiveTrueOrderByRatingDesc();

    /**
     * 이용 횟수 순으로 상점 조회
     */
    List<Shop> findByActiveTrueOrderByVisitCountDesc();

    /**
     * 총 상점 수 조회
     */
    Long countByActiveTrue();

    /**
     * 영업중인 상점 수 조회
     */
    Long countByStatusAndActiveTrue(String status);

    /**
     * 총 이용 횟수 합계
     */
    @Query("SELECT SUM(s.visitCount) FROM Shop s WHERE s.active = true")
    Long sumTotalVisitCount();

    /**
     * 평균 할인율
     */
    @Query("SELECT AVG(s.discountRate) FROM Shop s WHERE s.active = true")
    Double averageDiscountRate();
}
