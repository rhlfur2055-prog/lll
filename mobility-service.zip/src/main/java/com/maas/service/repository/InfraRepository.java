package com.maas.service.repository;

import com.maas.service.entity.InfraHub;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InfraRepository extends JpaRepository<InfraHub, Long> {
    List<InfraHub> findByCategory(String category);
}
