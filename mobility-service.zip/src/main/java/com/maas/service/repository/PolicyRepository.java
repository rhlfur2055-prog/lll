package com.maas.service.repository;

import com.maas.service.entity.Policy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * 정책 정보 Repository
 */
@Repository
public interface PolicyRepository extends JpaRepository<Policy, Long> {

    /**
     * 정책 타입으로 조회
     */
    List<Policy> findByPolicyType(String policyType);

    /**
     * 활성화된 정책 목록 조회
     */
    List<Policy> findByEnabledTrue();

    /**
     * 정책 타입과 활성화 상태로 조회
     */
    Optional<Policy> findByPolicyTypeAndEnabledTrue(String policyType);

    /**
     * 정책명으로 조회
     */
    Optional<Policy> findByPolicyName(String policyName);
}
