package com.maas.service.repository;

import com.maas.service.entity.BikeStation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BikeStationRepository extends JpaRepository<BikeStation, String> {

    List<BikeStation> findByDistrict(String district);

    List<BikeStation> findByStationNameContaining(String keyword);

    @Query("SELECT b FROM BikeStation b WHERE " +
           "(6371 * acos(cos(radians(:lat)) * cos(radians(b.latitude)) * " +
           "cos(radians(b.longitude) - radians(:lon)) + " +
           "sin(radians(:lat)) * sin(radians(b.latitude)))) < :radius " +
           "ORDER BY (6371 * acos(cos(radians(:lat)) * cos(radians(b.latitude)) * " +
           "cos(radians(b.longitude) - radians(:lon)) + " +
           "sin(radians(:lat)) * sin(radians(b.latitude))))")
    List<BikeStation> findNearbyStations(
        @Param("lat") Double latitude,
        @Param("lon") Double longitude,
        @Param("radius") Double radiusKm
    );

    List<BikeStation> findByAvailableBikesGreaterThan(Integer count);
}
