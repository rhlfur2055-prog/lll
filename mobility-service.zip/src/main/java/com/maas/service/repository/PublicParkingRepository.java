package com.maas.service.repository;

import com.maas.service.entity.PublicParking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PublicParkingRepository extends JpaRepository<PublicParking, Long> {

    Optional<PublicParking> findByParkingCode(String parkingCode);

    List<PublicParking> findByParkingNameContaining(String keyword);

    List<PublicParking> findByRegion(String region);

    List<PublicParking> findByDistrict(String district);

    List<PublicParking> findByRegionAndDistrict(String region, String district);

    @Query(value = "SELECT * FROM PUBLIC_PARKING " +
           "WHERE (6371 * acos(cos(radians(:latitude)) * cos(radians(LATITUDE)) * " +
           "cos(radians(LONGITUDE) - radians(:longitude)) + sin(radians(:latitude)) * " +
           "sin(radians(LATITUDE)))) <= :radiusKm " +
           "ORDER BY (6371 * acos(cos(radians(:latitude)) * cos(radians(LATITUDE)) * " +
           "cos(radians(LONGITUDE) - radians(:longitude)) + sin(radians(:latitude)) * " +
           "sin(radians(LATITUDE))))",
           nativeQuery = true)
    List<PublicParking> findNearbyParking(
        @Param("latitude") Double latitude,
        @Param("longitude") Double longitude,
        @Param("radiusKm") Double radiusKm
    );

    List<PublicParking> findByAvailableSpacesGreaterThan(Integer minSpaces);
}
