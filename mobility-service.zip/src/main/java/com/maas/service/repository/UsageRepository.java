package com.maas.service.repository;

import com.maas.service.entity.UsageRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsageRepository extends JpaRepository<UsageRecord, Long> {
    
    // Count records where policy was applied ('1')
    long countByPolicyApplied(String applied);
    
    // Recent activities
    List<UsageRecord> findTop5ByOrderByUsageTimeDesc();

    // Check usage today (optional for "Active Now" simulation)
    @Query(value = "SELECT COUNT(*) FROM USAGE_RECORDS WHERE USAGE_TIME > TRUNC(SYSDATE)", nativeQuery = true)
    long countTodayUsage();
}
