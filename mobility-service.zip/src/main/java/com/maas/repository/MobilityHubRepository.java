package com.maas.repository;

import com.maas.domain.MobilityHub;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MobilityHubRepository extends JpaRepository<MobilityHub, Long> {

    List<MobilityHub> findByCategoryOrderByLineNameAscStationNameAsc(String category);

    List<MobilityHub> findByStationNameContainingOrderByLineName(String stationName);

    List<MobilityHub> findByLineNameOrderByStationNameAsc(String lineName);

    @Query("SELECT DISTINCT m.lineName FROM MobilityHub m WHERE m.category = 'SUBWAY' ORDER BY m.lineName")
    List<String> findDistinctSubwayLines();

    @Query("SELECT m.lineName, COUNT(m) FROM MobilityHub m WHERE m.category = 'SUBWAY' GROUP BY m.lineName ORDER BY m.lineName")
    List<Object[]> countStationsByLine();
}
