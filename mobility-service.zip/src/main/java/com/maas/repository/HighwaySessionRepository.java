package com.maas.repository;

import com.maas.domain.HighwaySession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface HighwaySessionRepository extends JpaRepository<HighwaySession, Long> {
    Optional<HighwaySession> findByUserIdAndExitTimeIsNull(Long userId);
}
