package com.maas.controller;

import com.maas.domain.MobilityHub;
import com.maas.service.IntegratedService;
import com.maas.service.SubwayRealtimeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
public class LegacyController {

    private static final Logger log = LoggerFactory.getLogger(LegacyController.class);

    private final IntegratedService integratedService;
    private final SubwayRealtimeService subwayRealtimeService;

    public LegacyController(IntegratedService integratedService, SubwayRealtimeService subwayRealtimeService) {
        this.integratedService = integratedService;
        this.subwayRealtimeService = subwayRealtimeService;
    }

    @GetMapping("/subway/arrival")
    public ResponseEntity<Map<String, Object>> getSubwayArrival(
            @RequestParam String line,
            @RequestParam String station) {
        try {
            List<Map<String, Object>> arrivals = subwayRealtimeService.getRealtimeArrivals(station);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "station", station,
                "line", line,
                "arrivals", arrivals
            ));
        } catch (Exception e) {
            log.error("Error in legacy subway arrival", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/bus/api/stops")
    public ResponseEntity<List<Map<String, Object>>> getBusStops(
            @RequestParam double lat,
            @RequestParam double lng,
            @RequestParam double radius) {
        try {
            return ResponseEntity.ok(integratedService.getBusStops(lat, lng, radius));
        } catch (Exception e) {
            log.error("Error in bus stops", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/ktx/search")
    public ResponseEntity<Map<String, Object>> searchKtx(
            @RequestParam String departure,
            @RequestParam String arrival,
            @RequestParam String date,
            @RequestParam(required = false, defaultValue = "1") int passengers) {
        try {
            List<Map<String, Object>> results = integratedService.searchKtx(departure, arrival, date);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "schedules", results,
                "count", results.size()
            ));
        } catch (Exception e) {
            log.error("Error in KTX search", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/bike/stations")
    public ResponseEntity<List<MobilityHub>> getBikeStations(
            @RequestParam double lat,
            @RequestParam double lng,
            @RequestParam double radius) {
        try {
            return ResponseEntity.ok(integratedService.getBikeStations()); // Ignoring radius for mock
        } catch (Exception e) {
            log.error("Error in bike stations", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/shops/api/list")
    public ResponseEntity<List<Map<String, Object>>> getShopList(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String status) {
        try {
            return ResponseEntity.ok(integratedService.getShopList(category));
        } catch (Exception e) {
            log.error("Error in shop list", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/analytics/api/stats")
    public ResponseEntity<Map<String, Object>> getAnalyticsStats(
            @RequestParam(required = false) Integer days,
            @RequestParam(required = false) String region,
            @RequestParam(required = false) String policy) {
        try {
            return ResponseEntity.ok(integratedService.getAnalyticsStats());
        } catch (Exception e) {
            log.error("Error in analytics stats", e);
            return ResponseEntity.internalServerError().build();
        }
    }
}
