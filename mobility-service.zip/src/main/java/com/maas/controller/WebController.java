package com.maas.controller;

import com.maas.service.IntegratedService;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WebController {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(WebController.class);
    private final IntegratedService integratedService;

    public WebController(IntegratedService integratedService) {
        this.integratedService = integratedService;
    }

    @GetMapping("/")
    public String root() {
        return "redirect:/mobile/index";
    }

    @GetMapping("/mobile/index")
    public String mobileIndex() {
        return "mobile/index";
    }

    // Alias for user request
    @GetMapping("/mobile/home")
    public String mobileHome() {
        return "mobile/home";
    }

    @GetMapping("/mobile/map")
    public String mobileMap() {
        return "mobile/map";
    }

    @GetMapping("/web/dashboard")
    public String webDashboard() {
        return "web/dashboard";
    }
    
    // Alias for user request to match existing API
    @GetMapping("/api/mobility/search")
    public String mobilitySearch(@RequestParam String keyword) {
        return "forward:/api/search";
    }

    // API Test page
    @GetMapping("/api-test")
    public String apiTest() {
        return "api-test";
    }
}
