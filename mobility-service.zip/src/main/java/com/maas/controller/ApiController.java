package com.maas.controller;

import com.maas.domain.MobilityHub;
import com.maas.domain.MileageHistory;
import com.maas.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ApiController {

    private static final Logger log = LoggerFactory.getLogger(ApiController.class);

    private final IntegratedService integratedService;
    private final SubwayRealtimeService realtimeService;
    private final KPassService kPassService;
    private final ParkingQrService parkingQrService;
    private final HighwayService highwayService;

    public ApiController(IntegratedService integratedService,
                         SubwayRealtimeService realtimeService,
                         KPassService kPassService,
                         ParkingQrService parkingQrService,
                         HighwayService highwayService) {
        this.integratedService = integratedService;
        this.realtimeService = realtimeService;
        this.kPassService = kPassService;
        this.parkingQrService = parkingQrService;
        this.highwayService = highwayService;
    }

    @GetMapping("/stations")
    public ResponseEntity<List<MobilityHub>> getStations(
            @RequestParam(required = false) String category) {

        try {
            List<MobilityHub> stations = category != null && !category.isEmpty() ?
                integratedService.getStationsByCategory(category) :
                integratedService.getAllStations();

            return ResponseEntity.ok(stations);
        } catch (Exception e) {
            log.error("Error getting stations", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/stations/by-line")
    public ResponseEntity<List<MobilityHub>> getStationsByLine(@RequestParam String line) {
        try {
            List<MobilityHub> stations = integratedService.getStationsByLine(line);
            return ResponseEntity.ok(stations);
        } catch (Exception e) {
            log.error("Error getting stations by line", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/lines")
    public ResponseEntity<Map<String, Object>> getSubwayLines() {
        try {
            List<String> lines = integratedService.getSubwayLines();
            Map<String, Integer> counts = integratedService.getLineStationCounts();

            List<Map<String, Object>> result = lines.stream()
                .map(line -> {
                    Map<String, Object> info = new HashMap<>();
                    info.put("lineName", line);
                    info.put("stationCount", counts.getOrDefault(line, 0));
                    info.put("color", integratedService.getLineColor(line));
                    return info;
                })
                .toList();

            return ResponseEntity.ok(Map.of("lines", result));
        } catch (Exception e) {
            log.error("Error getting lines", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/stations/{stationName}/realtime")
    public ResponseEntity<Map<String, Object>> getStationRealtime(@PathVariable String stationName) {
        try {
            List<MobilityHub> stations = integratedService.searchStations(stationName);

            if (stations.isEmpty()) {
                return ResponseEntity.ok(Map.of("error", "Station not found"));
            }

            MobilityHub station = stations.get(0);
            List<Map<String, Object>> arrivals = realtimeService.getRealtimeArrivals(stationName);

            Map<String, Object> result = new HashMap<>();
            result.put("station", station);
            result.put("arrivals", arrivals);

            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error getting realtime data", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/kpass/earn")
    public ResponseEntity<Map<String, Object>> earnMileage(
            @RequestParam Long userId,
            @RequestParam String serviceType,
            @RequestParam Double distanceKm) {

        try {
            Map<String, Object> result = kPassService.earnMileage(userId, serviceType, distanceKm);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error earning mileage", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/kpass/use")
    public ResponseEntity<Map<String, Object>> useMileage(
            @RequestParam Long userId,
            @RequestParam Integer points) {

        try {
            Map<String, Object> result = kPassService.useMileage(userId, points);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error using mileage", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/kpass/{userId}/history")
    public ResponseEntity<List<MileageHistory>> getMileageHistory(@PathVariable Long userId) {
        try {
            List<MileageHistory> history = kPassService.getMileageHistory(userId);
            return ResponseEntity.ok(history);
        } catch (Exception e) {
            log.error("Error getting history", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/parking/qr/entry")
    public ResponseEntity<Map<String, Object>> generateParkingQr(
            @RequestParam Long userId,
            @RequestParam Long parkingLotId,
            @RequestParam String carNumber) {

        try {
            Map<String, Object> result = parkingQrService.generateEntryQr(userId, parkingLotId, carNumber);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error generating QR", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/parking/qr/exit")
    public ResponseEntity<Map<String, Object>> scanParkingQr(@RequestParam String qrCode) {
        try {
            Map<String, Object> result = parkingQrService.scanExitQr(qrCode);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error scanning QR", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/highway/enter")
    public ResponseEntity<Map<String, Object>> enterHighway(
            @RequestParam Long userId,
            @RequestParam String tollgate) {

        try {
            Map<String, Object> result = highwayService.enterHighway(userId, tollgate);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error entering highway", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/highway/exit")
    public ResponseEntity<Map<String, Object>> exitHighway(
            @RequestParam Long userId,
            @RequestParam String tollgate) {

        try {
            Map<String, Object> result = highwayService.exitHighway(userId, tollgate);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("Error exiting highway", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> search(@RequestParam String keyword) {
        try {
            List<MobilityHub> results = integratedService.searchStations(keyword);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("stations", results);
            response.put("count", results.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error searching", e);
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "검색 중 오류가 발생했습니다");
            return ResponseEntity.status(500).body(error);
        }
    }

    @GetMapping("/health/dashboard")
    public ResponseEntity<Map<String, Object>> healthDashboard() {
        try {
            Map<String, Object> dashboard = new HashMap<>();

            // 서비스 상태
            Map<String, Object> services = new HashMap<>();
            services.put("subway", Map.of("status", "UP", "message", "지하철 서비스 정상"));
            services.put("bus", Map.of("status", "UP", "message", "버스 서비스 정상"));
            services.put("bike", Map.of("status", "UP", "message", "따릉이 서비스 정상"));
            services.put("parking", Map.of("status", "UP", "message", "주차 서비스 정상"));
            services.put("highway", Map.of("status", "UP", "message", "고속도로 서비스 정상"));

            // 통계 정보
            List<MobilityHub> allStations = integratedService.getAllStations();
            List<String> lines = integratedService.getSubwayLines();

            Map<String, Object> stats = new HashMap<>();
            stats.put("totalStations", allStations.size());
            stats.put("totalLines", lines.size());
            stats.put("activeUsers", 1234);
            stats.put("todayTrips", 5678);

            dashboard.put("status", "UP");
            dashboard.put("services", services);
            dashboard.put("stats", stats);
            dashboard.put("timestamp", System.currentTimeMillis());

            return ResponseEntity.ok(dashboard);
        } catch (Exception e) {
            log.error("Error getting health dashboard", e);
            return ResponseEntity.internalServerError().build();
        }
    }
}