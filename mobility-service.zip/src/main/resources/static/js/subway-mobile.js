// 지하철 모바일 페이지 JavaScript

let selectedLine = 'all';
let allStations = [];
let currentStation = null;

// DOM 로드 완료
document.addEventListener('DOMContentLoaded', function () {
    loadSubwayData();
    drawSubwayMap();
});

// 지하철 데이터 로드
function loadSubwayData() {
    const listContainer = document.getElementById('stationList');
    listContainer.innerHTML = '<div class="loading"><div class="spinner"></div><p>역 정보를 불러오는 중...</p></div>';

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    fetch('/subway/api/lines/all', { signal: controller.signal })
        .then(response => response.json())
        .then(data => {
            clearTimeout(timeoutId);
            if (data?.success && data?.lines) {
                allStations = [];
                data.lines.forEach(line => {
                    if (line?.stations) {
                        line.stations.forEach(station => {
                            allStations.push({
                                name: station?.stationName ?? '이름 없음',
                                line: line?.lineNumber ?? '',
                                lineColor: getLineColor(line?.lineNumber ?? '')
                            });
                        });
                    }
                });
                displayStations(allStations);
            } else {
                displayError();
            }
        })
        .catch(error => {
            clearTimeout(timeoutId);
            console.error('Error loading subway data:', error);
            displayError();
        });
}

// 노선 선택
function selectLine(line) {
    selectedLine = line;

    // 탭 활성화
    document.querySelectorAll('.line-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`[data-line="${line}"]`).classList.add('active');

    // 역 필터링
    if (line === 'all') {
        displayStations(allStations);
    } else {
        const filtered = allStations.filter(s => s.line === line);
        displayStations(filtered);
    }

    // 노선도 업데이트
    updateSubwayMap(line);
}

// 역 검색
function searchStation() {
    const query = document.getElementById('stationSearch')?.value?.toLowerCase()?.trim() ?? '';

    if (query === '') {
        selectLine(selectedLine);
        return;
    }

    const filtered = allStations.filter(s =>
        (s?.name ?? '').toLowerCase().includes(query)
    );

    displayStations(filtered);
}

// 역 목록 표시
function displayStations(stations) {
    const listContainer = document.getElementById('stationList');

    if (stations.length === 0) {
        listContainer.innerHTML = `
            <div class="empty-state">
                <p>검색 결과가 없습니다.</p>
            </div>
        `;
        return;
    }

    listContainer.innerHTML = stations.map(station => `
        <div class="station-item" onclick="showStationDetail('${station.name}', '${station.line}')">
            <div class="station-badge line-${station.line}">${station.line}</div>
            <div class="station-details">
                <div class="station-name">${station.name}</div>
                <div class="station-subtitle">${station.line}호선</div>
            </div>
        </div>
    `).join('');
}

// 에러 표시
function displayError() {
    const listContainer = document.getElementById('stationList');
    listContainer.innerHTML = `
        <div class="error-state">
            <p>데이터를 불러올 수 없습니다.</p>
            <button class="btn btn-primary" onclick="loadSubwayData()">다시 시도</button>
        </div>
    `;
}

// 역 상세 정보 표시
function showStationDetail(stationName, line) {
    currentStation = { name: stationName, line: line };

    // 모달 열기
    const modal = document.getElementById('stationModal');
    modal.classList.add('active');

    // 역 정보 표시
    document.getElementById('stationName').textContent = stationName;
    document.getElementById('stationLine').textContent = line + '호선';
    document.getElementById('stationAddress').textContent = '서울시';

    // 실시간 도착 정보 로드
    loadArrivalInfo(stationName);
}

// 역 상세 모달 닫기
function closeStationModal() {
    const modal = document.getElementById('stationModal');
    modal.classList.remove('active');
}

// 도착 정보 로드
function loadArrivalInfo(stationName) {
    const arrivalList = document.querySelector('.arrival-list');
    arrivalList.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    fetch(`/subway/api/arrival?stationName=${encodeURIComponent(stationName)}`, { signal: controller.signal })
        .then(response => response.json())
        .then(data => {
            clearTimeout(timeoutId);
            if (data?.success && data?.arrivals) {
                displayArrivalInfo(data.arrivals);
            } else {
                arrivalList.innerHTML = '<p>도착 정보가 없습니다.</p>';
            }
        })
        .catch(error => {
            clearTimeout(timeoutId);
            console.error('Error loading arrival info:', error);
            arrivalList.innerHTML = `
                <div class="error-msg">
                    <p>네트워크가 불안정합니다.</p>
                    <button class="retry-btn" onclick="loadArrivalInfo('${stationName}')">재시도</button>
                </div>
            `;
        });
}

// 도착 정보 표시
function displayArrivalInfo(arrivals) {
    const arrivalList = document.querySelector('.arrival-list');

    if (arrivals.length === 0) {
        arrivalList.innerHTML = '<p>운행 정보가 없습니다.</p>';
        return;
    }

    arrivalList.innerHTML = arrivals.map(arrival => `
        <div class="arrival-card">
            <div class="arrival-header">
                <span class="arrival-direction">${arrival?.direction ?? '정보 없음'} - ${arrival?.destination ?? ''}</span>
                <span class="arrival-time">${arrival?.arrivalTime ?? 0}분</span>
            </div>
            <div class="arrival-detail">
                ${arrival?.stationsBefore ?? 0}개 역 전 • ${arrival?.trainType ?? ''} • ${arrival?.congestion ?? ''}
            </div>
        </div>
    `).join('');
}

// 출발지 설정
function setDeparture() {
    if (currentStation) {
        localStorage.setItem('departure', JSON.stringify(currentStation));
        alert(`출발지: ${currentStation.name}역 설정 완료`);
        closeStationModal();
    }
}

// 도착지 설정
function setDestination() {
    if (currentStation) {
        localStorage.setItem('destination', JSON.stringify(currentStation));
        alert(`도착지: ${currentStation.name}역 설정 완료`);
        closeStationModal();

        // 경로 검색 페이지로 이동
        const departure = JSON.parse(localStorage.getItem('departure'));
        if (departure) {
            location.href = `/mobile/route?from=${departure.name}&to=${currentStation.name}`;
        }
    }
}

// 노선도 그리기
function drawSubwayMap() {
    const mapContainer = document.getElementById('subwayMap');

    const svg = `
        <svg viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
            <!-- 1호선 (수직) -->
            <line class="subway-line subway-line-1" x1="100" y1="50" x2="100" y2="550" />

            <!-- 2호선 (순환선) -->
            <circle class="subway-line subway-line-2" cx="300" cy="300" r="150" />

            <!-- 3호선 (대각선) -->
            <line class="subway-line subway-line-3" x1="500" y1="50" x2="200" y2="550" />

            <!-- 4호선 (수직) -->
            <line class="subway-line subway-line-4" x1="200" y1="50" x2="200" y2="550" />

            <!-- 5호선 (곡선) -->
            <path class="subway-line subway-line-5" d="M 100 400 Q 300 350 500 400" />

            <!-- 6호선 (곡선) -->
            <path class="subway-line subway-line-6" d="M 150 100 Q 200 200 250 300 T 350 500" />

            <!-- 7호선 (수평) -->
            <line class="subway-line subway-line-7" x1="50" y1="400" x2="550" y2="400" />

            <!-- 8호선 (대각선) -->
            <line class="subway-line subway-line-8" x1="350" y1="450" x2="500" y2="550" />

            <!-- 9호선 (수평) -->
            <line class="subway-line subway-line-9" x1="50" y1="500" x2="450" y2="500" />

            <!-- 주요 역 표시 -->
            <g class="station-dot line-2" onclick="showStationDetail('강남', '2')">
                <circle cx="400" cy="400" r="8" />
                <text class="station-label" x="410" y="405">강남</text>
            </g>

            <g class="station-dot line-2" onclick="showStationDetail('역삼', '2')">
                <circle cx="450" cy="350" r="8" />
                <text class="station-label" x="460" y="355">역삼</text>
            </g>

            <g class="station-dot line-1" onclick="showStationDetail('서울역', '1')">
                <circle cx="100" cy="300" r="8" />
                <text class="station-label" x="110" y="305">서울역</text>
            </g>

            <g class="station-dot line-2" onclick="showStationDetail('시청', '2')">
                <circle cx="200" cy="250" r="8" />
                <text class="station-label" x="210" y="255">시청</text>
            </g>

            <g class="station-dot line-7" onclick="showStationDetail('건대입구', '7')">
                <circle cx="450" cy="400" r="8" />
                <text class="station-label" x="460" y="405">건대입구</text>
            </g>

            <g class="station-dot line-9" onclick="showStationDetail('김포공항', '9')">
                <circle cx="150" cy="500" r="8" />
                <text class="station-label" x="160" y="505">김포공항</text>
            </g>
        </svg>
    `;

    mapContainer.innerHTML = svg;
}

// 노선도 업데이트
function updateSubwayMap(line) {
    const lines = document.querySelectorAll('.subway-line');
    const stations = document.querySelectorAll('.station-dot');

    if (line === 'all') {
        lines.forEach(l => l.style.opacity = '1');
        stations.forEach(s => s.style.opacity = '1');
    } else {
        lines.forEach(l => {
            l.style.opacity = l.classList.contains(`subway-line-${line}`) ? '1' : '0.2';
        });
        stations.forEach(s => {
            s.style.opacity = s.classList.contains(`line-${line}`) ? '1' : '0.2';
        });
    }
}

// 노선 색상 가져오기
function getLineColor(line) {
    const colors = {
        '1': '#0052A4',
        '2': '#00A84D',
        '3': '#EF7C1C',
        '4': '#00A5DE',
        '5': '#996CAC',
        '6': '#CD7C2F',
        '7': '#747F00',
        '8': '#E6186C',
        '9': '#BDB092'
    };
    return colors[line] || '#666';
}

// 메뉴 표시
function showSubwayMenu() {
    alert('지하철 메뉴 기능 준비중');
}
