// KTX 모바일 페이지 JavaScript

let currentMode = 'departure'; // departure or arrival
let selectedDeparture = '서울';
let selectedArrival = '부산';
let selectedDate = new Date();
let passengerCount = 1;

const stations = [
    '서울', '용산', '영등포', '광명', '수원', '천안아산', '오송',
    '대전', '김천구미', '동대구', '신경주', '울산', '부산',
    '익산', '정읍', '광주송정', '나주', '목포',
    '포항', '밀양', '마산', '진주'
];

// DOM 로드 완료
document.addEventListener('DOMContentLoaded', function () {
    initKtxPage();
});

// 페이지 초기화
function initKtxPage() {
    // 오늘 날짜 설정
    updateDateDisplay();

    // 역 목록 로드
    loadStationList();
}

// 날짜 표시 업데이트
function updateDateDisplay() {
    const dateStr = formatDate(selectedDate);
    document.getElementById('selectedDate').textContent = dateStr;
}

// 역 선택
function selectStation(mode) {
    currentMode = mode;

    const modal = document.getElementById('stationModal');
    const title = document.getElementById('stationModalTitle');

    if (mode === 'departure') {
        title.textContent = '출발역 선택';
    } else {
        title.textContent = '도착역 선택';
    }

    modal.classList.add('active');
}

// 역 선택 모달 닫기
function closeStationModal() {
    const modal = document.getElementById('stationModal');
    modal.classList.remove('active');
}

// 역 목록 로드
function loadStationList() {
    const grid = document.getElementById('stationGrid');

    grid.innerHTML = stations.map(station => `
        <div class="station-option" onclick="chooseStation('${station}')">
            ${station}
        </div>
    `).join('');
}

// 역 선택 완료
function chooseStation(station) {
    if (currentMode === 'departure') {
        selectedDeparture = station;
        document.getElementById('departureStation').textContent = station;
    } else {
        selectedArrival = station;
        document.getElementById('arrivalStation').textContent = station;
    }

    closeStationModal();
}

// 역 검색 필터
function filterStations() {
    const query = document.getElementById('stationSearchInput').value.toLowerCase();
    const filtered = stations.filter(s => s.toLowerCase().includes(query));

    const grid = document.getElementById('stationGrid');
    grid.innerHTML = filtered.map(station => `
        <div class="station-option" onclick="chooseStation('${station}')">
            ${station}
        </div>
    `).join('');
}

// 출발/도착 역 교체
function swapStations() {
    const temp = selectedDeparture;
    selectedDeparture = selectedArrival;
    selectedArrival = temp;

    document.getElementById('departureStation').textContent = selectedDeparture;
    document.getElementById('arrivalStation').textContent = selectedArrival;
}

// 날짜 선택
function selectDate() {
    const input = document.createElement('input');
    input.type = 'date';
    input.min = formatDateInput(new Date());
    input.value = formatDateInput(selectedDate);

    input.onchange = function () {
        selectedDate = new Date(this.value);
        updateDateDisplay();
    };

    input.click();
}

// 인원 변경
function changePassenger(delta) {
    passengerCount += delta;

    if (passengerCount < 1) passengerCount = 1;
    if (passengerCount > 9) passengerCount = 9;

    document.getElementById('passengerCount').textContent = passengerCount;
}

// 열차 검색
function searchTrains() {
    const listContainer = document.getElementById('trainList');
    const loading = listContainer.querySelector('.loading');

    if (loading) {
        loading.innerHTML = '<div class="spinner"></div><p>열차 검색 중...</p>';
    }

    const dateStr = formatDateInput(selectedDate);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    fetch(`/api/ktx/search?depStation=${encodeURIComponent(selectedDeparture)}&arrStation=${encodeURIComponent(selectedArrival)}&date=${dateStr}&passengers=${passengerCount}`, { signal: controller.signal })
        .then(response => response.json())
        .then(data => {
            clearTimeout(timeoutId);
            if (data?.success && data?.trains) {
                displayTrains(data.trains);
            } else {
                displayError();
            }
        })
        .catch(error => {
            clearTimeout(timeoutId);
            console.error('Error searching trains:', error);
            displayError('네트워크가 불안정하거나 검색 결과가 없습니다.');
        });
}

// 열차 목록 표시
function displayTrains(trains) {
    const listContainer = document.getElementById('trainList');
    const resultCount = document.getElementById('resultCount');

    resultCount.textContent = trains.length + '개';

    if (trains.length === 0) {
        listContainer.innerHTML = `
            <div class="list-header">
                <h2>열차 목록</h2>
                <span class="result-count">0개</span>
            </div>
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12,2C8,2 4.86,4.03 3.5,7H2V9H3.5C3.18,9.94 3,10.95 3,12H2V14H3C3,16.21 3.91,18.2 5.33,19.67V22H7V20.6C8.53,21.47 10.21,22 12,22C13.79,22 15.47,21.47 17,20.6V22H19V19.67C20.09,18.2 21,16.21 21,14H22V12H21C21,10.95 20.82,9.94 20.5,9H22V7H20.5C19.14,4.03 16,2 12,2M12,4C14.92,4 17.34,5.82 18.21,8.36L18.21,8.37C18.39,8.86 18.53,9.38 18.64,9.91C18.75,10.43 18.82,10.97 18.86,11.5C18.89,11.83 18.91,12.16 18.91,12.5H5.09C5.09,12.16 5.11,11.83 5.14,11.5C5.18,10.97 5.25,10.43 5.36,9.91C5.47,9.38 5.61,8.86 5.79,8.37L5.79,8.36C6.66,5.82 9.08,4 12,4Z"/>
                </svg>
                <p>검색 결과가 없습니다</p>
            </div>
        `;
        return;
    }

    const trainsHtml = trains.map(train => {
        const seatsClass = (train?.availableSeats ?? 0) < 10 ? 'low' : '';

        return `
            <div class="train-card" onclick="selectTrain('${train?.trainNo ?? ''}', '${train?.departureTime ?? ''}', '${train?.arrivalTime ?? ''}', '${train?.price ?? 0}')">
                <div class="train-header">
                    <span class="train-number">${train?.trainNo ?? ''}</span>
                    <span class="train-type">KTX</span>
                </div>
                <div class="train-route">
                    <div class="route-station">
                        <div class="route-time">${train?.departureTime ?? ''}</div>
                        <div class="route-name">${selectedDeparture}</div>
                    </div>
                    <div class="route-icon">
                        <div class="route-duration">${train?.duration ?? ''}</div>
                        <svg viewBox="0 0 24 24" fill="currentColor" style="width: 24px; height: 24px;">
                            <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z"/>
                        </svg>
                    </div>
                    <div class="route-station">
                        <div class="route-time">${train?.arrivalTime ?? ''}</div>
                        <div class="route-name">${selectedArrival}</div>
                    </div>
                </div>
                <div class="train-footer">
                    <div class="train-price">${(train?.price ?? 0).toLocaleString()}원</div>
                    <div class="train-seats ${seatsClass}">
                        ${(train?.availableSeats ?? 0) < 10 ? '잔여석 ' + (train?.availableSeats ?? 0) + '석' : '예약 가능'}
                    </div>
                </div>
            </div>
        `;
    }).join('');

    listContainer.innerHTML = `
        <div class="list-header">
            <h2>열차 목록</h2>
            <span class="result-count">${trains.length}개</span>
        </div>
        ${trainsHtml}
    `;
}

// 에러 표시
function displayError(message = '열차 정보를 불러올 수 없습니다') {
    const listContainer = document.getElementById('trainList');
    listContainer.innerHTML = `
        <div class="list-header">
            <h2>열차 목록</h2>
            <span class="result-count">0개</span>
        </div>
        <div class="empty-state">
            <p>${message}</p>
            <button class="btn btn-primary" onclick="searchTrains()">다시 시도</button>
        </div>
    `;
}

// 열차 선택
function selectTrain(trainNo, depTime, arrTime, price) {
    const confirmed = confirm(`${trainNo} 열차를 예약하시겠습니까?\n\n출발: ${selectedDeparture} ${depTime}\n도착: ${selectedArrival} ${arrTime}\n요금: ${price}원`);

    if (confirmed) {
        reserveTrain(trainNo, depTime, arrTime, price);
    }
}

// 열차 예약
function reserveTrain(trainNo, depTime, arrTime, price) {
    if (window.isReserving) return;
    window.isReserving = true;

    // 예약 버튼 시각적 피드백 (비활성화 효과)
    const reserveBtns = document.querySelectorAll('.train-card');
    reserveBtns.forEach(btn => btn.style.opacity = '0.5');

    const data = {
        trainNo: trainNo,
        depStation: selectedDeparture,
        arrStation: selectedArrival,
        depTime: depTime,
        date: formatDateInput(selectedDate),
        fare: String(price)
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 예약은 조금 더 여유있게 5초

    fetch('/api/ktx/reserve', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data),
        signal: controller.signal
    })
        .then(response => response.json())
        .then(result => {
            window.isReserving = false;
            clearTimeout(timeoutId);
            reserveBtns.forEach(btn => btn.style.opacity = '1');

            if (result?.success && result?.reservation) {
                showReservationSuccess(result);
            } else {
                alert(result?.message ?? '예약 실패');
            }
        })
        .catch(error => {
            window.isReserving = false;
            clearTimeout(timeoutId);
            reserveBtns.forEach(btn => btn.style.opacity = '1');
            console.error('Reservation error:', error);
            alert('네트워크가 불안정하거나 예약 처리 중 오류가 발생했습니다.');
        });
}

// 예약 완료 표시
function showReservationSuccess(result) {
    const listContainer = document.getElementById('trainList');

    listContainer.innerHTML = `
        <div class="reservation-success">
            <div class="success-icon">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9,20.42L2.79,14.21L5.62,11.38L9,14.77L18.88,4.88L21.71,7.71L9,20.42Z"/>
                </svg>
            </div>
            <div class="success-title">예약 완료</div>
            <div class="success-message">KTX 예약이 완료되었습니다</div>

            <div class="reservation-info">
                <div class="info-row">
                    <span class="info-label">예약번호</span>
                    <span class="info-value">${result.reservation.confirmationNumber}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">열차</span>
                    <span class="info-value">${result.reservation.trainNo}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">출발</span>
                    <span class="info-value">${result.reservation.depStation} ${formatTime(result.reservation.depDate)}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">도착</span>
                    <span class="info-value">${result.reservation.arrStation} ${formatTime(result.reservation.arrDate)}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">요금</span>
                    <span class="info-value">${result.reservation.finalFare.toLocaleString()}원</span>
                </div>
            </div>

            <button class="btn btn-primary" onclick="location.href='/mobile'">메인으로</button>
        </div>
    `;
}

// 날짜 포맷팅
function formatDate(date) {
    const days = ['일', '월', '화', '수', '목', '금', '토'];
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const dayName = days[date.getDay()];

    return `${month}월 ${day}일 (${dayName})`;
}

function formatDateInput(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}

function formatTime(dateTimeStr) {
    if (!dateTimeStr) return "";
    const date = new Date(dateTimeStr);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
}
