/**
 * 따릉이 모바일 JS
 * 2026-01-14 Updated: SDK Load Check & Robust Error Handling
 */

let map = null;
let markers = [];
let clusterer = null;
let allStations = [];

document.addEventListener('DOMContentLoaded', () => {
    initKakaoMap();
});

function initKakaoMap() {
    if (typeof kakao === 'undefined' || !kakao.maps) {
        console.error('Kakao Maps SDK not loaded.');
        alert('지도 로드 실패. API 키를 확인하세요.');
        useDummyDataWithoutMap(); // 지도 없이 리스트라도 보여주기 (옵션)
        return;
    }

    // SDK 로드 완료 후 실행 보장
    kakao.maps.load(() => {
        const container = document.getElementById('map');
        const options = {
            center: new kakao.maps.LatLng(37.498095, 127.027610), // 강남역 (기본)
            level: 4
        };

        map = new kakao.maps.Map(container, options);

        // 클러스터러
        clusterer = new kakao.maps.MarkerClusterer({
            map: map,
            averageCenter: true,
            minLevel: 6
        });

        // 줌 컨트롤
        const zoomControl = new kakao.maps.ZoomControl();
        map.addControl(zoomControl, kakao.maps.ControlPosition.RIGHT);

        // 데이터 로드
        loadBikeStations();
    });
}

function loadBikeStations() {
    const loading = document.getElementById('loading');
    if (loading) loading.style.display = 'block';

    fetch('/api/bike/stations/all')
        .then(res => {
            if (!res.ok) throw new Error('Network response was not ok');
            return res.json();
        })
        .then(data => {
            if (!data || data.length === 0) {
                console.warn('No data from API, using dummy data.');
                useDummyData(); // fallback
            } else {
                allStations = data;
                displayMarkers(data);
            }
        })
        .catch(err => {
            console.error('API Error:', err);
            useDummyData(); // fallback on error
        })
        .finally(() => {
            if (loading) loading.style.display = 'none';
        });
}

function useDummyData() {
    // 강남역 주변 더미 데이터
    const dummy = [
        { stationName: '강남역 10번출구', latitude: 37.498095, longitude: 127.027610, parkingBikeTotCnt: 5 },
        { stationName: '강남역 11번출구', latitude: 37.498750, longitude: 127.026700, parkingBikeTotCnt: 12 },
        { stationName: '역삼역 4번출구', latitude: 37.500666, longitude: 127.036449, parkingBikeTotCnt: 0 },
        { stationName: '메리츠타워 앞', latitude: 37.497500, longitude: 127.028000, parkingBikeTotCnt: 8 }
    ];
    allStations = dummy;
    displayMarkers(dummy);

    // 강남역으로 이동
    if (map) {
        const moveLatLon = new kakao.maps.LatLng(37.498095, 127.027610);
        map.setCenter(moveLatLon);
    }
}

function displayMarkers(stations) {
    if (!map) return;

    // 기존 마커 제거
    clusterer.clear();
    markers = [];

    stations.forEach(station => {
        const lat = station.latitude;
        const lng = station.longitude;
        if (!lat || !lng) return;

        const available = station.parkingBikeTotCnt || 0;

        // 이미지 마커 (초록: 여유, 빨강: 0, 노랑: 부족)
        let markerImageSrc = 'https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_red.png'; // 기본
        if (available > 5) markerImageSrc = 'https://maps.google.com/mapfiles/ms/icons/green-dot.png';
        else if (available > 0) markerImageSrc = 'https://maps.google.com/mapfiles/ms/icons/yellow-dot.png';
        else markerImageSrc = 'https://maps.google.com/mapfiles/ms/icons/red-dot.png';

        const imageSize = new kakao.maps.Size(24, 24);
        const markerImage = new kakao.maps.MarkerImage(markerImageSrc, imageSize);

        const marker = new kakao.maps.Marker({
            position: new kakao.maps.LatLng(lat, lng),
            image: markerImage,
            title: station.stationName
        });

        // 인포윈도우
        const iwContent = `
            <div style="padding:10px; min-width:150px;">
                <h4>${station.stationName}</h4>
                <p>대여가능: <strong>${available}</strong>대</p>
            </div>
        `;
        const infowindow = new kakao.maps.InfoWindow({
            content: iwContent,
            removable: true
        });

        kakao.maps.event.addListener(marker, 'click', function () {
            infowindow.open(map, marker);
        });

        markers.push(marker);
    });

    clusterer.addMarkers(markers);
}

function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            const locPosition = new kakao.maps.LatLng(lat, lon);

            if (map) {
                map.setCenter(locPosition);
                new kakao.maps.Marker({
                    map: map,
                    position: locPosition,
                    title: '내 위치'
                });
            }
        });
    } else {
        alert('내 위치를 찾을 수 없습니다.');
    }
}

function useDummyDataWithoutMap() {
    // 지도 로드 실패 시 콘솔이라도 찍기
    console.log("지도 로드 실패. 더미데이터:", [
        { stationName: '강남역 10번출구', latitude: 37.498095, longitude: 127.027610, parkingBikeTotCnt: 5 }
    ]);
}
