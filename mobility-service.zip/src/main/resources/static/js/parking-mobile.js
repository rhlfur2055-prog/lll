// 주차장 모바일 JavaScript

let map;
let markers = [];
let allParkingData = [];
let currentGradeFilter = 'all';
let activeSessionId = null;
let parkingDurationInterval = null;

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    initializeMap();
    loadParkingData();
    checkActiveSession();
});

// 카카오맵 초기화
function initializeMap() {
    try {
        const mapContainer = document.getElementById('map');
        const mapOption = {
            center: new kakao.maps.LatLng(37.5665, 126.9780), // 서울 시청
            level: 5
        };

        map = new kakao.maps.Map(mapContainer, mapOption);

        // 현재 위치 가져오기
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                const locPosition = new kakao.maps.LatLng(lat, lng);

                // 현재 위치 마커
                const marker = new kakao.maps.Marker({
                    map: map,
                    position: locPosition,
                    image: new kakao.maps.MarkerImage(
                        'https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_red.png',
                        new kakao.maps.Size(30, 35)
                    )
                });

                map.setCenter(locPosition);
                loadNearbyParking(lat, lng);
            }, function(error) {
                console.warn('위치 정보를 가져올 수 없습니다:', error);
                loadAllParking();
            });
        } else {
            loadAllParking();
        }
    } catch (error) {
        console.error('카카오맵 초기화 실패:', error);
    }
}

// 현재 위치로 이동
function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const locPosition = new kakao.maps.LatLng(lat, lng);

            map.setCenter(locPosition);
            loadNearbyParking(lat, lng);
        });
    }
}

// 주변 주차장 로드
async function loadNearbyParking(lat, lng) {
    try {
        const response = await fetch(`/api/parking/nearby?lat=${lat}&lng=${lng}&radius=5000`);
        const parkings = await response.json();

        allParkingData = parkings.map(p => ({
            ...p,
            parkingGrade: assignParkingGrade(p) // 급지 자동 할당
        }));

        displayParkingOnMap(allParkingData);
        renderParkingList(allParkingData);
    } catch (error) {
        console.error('주변 주차장 조회 실패:', error);
        loadAllParking();
    }
}

// 전체 주차장 로드
async function loadAllParking() {
    try {
        const response = await fetch('/api/parking/all');
        const parkings = await response.json();

        allParkingData = parkings.map(p => ({
            ...p,
            parkingGrade: assignParkingGrade(p)
        }));

        displayParkingOnMap(allParkingData);
        renderParkingList(allParkingData);
    } catch (error) {
        console.error('주차장 조회 실패:', error);
        document.getElementById('parkingList').innerHTML =
            '<p style="text-align: center; color: #999;">주차장 정보를 불러올 수 없습니다.</p>';
    }
}

// 주차장 급지 자동 할당 (지역 기반)
function assignParkingGrade(parking) {
    const name = parking.parkingName || '';
    const address = parking.address || '';

    // 1급지: 강남, 여의도, 을지로 등
    if (name.includes('강남') || name.includes('여의도') || name.includes('을지로') ||
        address.includes('강남구') || address.includes('여의도') || address.includes('중구')) {
        return 'GRADE_1';
    }

    // 2급지: 서울 일반 도심
    if (address.includes('서울') && !address.includes('구로') && !address.includes('금천')) {
        return 'GRADE_2';
    }

    // 3급지: 외곽
    return 'GRADE_3';
}

// 주차장 데이터 로드
async function loadParkingData() {
    // 현재 위치 기반으로 이미 로드됨
}

// 지도에 주차장 마커 표시
function displayParkingOnMap(parkings) {
    // 기존 마커 제거
    markers.forEach(marker => marker.setMap(null));
    markers = [];

    parkings.forEach(parking => {
        if (!parking.latitude || !parking.longitude) return;

        const position = new kakao.maps.LatLng(parking.latitude, parking.longitude);

        // 마커 생성
        const marker = new kakao.maps.Marker({
            map: map,
            position: position,
            title: parking.parkingName
        });

        // InfoWindow 생성
        const gradeLabel = getGradeLabel(parking.parkingGrade);
        const feeInfo = getFeeInfo(parking.parkingGrade);

        const content = `
            <div style="padding: 12px; min-width: 200px;">
                <strong style="font-size: 14px; color: #333;">${parking.parkingName}</strong><br>
                <span style="font-size: 12px; color: #667eea; font-weight: 600;">${gradeLabel}</span><br>
                <span style="font-size: 11px; color: #666;">${feeInfo}</span><br>
                <span style="font-size: 11px; color: ${parking.availableSpaces > 0 ? 'green' : 'red'};">
                    여유: ${parking.availableSpaces || 0}대
                </span>
            </div>
        `;

        const infowindow = new kakao.maps.InfoWindow({
            content: content
        });

        // 마커 클릭 이벤트
        kakao.maps.event.addListener(marker, 'click', function() {
            // 모든 InfoWindow 닫기
            markers.forEach(m => {
                if (m.infowindow) m.infowindow.close();
            });

            infowindow.open(map, marker);
        });

        marker.infowindow = infowindow;
        markers.push(marker);
    });
}

// 주차장 목록 렌더링
function renderParkingList(parkings) {
    const listContainer = document.getElementById('parkingList');
    document.getElementById('parkingCount').textContent = `${parkings.length}개`;

    if (parkings.length === 0) {
        listContainer.innerHTML = '<p style="text-align: center; color: #999;">주변에 주차장이 없습니다.</p>';
        return;
    }

    const html = `
        <div class="list-header">
            <h2>주변 주차장</h2>
            <span class="parking-count">${parkings.length}개</span>
        </div>
        ${parkings.map(parking => `
            <div class="parking-item" onclick="showEntryModal('${parking.parkingCode}', '${parking.parkingName}', '${parking.parkingGrade}')">
                <div class="parking-header">
                    <div>
                        <h3 class="parking-name">${parking.parkingName}</h3>
                        <p class="parking-address">${parking.address || '주소 정보 없음'}</p>
                    </div>
                    <span class="parking-grade ${parking.parkingGrade}">${getGradeLabel(parking.parkingGrade)}</span>
                </div>
                <div class="parking-details">
                    <div class="detail-item">
                        <svg class="detail-icon" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20M12.5,7V12.25L17,14.92L16.25,16.15L11,13V7H12.5Z"/>
                        </svg>
                        <span>24시간</span>
                    </div>
                    <div class="detail-item">
                        <svg class="detail-icon" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M18.92,6.01C18.72,5.42 18.16,5 17.5,5H6.5C5.84,5 5.29,5.42 5.08,6.01L3,12V20A1,1 0 0,0 4,21H5A1,1 0 0,0 6,20V19H18V20A1,1 0 0,0 19,21H20A1,1 0 0,0 21,20V12L18.92,6.01M6.85,7H17.14L18.22,10.11H5.77L6.85,7M19,17H5V12H19V17M7.5,13A1.5,1.5 0 0,1 9,14.5A1.5,1.5 0 0,1 7.5,16A1.5,1.5 0 0,1 6,14.5A1.5,1.5 0 0,1 7.5,13M16.5,13A1.5,1.5 0 0,1 18,14.5A1.5,1.5 0 0,1 16.5,16A1.5,1.5 0 0,1 15,14.5A1.5,1.5 0 0,1 16.5,13Z"/>
                        </svg>
                        <span>${parking.availableSpaces || 0}대</span>
                    </div>
                </div>
                <div class="parking-fee">
                    <strong>${getFeeInfo(parking.parkingGrade)}</strong>
                </div>
                <button class="btn-parking-entry" onclick="event.stopPropagation(); showEntryModal('${parking.parkingCode}', '${parking.parkingName}', '${parking.parkingGrade}')">
                    입차하기
                </button>
            </div>
        `).join('')}
    `;

    listContainer.innerHTML = html;
}

// 급지 라벨 반환
function getGradeLabel(grade) {
    const labels = {
        'GRADE_1': '1급지',
        'GRADE_2': '2급지',
        'GRADE_3': '3급지'
    };
    return labels[grade] || '3급지';
}

// 요금 정보 반환
function getFeeInfo(grade) {
    const fees = {
        'GRADE_1': '30분 2,000원 / 추가 10분 1,000원',
        'GRADE_2': '30분 1,500원 / 추가 10분 700원',
        'GRADE_3': '30분 1,000원 / 추가 10분 500원'
    };
    return fees[grade] || fees['GRADE_3'];
}

// 급지별 필터링
function filterByGrade(grade) {
    currentGradeFilter = grade;

    // 버튼 활성화 상태 변경
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === grade) {
            btn.classList.add('active');
        }
    });

    // 필터링된 데이터 표시
    const filtered = grade === 'all'
        ? allParkingData
        : allParkingData.filter(p => p.parkingGrade === grade);

    displayParkingOnMap(filtered);
    renderParkingList(filtered);
}

// 주차장 검색
function searchParking() {
    const keyword = document.getElementById('parkingSearch').value.toLowerCase();

    const filtered = allParkingData.filter(p => {
        const name = (p.parkingName || '').toLowerCase();
        const address = (p.address || '').toLowerCase();
        const matchesGrade = currentGradeFilter === 'all' || p.parkingGrade === currentGradeFilter;
        return matchesGrade && (name.includes(keyword) || address.includes(keyword));
    });

    displayParkingOnMap(filtered);
    renderParkingList(filtered);
}

// 활성 세션 확인
async function checkActiveSession() {
    if (!currentUserId) return;

    try {
        const response = await fetch(`/api/parking/status/${currentUserId}`);
        const data = await response.json();

        if (data.success && data.hasActiveSession) {
            activeSessionId = data.session.sessionId;
            displayActiveSession(data.session, data.parkedMinutes, data.currentFee);
            startParkingTimer(data.session.entryTime);
        }
    } catch (error) {
        console.error('활성 세션 조회 실패:', error);
    }
}

// 활성 세션 표시
function displayActiveSession(session, minutes, fee) {
    const card = document.getElementById('activeSessionCard');
    document.getElementById('activeCarNumber').textContent = session.carNumber;
    document.getElementById('activeParkingName').textContent = session.parkingLotName || '주차장';
    document.getElementById('activeEntryTime').textContent = formatDateTime(session.entryTime);
    document.getElementById('parkingDuration').textContent = formatDuration(minutes);
    document.getElementById('currentFee').textContent = fee.toLocaleString() + '원';

    card.style.display = 'block';
}

// 주차 시간 타이머 시작
function startParkingTimer(entryTime) {
    if (parkingDurationInterval) {
        clearInterval(parkingDurationInterval);
    }

    parkingDurationInterval = setInterval(async () => {
        try {
            const response = await fetch(`/api/parking/status/${currentUserId}`);
            const data = await response.json();

            if (data.success && data.hasActiveSession) {
                document.getElementById('parkingDuration').textContent = formatDuration(data.parkedMinutes);
                document.getElementById('currentFee').textContent = data.currentFee.toLocaleString() + '원';
            } else {
                clearInterval(parkingDurationInterval);
                document.getElementById('activeSessionCard').style.display = 'none';
            }
        } catch (error) {
            console.error('주차 시간 업데이트 실패:', error);
        }
    }, 60000); // 1분마다 업데이트
}

// 시간 포맷팅
function formatDuration(minutes) {
    if (minutes < 60) {
        return `${minutes}분`;
    }
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}시간 ${mins}분`;
}

// 날짜 시간 포맷팅
function formatDateTime(dateTime) {
    const date = new Date(dateTime);
    return date.toLocaleString('ko-KR', {
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// 입차 모달 표시
function showEntryModal(parkingId, parkingName, parkingGrade) {
    document.getElementById('selectedParkingId').value = parkingId;
    document.getElementById('selectedParkingName').value = parkingName;
    document.getElementById('selectedParkingGrade').value = parkingGrade;
    document.getElementById('carNumber').value = '';
    document.getElementById('entryModal').style.display = 'flex';
}

// 입차 모달 닫기
function closeEntryModal() {
    document.getElementById('entryModal').style.display = 'none';
}

// 입차 등록
async function recordEntry() {
    const parkingLotId = document.getElementById('selectedParkingId').value;
    const parkingLotName = document.getElementById('selectedParkingName').value;
    const parkingGrade = document.getElementById('selectedParkingGrade').value;
    const carNumber = document.getElementById('carNumber').value;

    if (!carNumber) {
        alert('차량번호를 입력해주세요.');
        return;
    }

    try {
        const response = await fetch('/api/parking/entry', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userId: currentUserId,
                parkingLotId: parkingLotId,
                parkingLotName: parkingLotName,
                carNumber: carNumber,
                parkingGrade: parkingGrade
            })
        });

        const data = await response.json();

        if (data.success) {
            closeEntryModal();
            showQRModal(data.qrCode);
            checkActiveSession();
        } else {
            alert(data.message || '입차 등록에 실패했습니다.');
        }
    } catch (error) {
        console.error('입차 등록 실패:', error);
        alert('입차 등록 중 오류가 발생했습니다.');
    }
}

// QR 모달 표시
function showQRModal(qrCode) {
    const qrContainer = document.getElementById('qrcode');
    qrContainer.innerHTML = '';

    new QRCode(qrContainer, {
        text: qrCode,
        width: 200,
        height: 200,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });

    document.getElementById('qrModal').style.display = 'flex';
}

// QR 모달 닫기
function closeQRModal() {
    document.getElementById('qrModal').style.display = 'none';
}

// 출차 모달 표시
async function showExitModal() {
    try {
        const response = await fetch(`/api/parking/calculate-fee`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sessionId: activeSessionId })
        });

        const data = await response.json();

        if (data.success) {
            document.getElementById('exitDuration').textContent = formatDuration(data.parkedMinutes);
            document.getElementById('exitBaseFee').textContent = data.parkingFee.toLocaleString() + '원';
            document.getElementById('exitFinalFee').textContent = data.parkingFee.toLocaleString() + '원';

            // 할인 체크박스 이벤트
            const isDisabled = document.getElementById('isDisabled');
            const isEco = document.getElementById('isEco');

            isDisabled.checked = false;
            isEco.checked = false;

            const updateFee = () => {
                let finalFee = data.parkingFee;
                let discountRate = 0;

                if (isDisabled.checked) discountRate += 0.50;
                if (isEco.checked) discountRate += 0.30;
                if (discountRate > 0.80) discountRate = 0.80;

                finalFee = Math.floor(finalFee * (1 - discountRate));
                document.getElementById('exitFinalFee').textContent = finalFee.toLocaleString() + '원';
            };

            isDisabled.onchange = updateFee;
            isEco.onchange = updateFee;

            document.getElementById('exitModal').style.display = 'flex';
        }
    } catch (error) {
        console.error('요금 계산 실패:', error);
        alert('요금 계산 중 오류가 발생했습니다.');
    }
}

// 출차 모달 닫기
function closeExitModal() {
    document.getElementById('exitModal').style.display = 'none';
}

// 출차 처리
async function processExit() {
    const isDisabled = document.getElementById('isDisabled').checked;
    const isEco = document.getElementById('isEco').checked;

    try {
        const response = await fetch('/api/parking/exit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                sessionId: activeSessionId,
                isDisabled: isDisabled,
                isEco: isEco
            })
        });

        const data = await response.json();

        if (data.success) {
            alert(`출차가 완료되었습니다.\n최종 요금: ${data.finalFee.toLocaleString()}원`);
            closeExitModal();

            // 활성 세션 카드 숨기기
            document.getElementById('activeSessionCard').style.display = 'none';
            activeSessionId = null;

            if (parkingDurationInterval) {
                clearInterval(parkingDurationInterval);
            }
        } else {
            alert(data.message || '출차 처리에 실패했습니다.');
        }
    } catch (error) {
        console.error('출차 처리 실패:', error);
        alert('출차 처리 중 오류가 발생했습니다.');
    }
}
