/**
 * K-Pass 모바일 JavaScript
 * 잔액 조회, QR 생성, 이용내역, 통계 기능
 */

// 상태 관리
let currentUserId = 1; // 임시 사용자 ID (실제로는 세션에서 가져옴)
let currentBalance = 0;
let qrCodeInstance = null;

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', function () {
    initKPass();
});

/**
 * K-Pass 초기화
 */
async function initKPass() {
    console.log('[K-Pass] 초기화 시작');

    // 사용자 ID 확인 (URL 파라미터 또는 세션)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('userId')) {
        currentUserId = parseInt(urlParams.get('userId'));
    }

    // 데이터 로드
    await Promise.all([
        loadBalance(),
        loadMonthlyStats()
    ]);

    console.log('[K-Pass] 초기화 완료');
}

/**
 * K-Pass 잔액 조회
 */
async function loadBalance() {
    try {
        const response = await fetch(`/api/kpass/balance/${currentUserId}`);
        const data = await response.json();

        if (data.success) {
            currentBalance = data.balance;
            document.getElementById('currentPoints').textContent = formatNumber(data.balance);
            document.getElementById('cardUserName').textContent = data.userName || '사용자';

            // 유효기간 (예시: 현재 년도 말)
            const validDate = new Date();
            validDate.setMonth(11, 31);
            document.getElementById('cardValidDate').textContent =
                `유효기간: ${validDate.getFullYear()}.${String(validDate.getMonth() + 1).padStart(2, '0')}`;
        } else {
            console.error('[K-Pass] 잔액 조회 실패:', data.error);
        }
    } catch (error) {
        console.error('[K-Pass] 잔액 조회 에러:', error);
        // 오프라인 모드 또는 에러 처리
        document.getElementById('currentPoints').textContent = '-';
    }
}

/**
 * 월간 통계 조회
 */
async function loadMonthlyStats() {
    try {
        const response = await fetch(`/api/kpass/stats/${currentUserId}`);
        const data = await response.json();

        if (data.success) {
            document.getElementById('monthlyUsageCount').textContent = data.usageCount || 0;
            document.getElementById('monthlySavings').textContent =
                formatNumber(data.savingsEstimate || 0) + '원';
        }
    } catch (error) {
        console.error('[K-Pass] 통계 조회 에러:', error);
    }
}

/**
 * QR 코드 모달 표시
 */
async function showQRCode() {
    const modal = document.getElementById('qrModal');
    modal.classList.add('active');

    try {
        // QR 토큰 생성 요청
        const response = await fetch('/api/kpass/qr/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: currentUserId })
        });
        const data = await response.json();

        if (data.success) {
            generateQRCode(data.token);
        } else {
            alert('QR 코드 생성에 실패했습니다.');
            closeQRModal();
        }
    } catch (error) {
        console.error('[K-Pass] QR 생성 에러:', error);
        // Fallback: 클라이언트에서 직접 생성
        const fallbackToken = `KPASS:${currentUserId}:${currentBalance}:${Date.now()}`;
        generateQRCode(fallbackToken);
    }
}

/**
 * QR 코드 생성
 */
function generateQRCode(token) {
    const container = document.getElementById('qrCodeContainer');
    container.innerHTML = ''; // 기존 QR 코드 제거

    // QRCode.js 라이브러리 사용
    if (typeof QRCode !== 'undefined') {
        qrCodeInstance = new QRCode(container, {
            text: token,
            width: 180,
            height: 180,
            colorDark: '#667eea',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.H
        });
    } else {
        // 라이브러리 없을 때 대체 표시
        container.innerHTML = `
            <div style="padding: 20px; word-break: break-all; font-size: 10px; color: #888;">
                ${token}
            </div>
        `;
    }
}

/**
 * QR 모달 닫기
 */
function closeQRModal() {
    const modal = document.getElementById('qrModal');
    modal.classList.remove('active');

    // QR 코드 인스턴스 정리
    if (qrCodeInstance) {
        qrCodeInstance.clear();
        qrCodeInstance = null;
    }
}

/**
 * 이용내역 표시
 */
async function showHistory() {
    const section = document.getElementById('historySection');
    const list = document.getElementById('historyList');

    section.style.display = 'block';
    list.innerHTML = `
        <div class="loading">
            <div class="spinner"></div>
            <p>이용내역을 불러오는 중...</p>
        </div>
    `;

    try {
        const response = await fetch(`/api/kpass/history/${currentUserId}`);
        const data = await response.json();

        if (data.success && data.transactions && data.transactions.length > 0) {
            list.innerHTML = data.transactions.map(tx => createHistoryItem(tx)).join('');
        } else {
            list.innerHTML = `
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M13,9H11V7H13M13,17H11V11H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"/>
                    </svg>
                    <p>이용내역이 없습니다</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('[K-Pass] 내역 조회 에러:', error);
        list.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M13,14H11V10H13M13,18H11V16H13M1,21H23L12,2L1,21Z"/>
                </svg>
                <p>내역을 불러올 수 없습니다</p>
            </div>
        `;
    }
}

/**
 * 이용내역 아이템 HTML 생성
 */
function createHistoryItem(tx) {
    const isEarn = tx.type === 'EARN';
    const pointClass = isEarn ? 'earn' : 'use';
    const pointSign = isEarn ? '+' : '-';

    // 날짜 포맷
    let dateStr = '-';
    if (tx.transactionTime) {
        const date = new Date(tx.transactionTime);
        dateStr = `${date.getMonth() + 1}/${date.getDate()} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    }

    return `
        <div class="history-item">
            <div class="item-header">
                <span class="item-type">${isEarn ? '적립' : '사용'}</span>
                <span class="item-date">${dateStr}</span>
            </div>
            <div class="item-detail">${tx.reason || '-'}</div>
            <div class="item-points ${pointClass}">${pointSign}${formatNumber(tx.amount)}P</div>
        </div>
    `;
}

/**
 * 이용내역 닫기
 */
function hideHistory() {
    document.getElementById('historySection').style.display = 'none';
}

/**
 * K-Pass 메뉴 표시
 */
function showKpassMenu() {
    // 간단한 알림 또는 드로어 메뉴
    const menu = [
        '충전하기',
        '사용하기',
        '이용내역',
        '혜택안내',
        '설정'
    ];

    alert('메뉴: ' + menu.join(' | '));
}

/**
 * 숫자 포맷 (천 단위 콤마)
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * 포인트 충전 (테스트용)
 */
async function chargePoints(amount) {
    try {
        const response = await fetch('/api/kpass/earn', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userId: currentUserId,
                transportType: 'CHARGE',
                fare: amount,
                routeInfo: '직접 충전'
            })
        });
        const data = await response.json();

        if (data.success) {
            alert(`${data.earnedPoints}P 충전 완료!\n새 잔액: ${formatNumber(data.newBalance)}P`);
            loadBalance();
        } else {
            alert('충전 실패: ' + data.error);
        }
    } catch (error) {
        console.error('[K-Pass] 충전 에러:', error);
        alert('충전 중 오류가 발생했습니다.');
    }
}

/**
 * 포인트 사용 (테스트용)
 */
async function spendPoints(amount, reason) {
    try {
        const response = await fetch('/api/kpass/use', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userId: currentUserId,
                points: amount,
                reason: reason || '포인트 사용'
            })
        });
        const data = await response.json();

        if (data.success) {
            alert(`${data.usedPoints}P 사용 완료!\n새 잔액: ${formatNumber(data.newBalance)}P`);
            loadBalance();
        } else {
            alert('사용 실패: ' + data.error);
        }
    } catch (error) {
        console.error('[K-Pass] 사용 에러:', error);
        alert('사용 중 오류가 발생했습니다.');
    }
}

// 전역 함수로 노출 (HTML onclick에서 사용)
window.showQRCode = showQRCode;
window.closeQRModal = closeQRModal;
window.showHistory = showHistory;
window.hideHistory = hideHistory;
window.showKpassMenu = showKpassMenu;
window.chargePoints = chargePoints;
window.spendPoints = spendPoints;
