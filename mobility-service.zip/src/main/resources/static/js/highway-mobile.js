/**
 * 고속도로 통행료 모바일 페이지 JavaScript
 * K-MaaS 통합 교통 시스템
 */

// 전역 변수
let currentUserId = 1; // 테스트용 사용자 ID
let selectedVehicle = null;
let selectedPaymentMethod = 'HIPASS';

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    console.log('[고속도로] 페이지 로드 완료');
    loadUserVehicles();
    loadTollHistory();
});

/**
 * 사용자 차량 목록 로드
 */
async function loadUserVehicles() {
    try {
        const response = await fetch(`/api/vehicles/user/${currentUserId}`);
        if (!response.ok) {
            throw new Error('차량 목록 조회 실패');
        }

        const vehicles = await response.json();
        const select = document.getElementById('vehicleSelect');

        // 기존 옵션 제거 (첫 번째 제외)
        while (select.options.length > 1) {
            select.remove(1);
        }

        // 차량 목록 추가
        vehicles.forEach(vehicle => {
            const option = document.createElement('option');
            option.value = vehicle.vehicleId;
            option.textContent = `${vehicle.vehicleNumber} (${getVehicleTypeName(vehicle.vehicleType)})`;
            option.dataset.vehicle = JSON.stringify(vehicle);
            select.appendChild(option);
        });

        console.log(`[차량 로드] ${vehicles.length}대 로드 완료`);

    } catch (error) {
        console.error('[차량 로드 실패]', error);
        // 테스트용 기본 차량 추가
        addTestVehicle();
    }
}

/**
 * 테스트용 차량 추가
 */
function addTestVehicle() {
    const select = document.getElementById('vehicleSelect');
    const testVehicle = {
        vehicleId: 999,
        vehicleNumber: '12가3456',
        vehicleType: 'SEDAN',
        vehicleClass: 2,
        isElectric: false,
        isDisabled: false,
        isEcoFriendly: false
    };

    const option = document.createElement('option');
    option.value = testVehicle.vehicleId;
    option.textContent = `${testVehicle.vehicleNumber} (승용차)`;
    option.dataset.vehicle = JSON.stringify(testVehicle);
    select.appendChild(option);
}

/**
 * 차량 선택 이벤트
 */
function selectVehicle() {
    const select = document.getElementById('vehicleSelect');
    const selectedOption = select.options[select.selectedIndex];

    if (selectedOption.value === '') {
        document.getElementById('vehicleInfo').style.display = 'none';
        selectedVehicle = null;
        return;
    }

    selectedVehicle = JSON.parse(selectedOption.dataset.vehicle);

    // 차량 정보 표시
    document.getElementById('vehicleNumber').textContent = selectedVehicle.vehicleNumber;
    document.getElementById('vehicleType').textContent = getVehicleTypeName(selectedVehicle.vehicleType);

    // 할인 혜택 표시
    const discounts = [];
    if (selectedVehicle.vehicleClass === 1) discounts.push('경차 50%');
    if (selectedVehicle.isElectric) discounts.push('전기차 50%');
    if (selectedVehicle.isDisabled) discounts.push('장애인 50%');
    if (selectedVehicle.isEcoFriendly) discounts.push('친환경 30%');

    document.getElementById('vehicleDiscount').textContent =
        discounts.length > 0 ? discounts.join(', ') : '해당 없음';

    document.getElementById('vehicleInfo').style.display = 'block';

    console.log('[차량 선택]', selectedVehicle);
}

/**
 * 차량 유형명 반환
 */
function getVehicleTypeName(type) {
    const typeMap = {
        'COMPACT': '경차',
        'SEDAN': '승용차',
        'SUV': 'SUV',
        'TRUCK': '화물차',
        'SPECIAL': '특수차량'
    };
    return typeMap[type] || '승용차';
}

/**
 * 톨게이트 목록 로드
 */
async function loadTollgates() {
    const routeSelect = document.getElementById('routeSelect');
    const routeNo = routeSelect.value;

    if (!routeNo) {
        return;
    }

    try {
        const response = await fetch(`/api/highway/tollgates?routeNo=${routeNo}`);

        if (!response.ok) {
            throw new Error('톨게이트 조회 실패');
        }

        const tollgates = await response.json();
        updateTollgateSelects(tollgates);

    } catch (error) {
        console.error('[톨게이트 로드 실패]', error);
        // Fallback: 기본 톨게이트 사용
        loadDefaultTollgates(routeNo);
    }
}

/**
 * 기본 톨게이트 로드 (Fallback)
 */
function loadDefaultTollgates(routeNo) {
    const tollgates = {
        '1': [ // 경부선
            { code: '001', name: '서울' },
            { code: '002', name: '한남' },
            { code: '003', name: '양재' },
            { code: '010', name: '수원신갈' },
            { code: '020', name: '천안' },
            { code: '030', name: '대전' },
            { code: '040', name: '대구' },
            { code: '100', name: '부산' }
        ],
        '10': [ // 남해선
            { code: '101', name: '순천' },
            { code: '102', name: '광양' },
            { code: '103', name: '사천' },
            { code: '104', name: '진주' },
            { code: '105', name: '부산' }
        ],
        '100': [ // 중부선
            { code: '201', name: '하남' },
            { code: '202', name: '일죽' },
            { code: '203', name: '충주' },
            { code: '204', name: '통영' }
        ],
        '130': [ // 서해안선
            { code: '301', name: '목감' },
            { code: '302', name: '당진' },
            { code: '303', name: '서산' },
            { code: '304', name: '목포' }
        ]
    };

    const selectedTollgates = tollgates[routeNo] || tollgates['1'];
    updateTollgateSelects(selectedTollgates);
}

/**
 * 톨게이트 셀렉트 업데이트
 */
function updateTollgateSelects(tollgates) {
    const entrySelect = document.getElementById('entryTollgate');
    const exitSelect = document.getElementById('exitTollgate');

    // 기존 옵션 제거
    entrySelect.innerHTML = '<option value="">진입 톨게이트 선택</option>';
    exitSelect.innerHTML = '<option value="">출구 톨게이트 선택</option>';

    // 새 옵션 추가
    tollgates.forEach(tollgate => {
        const entryOption = document.createElement('option');
        entryOption.value = tollgate.code;
        entryOption.textContent = tollgate.name;
        entrySelect.appendChild(entryOption);

        const exitOption = document.createElement('option');
        exitOption.value = tollgate.code;
        exitOption.textContent = tollgate.name;
        exitSelect.appendChild(exitOption);
    });
}

/**
 * 경로 정보 업데이트
 */
function updateRouteInfo() {
    const entrySelect = document.getElementById('entryTollgate');
    const exitSelect = document.getElementById('exitTollgate');

    const entryName = entrySelect.options[entrySelect.selectedIndex]?.text;
    const exitName = exitSelect.options[exitSelect.selectedIndex]?.text;

    if (entryName && exitName && entryName !== '진입 톨게이트 선택' && exitName !== '출구 톨게이트 선택') {
        updateStatusCard(`${entryName} → ${exitName}`, '통행료 계산 준비 완료');
    }
}

/**
 * 결제 방법 선택
 */
function selectPaymentMethod(method) {
    selectedPaymentMethod = method;

    // 모든 버튼의 active 클래스 제거
    document.querySelectorAll('.payment-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // 선택된 버튼에 active 클래스 추가
    event.target.closest('.payment-btn').classList.add('active');

    console.log('[결제 방법 선택]', method);
}

/**
 * 예상 통행료 계산
 */
async function calculateFee() {
    // 입력 검증
    if (!selectedVehicle) {
        alert('차량을 먼저 선택해주세요.');
        return;
    }

    const routeSelect = document.getElementById('routeSelect');
    const entrySelect = document.getElementById('entryTollgate');
    const exitSelect = document.getElementById('exitTollgate');
    const distanceInput = document.getElementById('distanceKm');

    if (!routeSelect.value) {
        alert('노선을 선택해주세요.');
        return;
    }

    if (!entrySelect.value || !exitSelect.value) {
        alert('진입/출구 톨게이트를 선택해주세요.');
        return;
    }

    if (!distanceInput.value || distanceInput.value <= 0) {
        alert('예상 거리를 입력해주세요.');
        return;
    }

    const entryCode = entrySelect.value;
    const exitCode = exitSelect.value;
    const routeNo = routeSelect.value;
    const distanceKm = parseFloat(distanceInput.value);

    try {
        updateStatusCard('계산 중...', '통행료를 계산하고 있습니다');

        const url = `/api/highway/calculate?entryCode=${entryCode}&exitCode=${exitCode}&vehicleNumber=${selectedVehicle.vehicleNumber}&routeNo=${routeNo}&distanceKm=${distanceKm}`;

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error('요금 계산 실패');
        }

        const result = await response.json();

        // 결과 표시
        displayFeeResult(result);

        const entryName = entrySelect.options[entrySelect.selectedIndex].text;
        const exitName = exitSelect.options[exitSelect.selectedIndex].text;
        updateStatusCard(`${entryName} → ${exitName}`, '요금 계산 완료');

    } catch (error) {
        console.error('[요금 계산 실패]', error);
        alert('요금 계산에 실패했습니다. 다시 시도해주세요.');
        updateStatusCard('계산 실패', '다시 시도해주세요');
    }
}

/**
 * 요금 결과 표시
 */
function displayFeeResult(result) {
    const baseFee = result.baseFee || 0;
    const discountAmount = result.discountAmount || 0;
    const finalFee = result.finalFee || 0;
    const discountRate = result.discountRate || 0;

    // 요금 표시
    document.getElementById('baseFee').textContent = formatCurrency(baseFee);
    document.getElementById('discountAmount').textContent = '-' + formatCurrency(discountAmount);
    document.getElementById('finalFee').textContent = formatCurrency(finalFee);

    // 할인 정보 표시
    const discountInfo = buildDiscountInfo(discountRate);
    document.getElementById('discountInfo').innerHTML = discountInfo;

    // 적립 포인트 계산 (3%)
    const earnedPoints = Math.round(finalFee * 0.03);
    document.getElementById('earnedPoints').textContent = earnedPoints + 'P';

    // 결과 영역 표시
    document.getElementById('feeResult').style.display = 'block';

    // 스크롤 이동
    document.getElementById('feeResult').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/**
 * 할인 정보 생성
 */
function buildDiscountInfo(discountRate) {
    const discounts = [];

    if (selectedVehicle.vehicleClass === 1) {
        discounts.push('✓ 경차 50% 할인');
    }

    if (selectedVehicle.isElectric) {
        discounts.push('✓ 전기차 50% 할인');
    }

    if (selectedVehicle.isDisabled) {
        discounts.push('✓ 장애인 차량 50% 할인');
    }

    if (selectedPaymentMethod === 'HIPASS') {
        discounts.push('✓ 하이패스 10% 할인');
    }

    const now = new Date();
    const hour = now.getHours();
    if ((hour >= 6 && hour < 9) || (hour >= 18 && hour < 20)) {
        discounts.push('✓ 출퇴근 시간대 20% 할인');
    }

    if (discounts.length === 0) {
        return '<p>적용된 할인이 없습니다.</p>';
    }

    return `
        <p><strong>적용된 할인 내역:</strong></p>
        <ul style="margin: 8px 0; padding-left: 20px;">
            ${discounts.map(d => `<li>${d}</li>`).join('')}
        </ul>
        <p><strong>총 할인율: ${discountRate.toFixed(1)}%</strong></p>
    `;
}

/**
 * 통행 내역 로드
 */
async function loadTollHistory() {
    try {
        const response = await fetch(`/api/highway/history/${currentUserId}`);

        if (!response.ok) {
            throw new Error('내역 조회 실패');
        }

        const data = await response.json();
        const history = data.history || [];

        displayTollHistory(history);

    } catch (error) {
        console.error('[내역 로드 실패]', error);
        // 빈 상태 유지
    }
}

/**
 * 통행 내역 표시
 */
function displayTollHistory(history) {
    const container = document.getElementById('tollHistory');

    if (history.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M13,9H11V7H13M13,17H11V11H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"/>
                </svg>
                <p>통행 내역이 없습니다</p>
            </div>
        `;
        return;
    }

    const html = history.map(record => `
        <div class="history-card">
            <div class="history-header">
                <div class="history-route">${record.entryTollgate} → ${record.exitTollgate}</div>
                <div class="history-date">${formatDate(record.exitTime)}</div>
            </div>
            <div class="history-details">
                <div class="history-detail-item">
                    차량: <strong>${record.vehicleNumber}</strong>
                </div>
                <div class="history-detail-item">
                    거리: <strong>${record.distanceKm}km</strong>
                </div>
                <div class="history-detail-item">
                    노선: <strong>${record.routeName}</strong>
                </div>
                <div class="history-detail-item">
                    차종: <strong>${record.vehicleType}</strong>
                </div>
            </div>
            <div class="history-footer">
                <div class="history-fee">${formatCurrency(record.finalFee)}</div>
                <div class="history-payment">${getPaymentMethodName(record.paymentMethod)}</div>
            </div>
        </div>
    `).join('');

    container.innerHTML = html;
}

/**
 * 차량 등록 모달 표시
 */
function showVehicleRegister() {
    document.getElementById('vehicleRegisterModal').style.display = 'flex';
}

/**
 * 차량 등록 모달 닫기
 */
function closeVehicleRegister() {
    document.getElementById('vehicleRegisterModal').style.display = 'none';
}

/**
 * 차량 등록
 */
async function registerVehicle() {
    const vehicleNumber = document.getElementById('newVehicleNumber').value.trim();
    const vehicleType = document.getElementById('newVehicleType').value;
    const vehicleClass = parseInt(document.getElementById('newVehicleClass').value);
    const isElectric = document.getElementById('isElectric').checked;
    const isDisabled = document.getElementById('isDisabled').checked;
    const isEcoFriendly = document.getElementById('isEcoFriendly').checked;

    if (!vehicleNumber) {
        alert('차량번호를 입력해주세요.');
        return;
    }

    const vehicleData = {
        userId: currentUserId,
        vehicleNumber: vehicleNumber,
        vehicleType: vehicleType,
        vehicleClass: vehicleClass,
        isElectric: isElectric,
        isDisabled: isDisabled,
        isEcoFriendly: isEcoFriendly,
        isActive: true
    };

    try {
        const response = await fetch('/api/vehicles/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(vehicleData)
        });

        if (!response.ok) {
            throw new Error('차량 등록 실패');
        }

        alert('차량이 등록되었습니다.');
        closeVehicleRegister();

        // 차량 목록 다시 로드
        loadUserVehicles();

        // 폼 초기화
        document.getElementById('newVehicleNumber').value = '';
        document.getElementById('isElectric').checked = false;
        document.getElementById('isDisabled').checked = false;
        document.getElementById('isEcoFriendly').checked = false;

    } catch (error) {
        console.error('[차량 등록 실패]', error);
        alert('차량 등록에 실패했습니다. 다시 시도해주세요.');
    }
}

/**
 * 상태 카드 업데이트
 */
function updateStatusCard(title, message) {
    document.getElementById('statusTitle').textContent = title;
    document.getElementById('statusMessage').textContent = message;
}

/**
 * 메뉴 표시
 */
function showMenu() {
    alert('메뉴 기능은 준비 중입니다.');
}

/**
 * 통화 포맷
 */
function formatCurrency(amount) {
    return amount.toLocaleString('ko-KR') + '원';
}

/**
 * 날짜 포맷
 */
function formatDate(dateString) {
    if (!dateString) return '-';

    const date = new Date(dateString);
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const hours = date.getHours();
    const minutes = date.getMinutes();

    return `${month}월 ${day}일 ${hours}:${minutes.toString().padStart(2, '0')}`;
}

/**
 * 결제 방법명 반환
 */
function getPaymentMethodName(method) {
    const methodMap = {
        'HIPASS': '하이패스',
        'CARD': '신용카드',
        'CASH': '현금'
    };
    return methodMap[method] || method;
}
