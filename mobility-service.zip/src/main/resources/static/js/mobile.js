// 모바일 MaaS 애플리케이션 JavaScript

// 전역 변수
let currentUser = null;

// DOM 로드 완료
document.addEventListener('DOMContentLoaded', function () {
    initApp();
});

// 앱 초기화
function initApp() {
    // 탭 네비게이션
    initTabNavigation();

    // 하단 네비게이션
    initBottomNavigation();

    // 로그인 상태 확인
    checkLoginStatus();

    // 검색 기능
    initSearch();
}

// 탭 네비게이션 초기화
function initTabNavigation() {
    const tabBtns = document.querySelectorAll('.tab-btn');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            tabBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            const tab = this.dataset.tab;
            loadTabContent(tab);
        });
    });
}

// 탭 콘텐츠 로드
function loadTabContent(tab) {
    console.log('Loading tab:', tab);

    if (tab === 'workplace') {
        alert('직장 설정 기능 준비중입니다.');
    }
}

// 하단 네비게이션 초기화
function initBottomNavigation() {
    const navBtns = document.querySelectorAll('.nav-btn');

    navBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            navBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            const page = this.dataset.page;
            navigateToPage(page);
        });
    });
}

// 페이지 네비게이션
function navigateToPage(page) {
    console.log('Navigate to:', page);

    switch (page) {
        case 'home':
            // 이미 홈 페이지
            break;
        case 'benefits':
            location.href = '/mobile/kpass';
            break;
        case 'search':
            focusSearch();
            break;
        case 'menu':
            showMenu();
            break;
    }
}

// 검색 초기화
function initSearch() {
    const searchInput = document.getElementById('searchInput');

    if (searchInput) {
        searchInput.addEventListener('focus', function () {
            this.parentElement.style.border = '2px solid var(--primary-green)';
        });

        searchInput.addEventListener('blur', function () {
            this.parentElement.style.border = '';
        });

        searchInput.addEventListener('input', function () {
            const query = this.value.trim();
            if (query.length > 1) {
                searchLocations(query);
            }
        });
    }
}

// 검색 포커스
function focusSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.focus();
    }
}

// 위치 검색
function searchLocations(query) {
    console.log('Searching for:', query);
    // 실제 검색 API 연동 필요
}

// 로그인 상태 확인
function checkLoginStatus() {
    // 세션에서 사용자 정보 확인 (404는 정상 - 비로그인 상태)
    fetch('/api/user/current')
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            // 404나 다른 에러는 비로그인 상태로 처리
            return null;
        })
        .then(user => {
            if (user) {
                currentUser = user;
                showUserProfile(user);
            }
            // 비로그인 상태는 조용히 처리 (showLoginPrompt 제거)
        })
        .catch(() => {
            // 네트워크 에러도 조용히 처리
        });
}


// 사용자 프로필 표시
function showUserProfile(user) {
    const userProfile = document.querySelector('.user-profile');
    if (userProfile) {
        userProfile.classList.add('active');

        // 사용자 정보 업데이트
        const userName = userProfile.querySelector('.user-details h3');
        if (userName) {
            userName.textContent = user.name || user.email;
        }

        // 마일리지 정보 업데이트
        updateUserPoints(user.userId);
    }
}

// 로그인 프롬프트 표시
function showLoginPrompt() {
    // 비로그인 시 메뉴 버튼에 알림 표시
    const menuBtn = document.querySelector('[data-page="menu"]');
    if (menuBtn) {
        menuBtn.style.position = 'relative';
    }
}

// 로그인 모달 표시
function showLoginModal() {
    const modal = createModal('login');
    document.body.appendChild(modal);

    // 모달 애니메이션
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

// 회원가입 모달 표시
function showSignupModal() {
    const modal = createModal('signup');
    document.body.appendChild(modal);

    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

// 모달 생성
function createModal(type) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    const content = document.createElement('div');
    content.className = 'modal-content';

    if (type === 'login') {
        content.innerHTML = `
            <div class="modal-header">
                <h2>로그인</h2>
                <p>K-MaaS에 오신 것을 환영합니다</p>
            </div>
            <form id="loginForm">
                <div class="form-group">
                    <label>이메일</label>
                    <input type="email" name="email" required placeholder="example@email.com">
                </div>
                <div class="form-group">
                    <label>비밀번호</label>
                    <input type="password" name="password" required placeholder="비밀번호 입력">
                </div>
                <button type="submit" class="btn btn-primary">로그인</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal()">취소</button>
            </form>
            <div class="modal-footer">
                계정이 없으신가요? <a href="#" onclick="showSignupModal(); return false;">회원가입</a>
            </div>
        `;
    } else if (type === 'signup') {
        content.innerHTML = `
            <div class="modal-header">
                <h2>회원가입</h2>
                <p>새로운 계정을 만들어보세요</p>
            </div>
            <form id="signupForm">
                <div class="form-group">
                    <label>이름</label>
                    <input type="text" name="name" required placeholder="홍길동">
                </div>
                <div class="form-group">
                    <label>이메일</label>
                    <input type="email" name="email" required placeholder="example@email.com">
                </div>
                <div class="form-group">
                    <label>비밀번호</label>
                    <input type="password" name="password" required placeholder="8자 이상">
                </div>
                <div class="form-group">
                    <label>전화번호</label>
                    <input type="tel" name="phone" required placeholder="010-1234-5678">
                </div>
                <button type="submit" class="btn btn-primary">가입하기</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal()">취소</button>
            </form>
            <div class="modal-footer">
                이미 계정이 있으신가요? <a href="#" onclick="showLoginModal(); return false;">로그인</a>
            </div>
        `;
    }

    overlay.appendChild(content);

    // 폼 제출 이벤트
    if (type === 'login') {
        content.querySelector('#loginForm').addEventListener('submit', handleLogin);
    } else if (type === 'signup') {
        content.querySelector('#signupForm').addEventListener('submit', handleSignup);
    }

    // 외부 클릭 시 닫기
    overlay.addEventListener('click', function (e) {
        if (e.target === overlay) {
            closeModal();
        }
    });

    return overlay;
}

// 모달 닫기
function closeModal() {
    const modal = document.querySelector('.modal-overlay');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

// 로그인 처리
function handleLogin(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const data = {
        email: formData.get('email'),
        password: formData.get('password')
    };

    fetch('/api/user/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                currentUser = result.user;
                closeModal();
                showUserProfile(result.user);
                alert('로그인 성공!');
                location.reload();
            } else {
                alert(result.message || '로그인 실패');
            }
        })
        .catch(err => {
            console.error('Login error:', err);
            alert('로그인 중 오류가 발생했습니다.');
        });
}

// 회원가입 처리
function handleSignup(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        password: formData.get('password'),
        phone: formData.get('phone')
    };

    fetch('/api/user/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                alert('회원가입 성공! 로그인해주세요.');
                closeModal();
                showLoginModal();
            } else {
                alert(result.message || '회원가입 실패');
            }
        })
        .catch(err => {
            console.error('Signup error:', err);
            alert('회원가입 중 오류가 발생했습니다.');
        });
}

// 사용자 포인트 업데이트
function updateUserPoints(userId) {
    fetch(`/api/user/${userId}/points`)
        .then(response => response.json())
        .then(data => {
            const pointElement = document.querySelector('.stat-value');
            if (pointElement) {
                pointElement.textContent = data.points.toLocaleString() + 'P';
            }
        })
        .catch(err => {
            console.error('Error fetching points:', err);
        });
}

// 메뉴 표시
function showMenu() {
    if (currentUser) {
        // 로그인 상태면 메뉴 페이지로
        location.href = '/mobile/menu';
    } else {
        // 비로그인 상태면 로그인 모달
        showLoginModal();
    }
}

// 유틸리티 함수
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function formatDate(date) {
    const d = new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
