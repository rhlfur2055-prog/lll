package com.maas.service;

import com.maas.service.config.ApiKeyConfig;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * 외부 API 연결 테스트
 * 모든 외부 API의 연결 상태를 동시에 테스트하고 결과를 표 형식으로 출력
 */
@SpringBootTest
public class ApiConnectionTest {

    private static final Logger log = LoggerFactory.getLogger(ApiConnectionTest.class);

    @Autowired
    private ApiKeyConfig apiKeyConfig;

    @Autowired
    private WebClient.Builder webClientBuilder;

    private static class ApiTestResult {
        String apiName;
        String endpoint;
        String status;
        int responseTime;
        String message;

        public ApiTestResult(String apiName, String endpoint) {
            this.apiName = apiName;
            this.endpoint = endpoint;
            this.status = "TESTING";
            this.responseTime = 0;
            this.message = "";
        }
    }

    @Test
    public void testAllApiConnections() throws Exception {
        log.info("=".repeat(100));
        log.info("K-MaaS API 연결 테스트 시작");
        log.info("=".repeat(100));

        List<ApiTestResult> results = new ArrayList<>();

        // 테스트할 API 목록
        List<CompletableFuture<ApiTestResult>> futures = new ArrayList<>();

        // 1. Seoul Metro Arrival API
        futures.add(testSeoulMetroArrival(results));

        // 2. Seoul Metro Congestion API
        futures.add(testSeoulMetroCongestion(results));

        // 3. Gyeonggi Bus API
        futures.add(testGyeonggiBus(results));

        // 4. Incheon Bus API
        futures.add(testIncheonBus(results));

        // 5. Public Data Portal - Subway Info
        futures.add(testPublicDataSubway(results));

        // 6. KTX API
        futures.add(testKtxApi(results));

        // 7. Public Bike (따릉이) API
        futures.add(testBikeApi(results));

        // 8. Air Quality API
        futures.add(testAirQualityApi(results));

        // 9. Shop API
        futures.add(testShopApi(results));

        // 10. Seoul Congestion API
        futures.add(testSeoulCongestionApi(results));

        // 모든 테스트 완료 대기 (최대 30초)
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .get(30, TimeUnit.SECONDS);

        // 결과 수집
        for (CompletableFuture<ApiTestResult> future : futures) {
            try {
                results.add(future.get());
            } catch (Exception e) {
                log.error("Failed to get test result", e);
            }
        }

        // 결과 출력
        printResults(results);

        log.info("=".repeat(100));
        log.info("API 연결 테스트 완료");
        log.info("=".repeat(100));
    }

    private CompletableFuture<ApiTestResult> testSeoulMetroArrival(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Seoul Metro Arrival", "http://swopenAPI.seoul.go.kr/api/subway");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "http://swopenAPI.seoul.go.kr/api/subway/" +
                        apiKeyConfig.getSeoulMetroArrivalKey() + "/json/realtimeStationArrival/0/5/서울";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("errorMessage")) {
                    result.status = "❌ FAILED";
                    result.message = "API Error Response";
                } else if (response != null && response.contains("realtimeArrivalList")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else {
                    result.status = "⚠️ UNKNOWN";
                    result.message = "Unexpected response";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName() + ": " + e.getMessage();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testSeoulMetroCongestion(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Seoul Metro Congestion", "http://swopenAPI.seoul.go.kr/api/subway");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "http://swopenAPI.seoul.go.kr/api/subway/" +
                        apiKeyConfig.getSeoulMetroCongestionKey() + "/json/CardSubwayStatsNew/1/5/20250101";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && !response.contains("ERROR")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else {
                    result.status = "❌ FAILED";
                    result.message = "API Error";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testGyeonggiBus(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Gyeonggi Bus", "https://apis.data.go.kr/6410000");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "https://apis.data.go.kr/6410000/buslocationservice/getBusLocationList" +
                        "?serviceKey=" + apiKeyConfig.getGyeonggiBusKey() +
                        "&routeId=234000037";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("busLocationList")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else if (response != null && response.contains("SERVICE_KEY")) {
                    result.status = "❌ FAILED";
                    result.message = "Invalid API Key";
                } else {
                    result.status = "⚠️ UNKNOWN";
                    result.message = "Check response";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testIncheonBus(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Incheon Bus", "https://apis.data.go.kr/6280000");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "https://apis.data.go.kr/6280000/busLocationService/getBusLocation" +
                        "?serviceKey=" + apiKeyConfig.getIncheonBusKey() +
                        "&brtId=165000014";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("busLocation")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else if (response != null && response.contains("SERVICE_KEY")) {
                    result.status = "❌ FAILED";
                    result.message = "Invalid API Key";
                } else {
                    result.status = "⚠️ UNKNOWN";
                    result.message = "Check response";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testPublicDataSubway(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Public Data - Subway", "https://apis.data.go.kr/1613000");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "https://apis.data.go.kr/1613000/SubwayInfoService/getKwrdFndSubwaySttnList" +
                        "?serviceKey=" + apiKeyConfig.getPublicDataPortalKey() +
                        "&subwayStationName=서울";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("item")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else {
                    result.status = "❌ FAILED";
                    result.message = "No data";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testKtxApi(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("KTX Train Info", "https://apis.data.go.kr/B551457");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "https://apis.data.go.kr/B551457/train/v2/trainInfo" +
                        "?serviceKey=" + apiKeyConfig.getKtxApiKey() +
                        "&depPlaceId=NAT010000" +
                        "&arrPlaceId=NAT014445";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("item")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else {
                    result.status = "❌ FAILED";
                    result.message = "No data";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testBikeApi(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Public Bike (따릉이)", "https://apis.data.go.kr/B551982");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "https://apis.data.go.kr/B551982/pbdo/BikeInformation" +
                        "?serviceKey=" + apiKeyConfig.getBikeApiKey();

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("item")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else {
                    result.status = "❌ FAILED";
                    result.message = "No data";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testAirQualityApi(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Air Quality", "https://apis.data.go.kr/B552584");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "https://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty" +
                        "?serviceKey=" + apiKeyConfig.getAirQualityKey() +
                        "&sidoName=서울" +
                        "&returnType=json";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("item")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else {
                    result.status = "❌ FAILED";
                    result.message = "No data";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testShopApi(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Shop API", "https://apis.data.go.kr/B553077");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "https://apis.data.go.kr/B553077/api/open/sdsc2/storeListInUpjong" +
                        "?serviceKey=" + apiKeyConfig.getShopApiKey() +
                        "&divId=ctprvnCd" +
                        "&key=11";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("body")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else {
                    result.status = "❌ FAILED";
                    result.message = "No data";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private CompletableFuture<ApiTestResult> testSeoulCongestionApi(List<ApiTestResult> results) {
        return CompletableFuture.supplyAsync(() -> {
            ApiTestResult result = new ApiTestResult("Seoul Congestion", "http://openapi.seoul.go.kr:8088");
            long startTime = System.currentTimeMillis();

            try {
                WebClient client = webClientBuilder.build();
                String url = "http://openapi.seoul.go.kr:8088/" +
                        apiKeyConfig.getSeoulCongestionKey() + "/json/citydata/1/5/종로구";

                String response = client.get()
                        .uri(url)
                        .retrieve()
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(5))
                        .block();

                result.responseTime = (int) (System.currentTimeMillis() - startTime);

                if (response != null && response.contains("RESULT")) {
                    result.status = "✅ SUCCESS";
                    result.message = "Connected";
                } else {
                    result.status = "❌ FAILED";
                    result.message = "No data";
                }
            } catch (Exception e) {
                result.responseTime = (int) (System.currentTimeMillis() - startTime);
                result.status = "❌ FAILED";
                result.message = e.getClass().getSimpleName();
            }

            return result;
        });
    }

    private void printResults(List<ApiTestResult> results) {
        log.info("");
        log.info("┌" + "─".repeat(98) + "┐");
        log.info("│" + center("K-MaaS API 연결 테스트 결과", 98) + "│");
        log.info("├" + "─".repeat(30) + "┬" + "─".repeat(35) + "┬" + "─".repeat(12) + "┬" + "─".repeat(10) + "┬" + "─".repeat(8) + "┤");
        log.info("│" + center("API Name", 30) + "│" + center("Endpoint", 35) + "│" + center("Status", 12) + "│" + center("Time(ms)", 10) + "│" + center("Message", 8) + "│");
        log.info("├" + "─".repeat(30) + "┼" + "─".repeat(35) + "┼" + "─".repeat(12) + "┼" + "─".repeat(10) + "┼" + "─".repeat(8) + "┤");

        int successCount = 0;
        int failCount = 0;
        int totalTime = 0;

        for (ApiTestResult result : results) {
            String status = padRight(result.status, 12);
            String time = padRight(result.responseTime + "ms", 10);
            String message = padRight(truncate(result.message, 8), 8);
            String apiName = padRight(truncate(result.apiName, 30), 30);
            String endpoint = padRight(truncate(result.endpoint, 35), 35);

            log.info("│" + apiName + "│" + endpoint + "│" + status + "│" + time + "│" + message + "│");

            if (result.status.contains("SUCCESS")) successCount++;
            else if (result.status.contains("FAILED")) failCount++;

            totalTime += result.responseTime;
        }

        log.info("└" + "─".repeat(30) + "┴" + "─".repeat(35) + "┴" + "─".repeat(12) + "┴" + "─".repeat(10) + "┴" + "─".repeat(8) + "┘");
        log.info("");
        log.info("📊 테스트 요약:");
        log.info("   ✅ 성공: {} / {}", successCount, results.size());
        log.info("   ❌ 실패: {} / {}", failCount, results.size());
        log.info("   ⏱️ 평균 응답시간: {}ms", results.isEmpty() ? 0 : totalTime / results.size());
        log.info("   ⏱️ 총 테스트 시간: {}ms", totalTime);
        log.info("");
    }

    private String center(String text, int width) {
        if (text.length() >= width) return text.substring(0, width);
        int leftPad = (width - text.length()) / 2;
        int rightPad = width - text.length() - leftPad;
        return " ".repeat(leftPad) + text + " ".repeat(rightPad);
    }

    private String padRight(String text, int width) {
        if (text.length() >= width) return text.substring(0, width);
        return text + " ".repeat(width - text.length());
    }

    private String truncate(String text, int maxLength) {
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 3) + "...";
    }
}
