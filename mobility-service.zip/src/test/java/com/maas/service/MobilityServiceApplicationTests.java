package com.maas.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobilityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
