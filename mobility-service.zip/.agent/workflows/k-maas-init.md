---
description: K-MaaS 플랫폼 자동 구축 시퀀스 (Supermove Style)
---

# 🖥️ K-MaaS : SYSTEM INITIALIZATION

> **전제 조건**: Java 17 이상 및 Maven 또는 Gradle이 설치되어 있어야 합니다.
> **사용법**: 아래 명령어를 Windows PowerShell 창에 그대로 복사하여 붙여넣으세요.

---

## [Phase 1] 인프라 스트럭처 구축 (디렉토리 자동 생성)

이 명령어 한 줄로 KTX, 지하철, 따릉이, K-Pass를 위한 모든 폴더 구조가 생성됩니다.

```powershell
# 프로젝트 루트 생성
mkdir k-maas-platform; cd k-maas-platform

# 백엔드 패키지 구조 생성 (Controller, Service, Entity, DTO, Config 등)
mkdir -p src/main/java/com/maas/service/config
mkdir -p src/main/java/com/maas/service/controller
mkdir -p src/main/java/com/maas/service/dto
mkdir -p src/main/java/com/maas/service/entity
mkdir -p src/main/java/com/maas/service/repository
mkdir -p src/main/java/com/maas/service/service/integration
mkdir -p src/main/java/com/maas/service/util

# 프론트엔드 리소스 구조 생성 (CSS, JS, Templates)
mkdir -p src/main/resources/static/css
mkdir -p src/main/resources/static/js
mkdir -p src/main/resources/templates/mobile
mkdir -p src/main/resources/templates/admin
mkdir -p src/main/resources/data

# 빌드 완료 메시지 출력
Write-Host "✅ K-MaaS System Infrastructure Ready." -ForegroundColor Green
```

---

## [Phase 2] 핵심 엔진 장착 (설정 파일 생성)

### A. Gradle 빌드 파일 생성 (build.gradle)

```powershell
# build.gradle 생성
@"
plugins {
    id 'java'
    id 'org.springframework.boot' version '3.2.0'
    id 'io.spring.dependency-management' version '1.1.4'
}

group = 'com.maas'
version = '1.0.0'
sourceCompatibility = '17'

repositories {
    mavenCentral()
}

dependencies {
    // Spring Boot Core
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'org.springframework.boot:spring-boot-starter-thymeleaf'
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'org.springframework.boot:spring-boot-starter-validation'
    implementation 'org.springframework.boot:spring-boot-starter-cache'
    
    // Database
    runtimeOnly 'com.h2database:h2'
    runtimeOnly 'com.oracle.database.jdbc:ojdbc11'
    
    // API Client
    implementation 'org.springframework.boot:spring-boot-starter-webflux'
    
    // Utility
    implementation 'org.projectlombok:lombok'
    annotationProcessor 'org.projectlombok:lombok'
    implementation 'com.google.code.gson:gson:2.10.1'
    
    // Test
    testImplementation 'org.springframework.boot:spring-boot-starter-test'
}

tasks.named('test') {
    useJUnitPlatform()
}
"@ | Out-File -FilePath build.gradle -Encoding UTF8

Write-Host "✅ build.gradle 생성 완료" -ForegroundColor Green
```

### B. Gradle Wrapper 설정

```powershell
# gradle-wrapper.properties 생성
mkdir -p gradle/wrapper
@"
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.5-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
"@ | Out-File -FilePath gradle/wrapper/gradle-wrapper.properties -Encoding UTF8

Write-Host "✅ Gradle Wrapper 설정 완료" -ForegroundColor Green
```

### C. 시스템 설정 파일 생성 (application.properties)

```powershell
# application.properties 생성
@"
# ========================================
# K-MaaS Platform Configuration
# ========================================

# Server
server.port=9999

# Application
spring.application.name=K-MaaS-Platform

# Database (H2 - Development)
spring.datasource.url=jdbc:h2:mem:maasdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=
spring.h2.console.enabled=true
spring.h2.console.path=/h2-console

# JPA
spring.jpa.hibernate.ddl-auto=create-drop
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true

# Thymeleaf
spring.thymeleaf.cache=false
spring.thymeleaf.prefix=classpath:/templates/
spring.thymeleaf.suffix=.html

# ========================================
# External API Keys (발급 받아서 입력)
# ========================================
# 한국철도공사 KTX API
api.korail.key=YOUR_KORAIL_API_KEY

# 서울 열린데이터광장 (지하철/따릉이)
api.seoul.key=YOUR_SEOUL_API_KEY

# 공공데이터포털
api.data.key=YOUR_DATA_PORTAL_KEY

# 카카오 지도 API
api.kakao.key=YOUR_KAKAO_JS_KEY

# ========================================
# Logging
# ========================================
logging.level.com.maas=DEBUG
logging.level.org.springframework.web=INFO
"@ | Out-File -FilePath src/main/resources/application.properties -Encoding UTF8

Write-Host "✅ application.properties 생성 완료" -ForegroundColor Green
```

---

## [Phase 3] 코어 파일 생성 (메인 클래스 + 샘플)

### A. Spring Boot 메인 클래스

```powershell
# MaasApplication.java 생성
@"
package com.maas.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class MaasApplication {
    public static void main(String[] args) {
        System.out.println("🚀 K-MaaS Platform Starting...");
        SpringApplication.run(MaasApplication.class, args);
        System.out.println("✅ K-MaaS Platform Ready at http://localhost:9999");
    }
}
"@ | Out-File -FilePath src/main/java/com/maas/service/MaasApplication.java -Encoding UTF8

Write-Host "✅ MaasApplication.java 생성 완료" -ForegroundColor Green
```

### B. 메인 컨트롤러 (라우팅)

```powershell
# MainController.java 생성
@"
package com.maas.service.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard";
    }

    @GetMapping("/mobile")
    public String mobile() {
        return "mobile/index";
    }

    @GetMapping("/api-test")
    public String apiTest() {
        return "api-test";
    }
}
"@ | Out-File -FilePath src/main/java/com/maas/service/controller/MainController.java -Encoding UTF8

Write-Host "✅ MainController.java 생성 완료" -ForegroundColor Green
```

### C. 모바일 인덱스 페이지

```powershell
# mobile/index.html 생성
@"
<!DOCTYPE html>
<html lang="ko" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>K-MaaS SuperApp</title>
    <link rel="stylesheet" th:href="@{/css/mobile.css}">
</head>
<body>
    <div class="app-container">
        <header class="app-header">
            <h1>🚄 K-MaaS</h1>
            <p>대한민국 통합 모빌리티</p>
        </header>
        
        <nav class="service-grid">
            <a href="/mobile/ktx" class="service-card ktx">
                <span class="icon">🚅</span>
                <span class="label">KTX</span>
            </a>
            <a href="/mobile/subway" class="service-card subway">
                <span class="icon">🚇</span>
                <span class="label">지하철</span>
            </a>
            <a href="/mobile/bike" class="service-card bike">
                <span class="icon">🚲</span>
                <span class="label">따릉이</span>
            </a>
            <a href="/mobile/kpass" class="service-card kpass">
                <span class="icon">💳</span>
                <span class="label">K-Pass</span>
            </a>
        </nav>
        
        <section class="quick-info">
            <h2>📍 실시간 정보</h2>
            <div id="realtime-info">로딩 중...</div>
        </section>
    </div>
    
    <script th:src="@{/js/mobile.js}"></script>
</body>
</html>
"@ | Out-File -FilePath src/main/resources/templates/mobile/index.html -Encoding UTF8

Write-Host "✅ mobile/index.html 생성 완료" -ForegroundColor Green
```

### D. CSS 스타일 (모바일)

```powershell
# mobile.css 생성
@"
/* K-MaaS Mobile SuperApp Style */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
}

.app-container {
    max-width: 480px;
    margin: 0 auto;
    padding: 20px;
}

.app-header {
    text-align: center;
    color: white;
    padding: 40px 0;
}

.app-header h1 {
    font-size: 2.5rem;
    margin-bottom: 10px;
}

.service-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    margin: 30px 0;
}

.service-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 20px;
    padding: 30px 20px;
    text-align: center;
    text-decoration: none;
    color: #333;
    transition: transform 0.3s, box-shadow 0.3s;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.service-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
}

.service-card .icon {
    font-size: 3rem;
    display: block;
    margin-bottom: 10px;
}

.service-card .label {
    font-size: 1.1rem;
    font-weight: 600;
}

.service-card.ktx { border-top: 4px solid #E31C5F; }
.service-card.subway { border-top: 4px solid #00A651; }
.service-card.bike { border-top: 4px solid #FFB800; }
.service-card.kpass { border-top: 4px solid #0066FF; }

.quick-info {
    background: white;
    border-radius: 20px;
    padding: 20px;
    margin-top: 20px;
}

.quick-info h2 {
    margin-bottom: 15px;
    color: #333;
}
"@ | Out-File -FilePath src/main/resources/static/css/mobile.css -Encoding UTF8

Write-Host "✅ mobile.css 생성 완료" -ForegroundColor Green
```

---

## [Phase 4] 시스템 점화 (실행)

// turbo-all

모든 파일 배치가 끝났다면, 시스템을 가동합니다.

```powershell
# Gradle Wrapper 다운로드 및 빌드
./gradlew wrapper
./gradlew clean build -x test
./gradlew bootRun
```

또는 **한 줄 실행**:

```powershell
./gradlew clean bootRun -x test
```

---

## 🌐 [Mission Control] 접속 대시보드

시스템 가동 확인 후 (`Started MaasApplication in...` 로그 확인), 브라우저에서 접속:

| 서비스 | URL |
|--------|-----|
| 📱 슈퍼앱 (모바일) | http://localhost:9999/mobile |
| 🖥️ 관제 센터 (대시보드) | http://localhost:9999/dashboard |
| 🛠️ 시스템 진단 (API Test) | http://localhost:9999/api-test |
| 📊 H2 콘솔 (DB) | http://localhost:9999/h2-console |

---

## 📁 모듈 배치 가이드 (파일 매핑)

| 파일 종류 | 저장 위치 |
|-----------|-----------|
| Config | `src/main/java/com/maas/service/config/` |
| Controller | `src/main/java/com/maas/service/controller/` |
| Service | `src/main/java/com/maas/service/service/` |
| Integration | `src/main/java/com/maas/service/service/integration/` |
| Entity | `src/main/java/com/maas/service/entity/` |
| Repository | `src/main/java/com/maas/service/repository/` |
| DTO | `src/main/java/com/maas/service/dto/` |
| Util | `src/main/java/com/maas/service/util/` |
| Main | `src/main/java/com/maas/service/MaasApplication.java` |

| 리소스 종류 | 저장 위치 |
|-------------|-----------|
| HTML (PC) | `src/main/resources/templates/` |
| HTML (Mobile) | `src/main/resources/templates/mobile/` |
| HTML (Admin) | `src/main/resources/templates/admin/` |
| CSS | `src/main/resources/static/css/` |
| JS | `src/main/resources/static/js/` |
| Data | `src/main/resources/data/` |

---

## ⚡ 원라인 전체 설치 (Copy & Paste)

아래 전체 스크립트를 PowerShell에 붙여넣으면 **모든 Phase가 자동 실행**됩니다:

```powershell
# K-MaaS 원클릭 설치 스크립트
Write-Host "🚀 K-MaaS Platform Installation Starting..." -ForegroundColor Cyan

# Phase 1: 디렉토리 생성
mkdir k-maas-platform; cd k-maas-platform
mkdir -p src/main/java/com/maas/service/config
mkdir -p src/main/java/com/maas/service/controller
mkdir -p src/main/java/com/maas/service/dto
mkdir -p src/main/java/com/maas/service/entity
mkdir -p src/main/java/com/maas/service/repository
mkdir -p src/main/java/com/maas/service/service/integration
mkdir -p src/main/java/com/maas/service/util
mkdir -p src/main/resources/static/css
mkdir -p src/main/resources/static/js
mkdir -p src/main/resources/templates/mobile
mkdir -p src/main/resources/templates/admin
mkdir -p src/main/resources/data
mkdir -p gradle/wrapper

Write-Host "✅ Phase 1: Infrastructure Complete" -ForegroundColor Green

# Phase 2-3: 파일 생성은 위의 개별 섹션 참조
Write-Host "📝 Phase 2-3: 설정 파일을 생성하세요 (위 가이드 참조)" -ForegroundColor Yellow

Write-Host "🎉 K-MaaS Platform Ready!" -ForegroundColor Green
Write-Host "다음 단계: 위의 Phase 2, 3 스크립트를 순서대로 실행하세요." -ForegroundColor Cyan
```
