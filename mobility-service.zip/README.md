# K-MaaS (Korean Mobility as a Service) 🚀

K-MaaS는 대중교통(지하철, 버스, KTX), 공유 자전거, 주차, 고속도로 등 모든 이동 수단을 하나의 플랫폼에서 통합 검색하고 결제 및 예약까지 가능한 **대한민국형 통합 모빌리티 서비스**입니다.

[![Production Ready](https://img.shields.io/badge/Status-Production%20Ready-green.svg)](FINAL_REPORT.md)
[![Service Status](https://img.shields.io/badge/Service-Online-blue.svg)](http://localhost:9999)
[![Version](https://img.shields.io/badge/Version-1.0.0-orange.svg)]()

---

## 📚 문서 바로가기

- **[최종 완료 보고서 (FINAL_REPORT.md)](FINAL_REPORT.md)**: 프로젝트 최종 현황 및 성과 보고
- **[시연 가이드 (DEMO.md)](DEMO.md)**: 실무 시연을 위한 단계별 시나리오
- **[API 레퍼런스 (API_REFERENCE.md)](API_REFERENCE.md)**: REST API 상세 명세

---

## ✨ 주요 기능

- **📱 통합 지도 UI**: 카카오맵 기반으로 모든 교통 수단을 한눈에 파악 (네이버 지도 스타일)
- **🚆 실시간 지하철**: 1-9호선, 분당선 등 수도권 전철 실시간 도착 정보 제공
- **🚄 KTX 예매 연동**: 실시간 시간표 조회 및 예매 페이지 연결
- **🚲 공유 자전거 (따릉이)**: 실시간 대여 가능 대수 및 위치 조회
- **🅿️ 스마트 주차**: 주차장 검색, QR 코드 입출차, 요금 자동 정산
- **💰 K-Pass 마일리지**: 이동 거리에 따른 자동 마일리지 적립 및 사용

---

## 🚀 빠르고 쉬운 시작 (Quick Start)

### 필수 요구사항
- Java 17 이상 (JDK 17+)
- Oracle Database XE (Port 1521)

### 실행 방법

1. **저장소 클론**
   ```bash
   git clone https://github.com/donggeun/k-maas.git
   cd k-maas
   ```

2. **자동 실행 스크립트 (Windows)**
   ```bash
   # 원클릭으로 빌드부터 실행까지
   run.bat
   ```

3. **접속**
   - 웹 브라우저: [http://localhost:9999](http://localhost:9999)
   - 모바일 화면 확인: Chrome DevTools (F12) → Device Toggle

---

## 🛠️ 기술 스택

- **Backend**: Spring Boot 3.2, Spring Data JPA, Oracle 21c (XE)
- **Frontend**: HTML5, Vanilla JavaScript, CSS3 (No Framework), Kakao Map API
- **Tooling**: Gradle 8.x, Git

---

## 🔍 트러블슈팅

**Q. 포트 충돌 오류 (Port 9999 is already in use)**
A. `run.bat` 실행 시 자동으로 점유된 포트를 해제합니다. 수동으로 하려면:
```bash
taskkill /F /IM java.exe /T
```

**Q. DB 연결 오류**
A. Oracle XE 서비스가 실행 중인지 확인하세요 (`services.msc`).
   `application.properties`의 username/password가 맞는지 확인하세요.

---

## 👨‍💻 개발자 정보

- **개발자**: 임동근
- **연락처**: donggeun@example.com
- **문의**: [GitHub Issues](https://github.com/donggeun/k-maas/issues)

---

Copyright © 2025 K-MaaS Project. All Rights Reserved.
