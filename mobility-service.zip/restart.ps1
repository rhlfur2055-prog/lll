# K-MaaS 리스타트 스크립트 (PowerShell)

Write-Host "🛑 기존 Java 프로세스 종료 중..." -ForegroundColor Yellow
Get-Process -Name "java" -ErrorAction SilentlyContinue | Stop-Process -Force
Get-Process -Name "gradle" -ErrorAction SilentlyContinue | Stop-Process -Force

Write-Host "🧹 프로젝트 클린 & 빌드 중..." -ForegroundColor Cyan
Set-Location "c:\tools\mobility-service"
./gradlew clean build -x test

if ($LASTEXITCODE -eq 0) {
    Write-Host "✨ 빌드 성공! 서버를 시작합니다..." -ForegroundColor Green
    
    # plain JAR 제외하고 실행 가능한 Boot JAR 선택
    $jarFile = Get-ChildItem "build\libs\mobility-service-*.jar" | Where-Object { $_.Name -notlike "*-plain.jar" } | Select-Object -First 1
    
    if ($jarFile) {
        Write-Host "🚀 실행 파일: $($jarFile.Name)"
        
        # 이전 로그 삭제
        if (Test-Path "server.log") { Remove-Item "server.log" }

        # 백그라운드 실행 및 로그 리다이렉션
        Start-Process -FilePath "java" -ArgumentList "-jar", "$($jarFile.FullName)" -RedirectStandardOutput "server.log" -RedirectStandardError "server.log" -WindowStyle Hidden
        
        Write-Host "✅ 서버가 백그라운드에서 시작되었습니다."
        Write-Host "📜 로그 확인: Get-Content server.log -Wait -Tail 20"
        Write-Host "⏳ 30초 후 http://localhost:9999 접속을 시도하세요."
    }
    else {
        Write-Host "❌ 실행 가능한 JAR 파일을 찾을 수 없습니다." -ForegroundColor Red
        Write-Host "📂 build/libs 목록:"
        Get-ChildItem "build\libs" | Select-Object Name
    }
}
else {
    Write-Host "❌ 빌드 실패. 로그를 확인하세요." -ForegroundColor Red
}
